import ollama

def generate_linkedin_post(niche, tone, model_name="gemma3"):
    # Build the system prompt (this is your prompt engineering practice!)
    system_prompt = system_prompt = f"""You are a professional content creator and industry expert in the "{niche}" niche.
Your task is to write high-quality LinkedIn posts with a "{tone}" tone.

Here are examples of good LinkedIn posts:

EXAMPLE 1:
"Let's talk about the 'overqualified' myth. I've seen countless talented professionals get rejected because they seemed 'too senior' for a role. Here's what actually matters: 1) Your ability to solve specific problems, 2) Cultural fit, and 3) Willingness to grow. Don't let a title define your potential. Have you ever been told you're 'overqualified'?"

EXAMPLE 2:
"3 questions every candidate should ask in an interview:
1. 'What does success look like in the first 90 days?'
2. 'What's the biggest challenge your team is facing?'
3. 'How does this role contribute to the bigger mission?'
These questions show you're thinking about impact. Save this for your next interview."

Now, write a new LinkedIn post following the same style.
AUDIENCE: Working professionals in the {niche} industry.

STRUCTURE:
1. HOOK: Start with a relatable problem or surprising fact.
2. BODY: Provide exactly 3-4 actionable insights.
3. CALL-TO-ACTION: End with a question.
LENGTH: 200-300 words."""

    user_prompt = f"Write a LinkedIn post about a current challenge in the {niche} industry."

    try:
        response = ollama.chat(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
        )
        return response["message"]["content"]
    except Exception as e:
        return f"Error: {e}"


# --- Generate 3 sample outputs ---
if __name__ == "__main__":
    print("=" * 70)
    print("SAMPLE 1: RECRUITER NICHE (EDUCATIONAL TONE)")
    print("=" * 70)
    output1 = generate_linkedin_post("Recruiter", "educational")
    print(output1)

    print("\n\n" + "=" * 70)
    print("SAMPLE 2: DATA SCIENTIST NICHE (INSPIRATIONAL TONE)")
    print("=" * 70)
    output2 = generate_linkedin_post("Data Scientist", "inspirational")
    print(output2)

    print("\n\n" + "=" * 70)
    print("SAMPLE 3: SOFTWARE ENGINEER NICHE (HUMOROUS TONE)")
    print("=" * 70)
    output3 = generate_linkedin_post("Software Engineer", "humorous")
    print(output3)