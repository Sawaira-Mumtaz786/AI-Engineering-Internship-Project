text
============================================================
          WEDNESDAY TASK - COMPLETION REPORT
============================================================
Date: July 10, 2026
Student: Sawaira Mumtaz
Environment: Windows 11, PowerShell, Python, Ollama (mistral)
============================================================

============================================================
PART 1: SUMMARY OF OPENAI'S PROMPTING GUIDE
============================================================

Key takeaways from the guide:

1. BE SPECIFIC: Tell the AI exactly what you want. Vague prompts give vague answers.

2. PROVIDE EXAMPLES: Show the AI what a good answer looks like.

3. SET THE TONE: Tell the AI how to sound (professional, casual, funny, etc.).

4. BREAK BIG TASKS DOWN: Split complex tasks into smaller steps.

5. USE SYSTEM MESSAGES: Set the rules and role for the AI upfront.

6. TEST AND COMPARE: Try different prompts and see what works best.

7. DEFINE THE AUDIENCE: Tell the AI who it's writing for.

============================================================
PART 2: SYSTEM PROMPTS TESTED
============================================================

PROMPT A - WITHOUT TONE INSTRUCTION:
System: "You are an AI assistant that writes LinkedIn posts for SaaS founders."
User: "Write a short LinkedIn post about customer churn for a SaaS founder. Share one lesson learned."

PROMPT B - WITH TONE INSTRUCTION:
System: "You are a seasoned SaaS founder. You write LinkedIn posts that are raw, honest, and slightly opinionated. You share real lessons, not generic advice. Your tone is direct and conversational. You avoid buzzwords."
User: "Write a short LinkedIn post about customer churn for a SaaS founder. Share one lesson learned."

============================================================
PART 3: OUTPUT EXAMPLES & ANALYSIS
============================================================

✅ BEST EXAMPLE (With Tone Instruction):
[COPY THE OUTPUT FROM PROMPT B HERE]

Why it WORKED:
- Tells a real story with emotion
- Vulnerable and honest
- Specific and concrete
- No buzzwords
- Sounds like a real person

❌ WORST EXAMPLE (Without Tone Instruction):
[COPY THE OUTPUT FROM PROMPT A HERE]

Why it FAILED:
- Boring and generic
- Sounds like a textbook
- Full of buzzwords
- No personality
- Sounds AI-written

============================================================
CONCLUSION / KEY TAKEAWAY
============================================================

Adding a tone instruction makes a dramatic difference because it:
- Gives the AI a PERSONA to embody
- Provides CONSTRAINTS that force creativity
- Makes the output sound HUMAN instead of AI-generated

Without tone, the AI defaults to its most generic, textbook-style writing. 
With tone, the AI produces authentic, engaging, and memorable content.

output
PS C:\Users\Sawaira Mumtaz\OneDrive\Desktop\AI task\week1-06-07-26> python wednesday_task.py      
============================================================
WEDNESDAY TASK - COMPLETE SOLUTION (OLLAMA VERSION)
============================================================

============================================================
PART 1: SUMMARY OF OPENAI'S 'INTRODUCTION TO PROMPTING' GUIDE
============================================================

Key takeaways from the guide:

1. BE SPECIFIC: Tell the AI exactly what you want. Vague prompts = vague answers.
2. PROVIDE EXAMPLES: Show the AI what a good answer looks like.
3. SET THE TONE: Tell the AI how to sound (professional, casual, funny, etc.).
4. BREAK BIG TASKS DOWN: Split complex tasks into smaller steps.
5. USE SYSTEM MESSAGES: Set the rules and role for the AI upfront.
6. TEST AND COMPARE: Try different prompts and see what works best.
7. DEFINE THE AUDIENCE: Tell the AI who it's writing for.


============================================================
PART 2 & 3: PROMPT COMPARISON (WITH vs WITHOUT TONE)
============================================================

------------------------------------------------------------
PROMPT A: WITHOUT TONE INSTRUCTION
------------------------------------------------------------
System Message: You are an AI assistant that writes LinkedIn posts for SaaS founders.

--- OUTPUT ---
ERROR: Ollama took too long. Please try again.

------------------------------------------------------------
PROMPT B: WITH TONE INSTRUCTION
------------------------------------------------------------
System Message: You are a seasoned SaaS founder. You write LinkedIn posts that are raw, honest, and slightly opinionated. 
You share real lessons, not generic advice. Your tone is direct and conversational. You avoid buzzwords.

--- OUTPUT ---
ERROR: Ollama took too long. Please try again.

============================================================
PART 3: BEST/WORST ANALYSIS
============================================================

----------------------------------------
✅ BEST EXAMPLE (With Tone Instruction)
----------------------------------------

ERROR: Ollama took too long. Please try again.

WHY THIS WORKED:
- Tells a real story with emotion
- Vulnerable and honest
- Specific and concrete
- No buzzwords
- Sounds like a real person

----------------------------------------
❌ WORST EXAMPLE (Without Tone Instruction)
----------------------------------------

ERROR: Ollama took too long. Please try again.

WHY THIS FAILED:
- Boring and generic
- Sounds like a textbook
- Full of buzzwords
- No personality
- Sounds AI-written

----------------------------------------
KEY TAKEAWAY:
----------------------------------------
Adding a tone instruction gives the AI a PERSONA to embody.
This makes the output sound HUMAN instead of AI-generated.


============================================================
END OF REPORT
============================================================
