<div align="center">
<img width="1200" height="475" alt="LinkedIn Post Generator" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# 🚀 LinkedIn Post Generator with Groq API

An AI-powered LinkedIn post generator that creates engaging content using Groq's fast LLM API. Perfect for professionals, marketers, and content creators.

## Features

- ✅ **AI-Generated Posts**: Creates LinkedIn posts in seconds
- ✅ **Auto-Validation**: Checks word count (150-300 words) and hashtag count (3-5)
- ✅ **Customizable**: Choose niche, tone, and topic
- ✅ **Carousel Support**: Generate 8-slide LinkedIn carousels
- ✅ **Quality Evaluation**: Optional AI authenticity scoring (1-10)
- ✅ **Free & Fast**: Powered by Groq's lightning-fast LPU technology

## Tech Stack

- **Python 3.x** - Core language
- **Groq API** - LLM provider (free tier available)
- **Argparse** - Command-line interface

## Prerequisites

- Python 3.8 or higher installed
- Groq API key (free from [console.groq.com](https://console.groq.com))

## Installation

### 1. Clone or download this repository
```bash
git clone <your-repo-url>
cd "AI LLM postfusion internship\Week4"
pip install groq
# Windows PowerShell
$env:GROQ_API_KEY = "your-groq-api-key-here"

# Mac/Linux
export GROQ_API_KEY="your-groq-api-key-here"
python generate.py --topic "Your Topic Here"
python generate.py --topic "AI in Healthcare"
python generate.py --topic "Leadership in Tech" --niche "Business" --tone "bold"
python generate.py --format carousel --topic "Future of Artificial Intelligence"
python generate.py --topic "Digital Marketing" --eval
python generate.py --topic "Your Topic" --niche "Your Niche" --tone "Your Tone" --format post --eval
============================================================
🚀 GROQ LINKEDIN GENERATOR
📌 Topic: 'AI in Healthcare' | Niche: Tech Leader | Tone: storytelling
============================================================

--- GENERATED CONTENT ---
[Your LinkedIn post content appears here...]

-------------------------

📊 VALIDATION:
  • Attempts: 1
  • Word Count: 208 (150-300) ✅
  • Hashtags: #AI, #Healthcare, #Innovation (3/3-5) ✅
  • Valid: ✅ PASSED
  