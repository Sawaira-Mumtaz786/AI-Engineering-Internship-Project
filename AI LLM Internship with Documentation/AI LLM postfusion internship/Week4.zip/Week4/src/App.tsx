import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { CliSimulator } from './components/CliSimulator';
import { MondayGenerator } from './components/MondayGenerator';
import { TuesdayValidation } from './components/TuesdayValidation';
import { WednesdayQualityGuard } from './components/WednesdayQualityGuard';
import { ThursdayCarousel } from './components/ThursdayCarousel';
import { FridayPortfolio } from './components/FridayPortfolio';

export default function App() {
  const [activeTab, setActiveTab] = useState('cli');
  const [ollamaUrl, setOllamaUrl] = useState('http://localhost:11434');
  const [model, setModel] = useState('llama3');
  const [ollamaOnline, setOllamaOnline] = useState<boolean | null>(null);

  const checkOllamaStatus = async () => {
    setOllamaOnline(null);
    try {
      const res = await fetch(`/api/ollama-status?url=${encodeURIComponent(ollamaUrl)}`);
      const data = await res.json();
      setOllamaOnline(data.online);
    } catch {
      setOllamaOnline(false);
    }
  };

  useEffect(() => {
    checkOllamaStatus();
  }, [ollamaUrl]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500 selection:text-white pb-16">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        ollamaUrl={ollamaUrl}
        setOllamaUrl={setOllamaUrl}
        model={model}
        setModel={setModel}
        ollamaOnline={ollamaOnline}
        checkOllama={checkOllamaStatus}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {activeTab === 'cli' && (
          <CliSimulator ollamaUrl={ollamaUrl} model={model} />
        )}

        {activeTab === 'monday' && (
          <MondayGenerator ollamaUrl={ollamaUrl} model={model} />
        )}

        {activeTab === 'tuesday' && (
          <TuesdayValidation ollamaUrl={ollamaUrl} model={model} />
        )}

        {activeTab === 'wednesday' && (
          <WednesdayQualityGuard ollamaUrl={ollamaUrl} model={model} />
        )}

        {activeTab === 'thursday' && (
          <ThursdayCarousel ollamaUrl={ollamaUrl} model={model} />
        )}

        {activeTab === 'friday' && (
          <FridayPortfolio ollamaUrl={ollamaUrl} model={model} />
        )}
      </main>
    </div>
  );
}
