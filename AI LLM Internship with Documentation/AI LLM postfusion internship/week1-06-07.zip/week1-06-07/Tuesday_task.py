import requests
import json

print("=" * 40)
print("MONDAY TASK - OLLAMA VERSION")
print("=" * 40)

# ----- PART 1: PYTHON REFRESHER -----
print("\n--- PART 1: PYTHON REFRESHER ---")

def welcome_message(name):
    return "Welcome to the team, " + name + "!"

my_business = {
    "name": "Peak Performance Coaching",
    "clients": 15,
    "country": "USA"
}

business_json = json.dumps(my_business)

print(welcome_message("Sawaira"))
print("My Dictionary:", my_business)
print("My Dictionary as a JSON string:", business_json)

# ----- PART 2: PUBLIC WEATHER API -----
print("\n--- PART 2: WEATHER API CALL ---")

weather_url = "https://api.open-meteo.com/v1/forecast?latitude=35.68&longitude=139.76&current_weather=true"
weather_response = requests.get(weather_url)
weather_data = weather_response.json()

print("Raw Weather JSON Response:")
print(weather_data)

temp = weather_data["current_weather"]["temperature"]
print(f"\nTokyo temperature right now: {temp}°C")

# ----- PART 3: OLLAMA API CALL -----
print("\n--- PART 3: OLLAMA API CALL ---")

ollama_url = "http://localhost:11434/api/generate"

payload = {
    "model": "mistral",
    "prompt": "Say 'My very first API call works perfectly!'",
    "stream": False
}

print("Calling your Ollama AI...")
response = requests.post(ollama_url, json=payload)

print("\n--- THE RAW JSON RESPONSE FROM OLLAMA ---")
print(response.text)

if response.status_code == 200:
    ollama_data = response.json()
    ai_reply = ollama_data["response"]
    print("\n--- AI's Actual Reply ---")
    print(ai_reply)
else:
    print("Oops, error code:", response.status_code)