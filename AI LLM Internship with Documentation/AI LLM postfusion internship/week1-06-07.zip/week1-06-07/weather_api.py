"""
PART 2: PUBLIC API CALL
Using the free Weather API (wttr.in) - No API key required!
"""

import requests
import json

def get_weather(city="Islamabad"):
    url = f"https://wttr.in/{city}?format=j1"
    
    try:
        print(f"🌤️  Fetching weather for {city}...")
        response = requests.get(url)
        
        if response.status_code == 200:
            return response.json()
        else:
            return {"error": f"Status code: {response.status_code}"}
    
    except Exception as e:
        return {"error": str(e)}

def extract_weather_info(data):
    if "error" in data:
        return data
    
    try:
        current = data.get("current_condition", [{}])[0]
        location = data.get("nearest_area", [{}])[0]
        
        return {
            "city": location.get("areaName", [{"value": "Unknown"}])[0].get("value"),
            "country": location.get("country", [{"value": "Unknown"}])[0].get("value"),
            "temperature": current.get("temp_C", "N/A"),
            "condition": current.get("weatherDesc", [{"value": "Unknown"}])[0].get("value"),
            "humidity": current.get("humidity", "N/A")
        }
    except Exception as e:
        return {"error": f"Parsing error: {e}"}

if __name__ == "__main__":
    print("=" * 60)
    print("🌤️  WEATHER API DEMONSTRATION")
    print("=" * 60)
    
    raw_data = get_weather("Islamabad")
    weather = extract_weather_info(raw_data)
    
    print("\n📊 Weather Information:")
    print("-" * 40)
    
    if "error" in weather:
        print(f"❌ {weather['error']}")
    else:
        print(f"📍 City: {weather['city']}")
        print(f"🌍 Country: {weather['country']}")
        print(f"🌡️  Temperature: {weather['temperature']}°C")
        print(f"☁️  Conditions: {weather['condition']}")
        print(f"💧 Humidity: {weather['humidity']}%")
    
    print("\n📝 Raw JSON Response (first 400 chars):")
    print("-" * 40)
    print(json.dumps(raw_data, indent=2)[:400] + "...")
    
    print("\n✅ Public API Call Complete!")