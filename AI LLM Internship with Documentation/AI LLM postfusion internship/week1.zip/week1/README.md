**🔧 Implementation Changes & Model Selection
**Instead of using the OpenAI API (which requires a paid API key), I built this project using Ollama — a free, open-source tool that runs AI models locally on my machine. This allowed me to complete the task without incurring any costs while still practicing core prompt engineering principles.

**🔄 Key Changes I Made to the Python Script
**What I Changed	Why I Changed It	How It Works
Switched from OpenAI to Ollama	To avoid needing a paid OpenAI API key. Ollama is 100% free and runs offline.	Replaced openai.ChatCompletion.create() with ollama.chat().
Added a model_name parameter	To easily test different AI models and compare their outputs.	The function now accepts model_name="tinyllama" as a default, but can be switched to "phi3.5" or "gemma3".
Changed the default model to TinyLlama	TinyLlama is lightweight (~0.6 GB) and runs quickly on any laptop, making it ideal for testing.	Set model_name="tinyllama" in the function signature.
Added a 3rd sample output	The task asked to "try 3 variations", so I added a Software Engineer + Humorous tone.	Added output3 = generate_linkedin_post("Software Engineer", "humorous") in the if __name__ == "__main__" block.
🧪 Testing Different Models (TinyLlama, Phi3.5, Gemma 3)
During development, I tested 3 different AI models to see how they performed with the same system prompt.

Model Name	Size	Speed	Output Quality	Verdict
TinyLlama	0.6 GB	⚡ Very Fast	Generic, uses placeholders like [Your Name]	Good for quick testing
Phi-3.5	2.3 GB	🚀 Fast	Better structure, fewer hallucinations	Balanced choice
Gemma 3 (by Google)	2.0 GB	🐢 Slower	Best quality, more specific and professional	Best for production
**Why I chose TinyLlama for the final submission:
**
It runs instantly on any computer (even low-spec laptops).

It demonstrates the core functionality without requiring long download times.

The system prompt still works — the model follows the HOOK-BODY-CTA structure.

For the internship evaluator, they can run the script immediately without waiting for large model downloads.

If my supervisor wants higher-quality outputs, I can simply change the model_name parameter to "gemma3" (after running ollama pull gemma3).

**📄 Final Code Snippet (The Core Logic)
**Here is the core function showing how I integrated everything:

**python**
def generate_linkedin_post(niche, tone, model_name="tinyllama"):
    system_prompt = f"""You are a professional content creator and industry expert in the "{niche}" niche.
Your task is to write high-quality LinkedIn posts with a "{tone}" tone.

**AUDIENCE**: Working professionals and peers in the {niche} industry.

**STRUCTURE RULES:
**1. HOOK: Start with a relatable problem or surprising fact.
2. BODY: Provide exactly 3-4 actionable insights.
3. CALL-TO-ACTION: End with a question to encourage comments.

LENGTH: Between 200-300 words."""

    user_prompt = f"Write a LinkedIn post about a current challenge in the {niche} industry."

    response = ollama.chat(
        model=model_name,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
    )
    return response["message"]["content"]
    
**💡 What I Learned From These Changes
**Prompt engineering is model-agnostic – The same system prompt works across different models (TinyLlama, Phi3.5, Gemma).

Model size affects output quality – Smaller models are faster but produce more generic text. Larger models generate richer, more specific posts.

Open-source AI is powerful and cost-effective – Ollama makes it easy to experiment with prompt engineering without spending money.

Iteration is key – Testing 3 niches and 3 models helped me understand how tone, structure, and model choice interact to produce different results.

**📂 Folder Structure Submitted
**text
week1/
├── linkedin_generator.py   # Main Python script (uses Ollama + TinyLlama)
├── requirements.txt        # Dependencies (ollama)
├── sample_outputs.txt      # 3 generated LinkedIn posts
└── README.md              # This file – project explanation & setup guide

**Here is the final Linkdeln post output 
**

======================================================================
SAMPLE 1: RECRUITER NICHE (EDUCATIONAL TONE)
======================================================================
[Insert Your Avatar Here]

Hey [LinkedIn Followers],

I hope you're having a great week so far! Today, I wanted to talk to you about a recent challenge in the Recruitment industry that has captivated the attention of many professionals out there.

In September 2019, Korn Ferry, one of the world's leading recruiting firms, introduced a new initiative called "Better Job Fairs" to increase transparency and fairness in job fairs. The idea behind this initiative was that job seekers should be treated equally and fairly at job fairs, regardless of their socio-economic background or educational qualifications.

Initially, this initiative received widespread criticism from many stakeholders, including employers,recruiters, and job-seekers, for being too "green" and radical for the industry. However, after a thorough analysis of job fairs around the world, Korn Ferry's Better Job Fairs initiative has proven to be more successful than ever before.

According to the latest research conducted by Korn Ferry, a significant number of job seekers who attended this initiative reported a 28% increase in their chances of securing a job at the fairs, compared to those who attended traditional job fairs. This has been attributed to better transparency and more equal treatment for all participants.

Moreover, Korn Ferry's Better Job Fairs initiative has also led to an increase in fairness in other aspects of recruitment, such as the hiring process itself. According to a survey conducted by Korn Ferry earlier this year, 82% of job seekers who attended job fairs reported that they felt more comfortable and confident about their chances of securing a job after attending the fairs.

While this may seem like a small change in an industry where many stakeholders have been demanding improvements for years, it highlights how essential it is to consider both the benefits and drawbacks when implementing new policies or initiatives. Nonetheless, I believe that Korn Ferry's Better Job Fairs initiative is a positive step forward for the industry, and I encourage you all to join me in celebrating this achievement.

So, if you're looking for a job, don't forget to attend your next job fair with an open mind and open heart, knowing that there are now better options available to you based on the Better Job Fairs initiative that we have just discussed.

In conclusion, I urge all job seekers to take advantage of this unique opportunity and attend their next job fair with a clear mind, optimism, and excitement for the future. Let's work together to improve the industry and promote equal opportunities for all participants.

Thank you for your time, and please feel free to leave any comments or questions below. I look forward to hearing from you soon!

======================================================================
SAMPLE 2: DATA SCIENTIST NICHE (INSPIRATIONAL TONE)
======================================================================
Title: "The Next ChaLearChallenge: How can Data Scientists Prepare for This Important Competition?"

LinkedIn Post:

[Image of an ocean at sunset, with a blue dot at the center]

Hey [Company Name],

As you know, the Data Scientist industry is growing rapidly and has become increasingly important in our modern world. It's no secret that this field demands top-of-the-line skills to create innovative solutions for clients. This month alone, we witnessed a significant challenge in the industry - the first Data Scientist ChaLearChallenge, hosted by [Website Name], an esteemed organization aiming to bring together data scientists from around the world.

The competition involves 10 teams of four individuals who are tasked with developing solutions that can accurately predict a customer's buying behavior based on their online purchases. As you probably know, these predictions have a significant impact on businesses. They help companies make informed decisions about their products or services, which ultimately affect their sales and overall revenue.

This is where we come in, Data Scientists from different organizations across the globe who are here to challenge each other in a fun yet competitive atmosphere. This is a great opportunity for Data Scientists at [Your Company Name] to showcase their skills and network with peers from similar organizations.

[Insert actionable insights here]

One of the most exciting things about this competition is that it encourages Data Scientists to experiment with new techniques, technologies, and data sets. This can lead to groundbreaking insights that may have never been achieved in the past, which could change the face of the industry as we know it today.

As a Data Scientist, you should be prepared for this competition. You need to familiarize yourself with various data sets from various industries and work on developing innovative solutions. The key is to approach the challenge with an open mind and a willingness to learn from others' experiences.

[CALL-TO-ACTION]

If you want to take advantage of this opportunity, we encourage all Data Scientists at [Your Company Name] to sign up for the competition. It will provide you with an excellent chance to showcase your skills and connect with other top Data Scientists from around the globe.

We can't wait to see what amazing solutions our Data Scientists can come up with!

Thank you for your time and attention. If you have any questions or concerns, please feel free to reach out to me at [Your Contact Information].

Best regards,

Here i test and change another ai model of ollama below and got output

===================================================================== 
SAMPLE 1: RECRUITER NICHE (EDUCATIONAL TONE)
======================================================================
Dear LinkedIn Community,

As you all know, LinkedIn is the best networking platform for professionals who are looking to expand their network and connect with potential employers. However, I would like to draw your attention to a current challenge that's been making headlines in the Recruiter industry.

Earlier this year, a new hiring process was implemented at a leading recruitment agency in the United Kingdom (UK). The new system was met with widespread resistance from employees who felt it would disrupt their workflow and workload. However, some of them also believed that the new system would lead to better hiring outcomes for their clients.

The initial phase of the challenge saw a significant increase in the number of applications submitted by candidates, but there was also a decrease in the number of interviews. The recruitment agency's management team had hoped this would signal a positive outcome but instead, they faced criticism and backlash from their clients.

However, the current challenge is not just an isolated incident; it's a trend that has been ongoing for some time in the industry. Many recruitment agencies across various countries have experimented with new hiring processes to find out what works best for them and their clients.

At this point, we can safely say that there is no one-size-fits-all approach when it comes to hiring. However, it seems that the Recruiter industry has found a winning formula in this challenge. The key lesson here is that transparency and communication are key to creating a successful hiring process.

In conclusion, we encourage everyone to embrace new technologies and processes in their job search as they have the power to improve outcomes for both recruiters and candidates alike. Don't be afraid to share your experiences or learn from others' experiences so that you can create a successful hiring process for yourself and future hires.

Thank you for your attention, and I look forward to hearing your thoughts on this topic in the comments section.

======================================================================
SAMPLE 2: DATA SCIENTIST NICHE (INSPIRATIONAL TONE)
======================================================================
[Insert Image]

Dear LinkedIn audience,

As an experienced content creator and industry expert in the Data Scientist space, I am thrilled to share with you the latest craze sweeping the Data Scientist industry. And it's no surprise that we have yet another exciting challenge to report on!

The recent Data Science Association of America (DSA) Challenge has sparked excitement and curiosity among the industry experts. This challenge is designed to test Data Scientists on their ability to handle unstructured data, which has emerged as a significant challenge in various industries.

For those who may be unfamiliar with what unstructured data entails, it refers to raw or unprocessed data that contains irrelevant or noisy information. In other words, the challenge is to use advanced machine learning techniques and algorithms to analyze such data sets. The DSA Challenge will test the abilities of Data Scientists to extract valuable insights from such data sets.

This challenging task has been well received by industry experts as it provides an opportunity for those who excel in unstructured data analysis to showcase their skills and knowledge. It's a great chance to learn new technologies, approaches and gain exposure through this initiative.

This challenge is not only unique but also interesting because it requires innovative thinking and creativity in handling these challenges. And that's what we love about Data Scientists! They are always looking for ways to solve complex problems using advanced analytical methods.

So, if you are a passionate Data Scientist who enjoys solving challenging problems and wants to showcase your skills and knowledge, I encourage you to participate in this challenge. It's an opportunity of a lifetime to be part of something unique, meaningful and beneficial for the industry as a whole.

Don't miss out on this exciting challenge! Join us to push the limits of unstructured data analysis and contribute your knowledge and expertise. Sign up now by visiting [insert link to registration page] and stay tuned for more updates on the DSA Challenge!

Thanks,
[Your Name]

==================================================================== 
SAMPLE 3: SOFTWARE ENGINEER NICHE (HUMOROUS TONE)
======================================================================
[Insert your headshot here]

Dear [LinkedIn audience],

As a professional content creator, I'm always on the lookout for the latest and most exciting stories happening in the Software Engineer industry. And today, I have some news that might catch your attention!

Recently, a recent graduate from one of the top tech schools across the country was hired into a prestigious Software Development team at XYZ Corporation. However, as soon as they started working on a project with a team of Software Engineers who were seasoned professionals in this field, chaos ensued.

It turns out that one of the senior Software Engineers on the team had been stealing ideas from another team member's work and incorporating them into their own. The junior developers on the team were left struggling to keep up with the latest trends in the industry.

As you can imagine, this led to delays in the project's timeline, resulting in more time spent debugging and fixing bugs than was originally planned. It also caused frustration for everyone involved, with many engineers feeling let down by their own company.

But don't worry, it wasn't all doom and gloom! Despite this chaos, the team eventually managed to come up with a workable solution and completed the project within the projected timeline. However, as parting gifts for completing the project successfully, the senior Software Engineer received a bonus that he was not expecting.

I can attest that I have seen it all before. It's always fun to see when something like this happens in the world of tech! But if we as professionals could learn from this experience and work together more effectively to tackle issues like these, then maybe we can create a better future for ourselves and those who are working hard to make things happen every day.

So, what can we learn from this incident? I propose that we collaborate more closely with each other and work as a team to find solutions that are not only effective but also sustainable in the long-term. Let's show our senior colleagues that we are committed to making things happen together, even when the road seems rocky!

If you have any insights or suggestions on how this can be done, please feel free to share them with me. Don't hesitate to reach out if you need any help or support in completing projects successfully and working towards a better future as a Software Engineer. I'm always here to provide whatever resources are necessary!

I look forward to hearing from you soon!

Take care,
