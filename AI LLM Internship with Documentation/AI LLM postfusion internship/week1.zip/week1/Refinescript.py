import ollama

def generate_linkedin_post(niche, tone, model_name="tinyllama"):
    """Generates a LinkedIn post based on niche and tone."""
    
    system_prompt = f"""You are a professional content creator and industry expert in the "{niche}" niche.
Your task is to write high-quality LinkedIn posts with a "{tone}" tone.

AUDIENCE: Working professionals and peers in the {niche} industry.

STRUCTURE RULES:
1. HOOK: Start with a relatable problem or surprising fact.
2. BODY: Provide exactly 3-4 actionable insights.
3. CALL-TO-ACTION: End with a question to encourage comments.

LENGTH: Between 200-300 words."""

    user_prompt = f"Write a LinkedIn post about a current challenge in the {niche} industry."

    try:
        response = ollama.chat(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ]
        )
        return response["message"]["content"]
    except Exception as e:
        return f"Error: {e}"

# --- NEW FUNCTION: The "Does this sound robotic?" Self-Check ---
def rate_post(post_content, niche, tone, model_name="tinyllama"):
    """
    Asks the AI to rate its own LinkedIn post on a scale of 1-10 
    for how natural, specific, and non-robotic it sounds.
    """
    
    rating_prompt = f"""You are a professional content quality evaluator. 
Your task is to rate the following LinkedIn post on a scale of 1 to 10.

Scoring Guide:
- 1-3: Very robotic, generic, full of placeholders ([Your Name]), or hallucinated facts.
- 4-6: Decent structure but feels stiff, lacks specific actionable advice.
- 7-8: Sounds human, has good specific tips, and flows naturally.
- 9-10: Excellent, engaging, highly specific, and feels like a real industry expert wrote it.

Niche: {niche}
Tone Requested: {tone}

Post to evaluate:
---
{post_content}
---

Provide your response in this exact format:
Score: [1-10]
Reason: [Brief explanation of why you gave this score, focusing on how natural or robotic it sounds.]
"""

    try:
        response = ollama.chat(
            model=model_name,
            messages=[
                {"role": "system", "content": "You are a strict but fair content evaluator. Return exactly the requested format."},
                {"role": "user", "content": rating_prompt}
            ]
        )
        return response["message"]["content"]
    except Exception as e:
        return f"Rating Error: {e}"

# --- Generate 3 sample outputs AND RATE THEM ---
if __name__ == "__main__":
    
    # Define the test cases (Niche, Tone)
    test_cases = [
        ("Recruiter", "educational"),
        ("Data Scientist", "inspirational"),
        ("Software Engineer", "humorous")
    ]
    
    # Loop through each test case
    for i, (niche, tone) in enumerate(test_cases, 1):
        print("=" * 70)
        print(f"SAMPLE {i}: {niche.upper()} NICHE ({tone.upper()} TONE)")
        print("=" * 70)
        
        # 1. Generate the post
        post = generate_linkedin_post(niche, tone)
        print(post)
        
        # 2. Run the "Robotic?" Self-Check
        print("\n" + "-" * 50)
        print("🤖 SELF-CHECK: Does this sound robotic?")
        print("-" * 50)
        rating_result = rate_post(post, niche, tone)
        print(rating_result)
        
        print("\n\n")