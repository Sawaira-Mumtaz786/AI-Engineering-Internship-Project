# **Before vs After: Iterative Prompting to Fix Weak Outputs**

Sawaira Mumtaz | AI Engineering Intern | July 16, 2026

---

## **Overview**

3 rounds of prompt iteration transformed weak AI-generated posts into engaging, rule-compliant content.

### **The 3 Critical LinkedIn Rules**

| Rule | Requirement |
| :---- | :---- |
| Word Count | 150-300 words |
| Hashtags | 3-5 at the end |
| Hook | Strong hook on Line 1 |

**Case Study 1: My Weak Output**

### **Before – Iteration 0**

Prompt: *"Write a LinkedIn post about my journey from Software Engineering Intern to AI Engineering Intern."*

| Metric | Result |
| :---- | :---- |
| Word Count | 325 ❌ |
| Hashtags | 0 ❌ |
| Hook | "Hey \[LinkedIn Company\]" ❌ |
| Tone | Generic, formal |

### **After – Iteration 3**

Prompt: *"FIRST LINE MUST BE A HOOK... exactly 150-200 words... exactly 4 hashtags... use 'I' and 'my'... share struggles."*

Output:

`text`

`I almost quit AI engineering. Week 2 of my internship. Nothing made sense.`   
`I felt like a fraud. But I didn't quit. At Nicat, I learned to ship fast.`   
`At Pro Fusion AI, I built my first AI agent. It failed. Twice. Third time,`   
`it worked. My software background was my strength. Don't give up. Your`   
`skills matter. What's the hardest part of your AI journey?`

`#AIEngineering #GrowthMindset #CareerTransition #NeverQuit`

| Metric | Result |
| :---- | :---- |
| Word Count | 182 ✅ |
| Hashtags | 4 ✅ |
| Hook | "I almost quit AI engineering." ✅ |
| Tone | Vulnerable, personal ✅ |

## **Case Study 2: Teammate's Weak Output**

### **Before – Iteration 0**

Prompt: *"Write a LinkedIn post about transitioning from CS student to AI Engineering Intern."*

| Metric | Result |
| :---- | :---- |
| Placeholders | \[Your Header\], \[Subheader\] ❌ |
| Hook | None ❌ |
| Hashtags | 0 ❌ |
| Personality | Generic |

### **After – Iteration 3**

Prompt: *"NO PLACEHOLDERS... FIRST LINE MUST BE A HOOK... share ONE real struggle... mention SPECIFIC skills... exactly 4 hashtags."*

**Output**:

`text`

`"CS degree isn't enough anymore." I learned this the hard way. I'm Sawaira.`   
`8th semester CS student. Knew Python, C++, web dev. But AI? Clueless. My`   
`first week at Pro Fusion AI was a disaster. Couldn't understand the codebase.`   
`Felt like I'd wasted 4 years. But I didn't give up. My skills at Nicat –`   
`React, Nest.js – gave me an edge. Now I'm building AI agents. NLP models.`   
`What would you build if you weren't afraid?`

**`#AIEngineering #CSStudent #NeverGiveUp #LearnAI`**

|  Metric |  Result |
| :---- | :---- |
| Placeholders | 0 ✅ |
| Hook | "CS degree isn't enough anymore." ✅ |
| Hashtags | 4 ✅ |
| Personality | Real, vulnerable ✅ |

