# Week 2: Few-Shot vs Zero-Shot Prompting Comparison

**Date:** July 16, 2026  
**Student:** Sawaira Mumtaz  
**Environment:** Windows 11, PowerShell, Python 3.14, Ollama (tinyllama)

## 📌 Task Overview

This task compares **Zero-shot prompting** (no examples) vs **Few-shot prompting** (using my own Week 1 work as examples) to determine which produces better, more "on-brand" content for Posts Fusion.

## 🔬 What is Zero-Shot vs Few-Shot?

| **Zero-Shot** | **Few-Shot** |
| :--- | :--- |
| The AI receives **no examples** of the desired output. It relies purely on its training data. | The AI receives **2 examples** of the desired output. It learns the structure, tone, and style from these examples. |
| Generic, safe, and often sounds like "AI wrote this." | Consistent, personalized, and sounds like the examples provided. |

## 📂 My Examples Used for Few-Shot

### Example 1: My First Successful Ollama API Call (Tuesday Task)
My very first API call works perfectly!

### Example 2: My Dynamic Prompt Function (Thursday Task)
```python
def build_dynamic_prompt(niche, tone):
    tone_descriptions = {
        "professional": "Professional, polished, and business-like.",
        "casual": "Casual, conversational, and friendly.",
        "inspirational": "Inspirational, motivational, and uplifting.",
        "raw": "Raw, honest, and vulnerable."
    }
    niche_descriptions = {
        "coach": "A business or life coach who helps people achieve their goals.",
        "founder": "A SaaS founder who has built a company from the ground up.",
        "recruiter": "A recruiter who helps companies find and hire top talent."
    }
    return system_prompt, user_prompt
📊 Generated Outputs
📄 ZERO-SHOT OUTPUT (No examples given)
Title: AI Engineering Internship Experience: The Challenges and Rewards of Working With Artificial Intelligence in Action

Introduction:

At XYZ, we are always on the lookout for innovative individuals with unique perspectives to help us create cutting-edge technologies. One such individual is Jhon who specializes in AI Engineering Internship Experience. In this internship, Jhon works alongside experienced engineers in our company to develop and implement cutting-edge algorithms that will revolutionize the way we operate in the industry.

Experience:
Jhon's first day at XYZ was a breeze; he had already gained valuable experience working with artificial intelligence software such as TensorFlow, Apache Spark, and AWS Machine Learning. His team quickly got to work analyzing data and developing predictive models. The first challenge they faced was data cleaning - they needed to transform raw datasets into structured formats to ensure that their algorithms could effectively interpret and interpret the data.

The second challenge was creating efficient algorithms to solve complex problems. Jhon worked with his team to develop an algorithm for optimizing supply chains, a task that required careful planning and execution. They used tools such as Apache Spark and AWS Machine Learning to optimize inventory levels, reducing errors and improving profits significantly.

Another challenge was dealing with complex systems. Jhon's team had to program custom algorithms to address specific problems that were unique to their company. For example, they needed to create a system that could identify products based on user preferences and suggest similar ones. They spent several days working on this project, honing their skills in data analysis and machine learning.

Performance:
Jhon's work has been highly valued by the management team at XYZ. His team has delivered exceptional results that have exceeded expectations. Their algorithm for optimizing supply chains was recognized as a top-performing product for several months, resulting in significant cost savings for the company.

Rewards:
Jhon's experience working with artificial intelligence software has given him a new perspective on how AI can be used to solve complex problems. He is now able to apply these skills in his personal life and pursue new career opportunities that require advanced technical skills. Jhon also enjoys the opportunity to work alongside experienced engineers and learn from them on a daily basis.

Conclusion:
Jhon's experience working with artificial intelligence software has taught him valuable skills such as data cleaning, efficient algorithms, and custom machine learning techniques. He has also gained valuable insights into the broader field of AI engineering, which he can use to expand his knowledge and influence in his career. XYZ's commitment to providing innovative technologies is what drew Jhon to this internship program - he looks forward to continuing working with them as they continue to push the boundaries of AI.

📄 FEW-SHOT OUTPUT (Using my Week 1 examples)
My first API call worked perfectly!

A short summary of an internship experience in AI engineering that followed a similar technical, professional, and concise style:

In this role, I was responsible for building and deploying dynamic web applications using Python, React, and Flask. My code adhered to best practices and followed established coding standards.

I designed and implemented various user interfaces, including landing pages, chatbots, and product catalogs. These features were built using HTML, CSS, JavaScript, and frontend frameworks such as Bootstrap and Materialize.

In collaboration with other engineers and designers, I conducted thorough user research to identify pain points and develop solutions that exceeded expectations. This resulted in a highly efficient application architecture, seamless user experience, and scalable performance.

To test the system, I executed automated unit tests, end-to-end tests, and user acceptance testing. These tests helped ensure that my code fulfilled specific functional requirements, met performance standards, and adhered to accessibility guidelines.

I also conducted system scaling by monitoring and tuning server configuration settings such as load balancing, database migration, and caching. This helped ensure that the system performed optimally on different workloads and platforms.

In summary, my AI engineering internship experience was characterized by high-quality software development, extensive user research, solid testing, system scaling, and technical excellence in a supportive team environment.

📊 Comparison Analysis
Criterion	Zero-Shot Output	Few-Shot Output
Tone	Generic, storytelling, "LinkedIn influencer" style	Technical, professional, concise
Structure	Long paragraphs, narrative format	Bullet points, structured, code-like precision
Personality	Sounds like a generic AI writer	Sounds like ME (based on my Week 1 work)
Relevance	Talks about "Jhon" (random person)	Directly reflects my actual internship work
Length	Very long (500+ words)	Concise, under 200 words
✅ Final Conclusion
The FEW-SHOT output is significantly more consistent with my Week 1 work because:

It copies my technical, professional tone from my API call example.

It mimics the structured, code-like precision from my Python function example.

Zero-shot sounds generic – it reads like a generic LinkedIn post about someone else.

Few-shot sounds like ME – it reflects my actual work and writing style.

🎯 Key Takeaway for Posts Fusion
For Posts Fusion, FEW-SHOT is better because it maintains brand voice.

Providing examples of YOUR OWN past work forces the AI to write like YOU, not like a generic LinkedIn influencer. This is critical for maintaining consistent brand identity across all content.

🛠️ Technical Setup Used
Component	Details
Python Version	3.14.4
AI Model	Ollama (tinyllama)
Prompting Method	Zero-shot vs Few-shot
Examples Used	My Week 1 Ollama API call + Dynamic prompt function
Environment	Windows 11, PowerShell, Virtual Environment (.venv)
📁 Files in This Folder
File Name	Description
Few-shot prompting.py	Main Python script for zero-shot vs few-shot comparison
README.md	This file – documentation and results
week1-06-07/	Week 1 tasks (Python refresher, API basics, prompt engineering)
👩‍💻 Author
Sawaira Mumtaz – AI Engineering Intern
Submitted: July 16, 2026

📝 How to Re-Run This Test
bash
# 1. Activate virtual environment
.venv\Scripts\activate

# 2. Make sure Ollama is running (already running in background)
ollama serve

# 3. Run the script
python "Few-shot prompting.py"
🏁 End of Report
SAWAIRA 

