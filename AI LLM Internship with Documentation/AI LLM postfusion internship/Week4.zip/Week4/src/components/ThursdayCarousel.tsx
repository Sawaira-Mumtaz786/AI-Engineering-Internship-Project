import React, { useState } from 'react';
import { Layers, ChevronLeft, ChevronRight, Sparkles, FileCode, CheckCircle, Lightbulb } from 'lucide-react';

interface ThursdayCarouselProps {
  ollamaUrl: string;
  model: string;
}

export const ThursdayCarousel: React.FC<ThursdayCarouselProps> = ({ ollamaUrl, model }) => {
  const [niche, setNiche] = useState('Career Coach');
  const [topic, setTopic] = useState('5 Networking Mistakes Holding Your Career Back');
  const [isGenerating, setIsGenerating] = useState(false);
  const [carouselContent, setCarouselContent] = useState<string | null>(null);
  const [currentSlide, setCurrentSlide] = useState(0);

  // Parse plain text slides
  const parseSlides = (text: string) => {
    const lines = text.split('\n').filter((l) => l.trim().length > 0);
    const slides: { number: number; title: string; body: string }[] = [];

    lines.forEach((line) => {
      const match = line.match(/^Slide\s*(\d+)[:\.-]?\s*(.*)/i) || line.match(/^(\d+)[\.\)]\s*(.*)/);
      if (match) {
        const slideNum = parseInt(match[1]);
        const content = match[2];
        const parts = content.split(' - ');
        slides.push({
          number: slideNum,
          title: parts[0] || `Slide ${slideNum}`,
          body: parts.slice(1).join(' - ') || content,
        });
      }
    });

    if (slides.length === 0) {
      // Fallback chunks if not cleanly formatted
      return [
        { number: 1, title: 'Slide 1: Title', body: text.slice(0, 150) },
        { number: 2, title: 'Slide 2: Main Point', body: text.slice(150, 300) },
        { number: 3, title: 'Slide 3: Key Insight', body: text.slice(300, 450) },
      ];
    }

    return slides;
  };

  const handleGenerateCarousel = async () => {
    setIsGenerating(true);
    setCarouselContent(null);
    setCurrentSlide(0);

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          niche,
          tone: 'engaging',
          topic,
          format: 'carousel',
          model,
          ollamaUrl,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setCarouselContent(data.content);
    } catch (err: any) {
      setCarouselContent(`Error: ${err.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Pre-loaded Test Carousels for Thursday Task Requirement 2
  const testCarousel1 = `Slide 1: 5 Networking Mistakes Keeping You Stuck - Why cold DMs and transactional asks fail in 2026.
Slide 2: Mistake #1: Asking for a job in the first message - Build rapport before asking for favors.
Slide 3: Mistake #2: Generic "I'd love to connect" invitations - Always personalize your connection note.
Slide 4: Mistake #3: Never giving value back - Share insightful articles, comment on their posts, or give genuine feedback.
Slide 5: Mistake #4: Ignoring peer networks - Your future boss or co-founder might be your current peer.
Slide 6: Mistake #5: Treating networking as a one-time transaction - Maintain relationships consistently over months.
Slide 7: The Fix: Shift from "What can I get?" to "How can I help?" - Reciprocity creates lasting career allies.
Slide 8: Which mistake have you seen most? Drop a comment below and let's discuss! #Networking #CareerGrowth`;

  const testCarousel2 = `Slide 1: How We Scaled SaaS Pricing Without Losing Customers - 4 strategic lessons from $0 to $1M ARR.
Slide 2: Lesson 1: Ditch cheap flat-rate pricing early - Usage-based tiers align value directly with revenue.
Slide 3: Lesson 2: Grandfather existing customers - Preserve loyalty while testing higher rates on new signups.
Slide 4: Lesson 3: Add an enterprise tier with custom SLAs - Large buyers want compliance and dedicated support.
Slide 5: Lesson 4: Test pricing changes every 6 months - Your product is worth far more now than at launch.
Slide 6: The Result: Increased ACV by 240% without increasing churn rate.
Slide 7: Key Takeaway: If nobody complains about your price, you are undercharging.
Slide 8: How often do you review your product pricing? Share your thoughts below! #SaaS #Pricing #Startups`;

  const activeSlides = carouselContent ? parseSlides(carouselContent) : parseSlides(testCarousel1);

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 mb-2">
          <Layers className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-bold text-white">Thursday Task: `--format carousel` & Spec Comparison</h2>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed max-w-3xl">
          Extends <code className="text-indigo-300 font-mono bg-slate-800 px-2 py-0.5 rounded">generate.py</code> with a <code className="text-indigo-300 font-mono bg-slate-800 px-2 py-0.5 rounded">--format carousel</code> option returning an 8-slide numbered list, and compares simple text outputs against Posts Fusion's production JSON schema.
        </p>
      </div>

      {/* Generator & Interactive Slide Reader */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs & Preset Launcher */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <h3 className="text-base font-semibold text-white flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-indigo-400" />
            <span>Generate 8-Slide Carousel</span>
          </h3>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Target Niche</label>
            <input
              type="text"
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Topic</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <button
            onClick={handleGenerateCarousel}
            disabled={isGenerating}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-medium text-xs py-2.5 rounded-xl transition flex items-center justify-center space-x-2"
          >
            {isGenerating ? 'Generating 8 Slides...' : 'Generate Carousel (--format carousel)'}
          </button>

          <div className="pt-4 border-t border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 font-semibold uppercase tracking-wider block">
              Thursday Test Carousels (Requirement 2):
            </span>
            <button
              onClick={() => {
                setCarouselContent(testCarousel1);
                setCurrentSlide(0);
              }}
              className="w-full text-left bg-slate-950 hover:bg-slate-800/80 border border-slate-800 p-2.5 rounded-xl text-xs text-slate-300 transition"
            >
              <strong className="text-indigo-400 block">Test 1: Career Coach</strong>
              <span className="text-[11px] text-slate-400">5 Networking Mistakes Holding Your Career Back</span>
            </button>

            <button
              onClick={() => {
                setCarouselContent(testCarousel2);
                setCurrentSlide(0);
              }}
              className="w-full text-left bg-slate-950 hover:bg-slate-800/80 border border-slate-800 p-2.5 rounded-xl text-xs text-slate-300 transition"
            >
              <strong className="text-emerald-400 block">Test 2: Tech Founder</strong>
              <span className="text-[11px] text-slate-400">Scaling SaaS Pricing Without Customer Churn</span>
            </button>
          </div>
        </div>

        {/* Right Preview Deck */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <span className="text-xs font-semibold text-slate-400">Interactive Slide Previewer</span>
            <span className="text-xs bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 px-2.5 py-0.5 rounded-full font-mono">
              Slide {currentSlide + 1} of {activeSlides.length}
            </span>
          </div>

          {/* Active Visual Slide Card */}
          <div className="bg-gradient-to-br from-indigo-950 via-slate-950 to-slate-900 border-2 border-indigo-500/40 rounded-2xl p-8 min-h-[260px] flex flex-col justify-between shadow-2xl relative">
            <div className="space-y-3">
              <span className="text-xs font-mono font-bold text-indigo-400 bg-indigo-500/20 px-3 py-1 rounded-full uppercase tracking-widest inline-block">
                Slide 0{activeSlides[currentSlide]?.number || currentSlide + 1}
              </span>
              <h4 className="text-xl font-extrabold text-white leading-tight">
                {activeSlides[currentSlide]?.title}
              </h4>
              <p className="text-slate-300 text-sm leading-relaxed pt-2">
                {activeSlides[currentSlide]?.body}
              </p>
            </div>

            <div className="flex justify-between items-center text-xs text-slate-500 pt-6 border-t border-slate-800/80">
              <span>Swipe or click arrows to read</span>
              <span>LinkedIn Carousel Format</span>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-6">
            <button
              onClick={() => setCurrentSlide((prev) => Math.max(0, prev - 1))}
              disabled={currentSlide === 0}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-white p-2.5 rounded-xl transition flex items-center space-x-1 text-xs"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous Slide</span>
            </button>

            <div className="flex space-x-1.5">
              {activeSlides.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentSlide(idx)}
                  className={`w-2.5 h-2.5 rounded-full transition-all ${
                    currentSlide === idx ? 'bg-indigo-500 w-6' : 'bg-slate-700'
                  }`}
                />
              ))}
            </div>

            <button
              onClick={() => setCurrentSlide((prev) => Math.min(activeSlides.length - 1, prev + 1))}
              disabled={currentSlide === activeSlides.length - 1}
              className="bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-white p-2.5 rounded-xl transition flex items-center space-x-1 text-xs"
            >
              <span>Next Slide</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Thursday Requirement 3: Posts Fusion Spec Comparison */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <div className="flex items-center space-x-3 mb-2">
          <FileCode className="w-6 h-6 text-indigo-400" />
          <h3 className="text-base font-bold text-white">
            Thursday Task 3: Simple Version vs. Posts Fusion Production Carousel JSON Spec
          </h3>
        </div>
        <p className="text-xs text-slate-300">
          Comparing our simple 8-slide plain text list against Nabeel's production Posts Fusion carousel engine schema.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* Simple Version */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
            <span className="font-bold text-indigo-400 uppercase tracking-wider block">
              1. Our Simple Script Version (Plain Text List)
            </span>
            <pre className="bg-slate-900 p-3 rounded-lg text-slate-300 font-mono text-[11px] overflow-x-auto">
{`Slide 1: [Hook Title] - [Short Body]
Slide 2: [Point 1] - [Short Body]
...
Slide 8: [CTA] - [Closing]`}</pre>
            <p className="text-slate-400 leading-relaxed">
              Unstructured plain text parsed via simple string regex. Lacks structural layout parameters, visual instructions, or explicit frontend rendering metadata.
            </p>
          </div>

          {/* Posts Fusion Spec */}
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 text-xs space-y-2">
            <span className="font-bold text-emerald-400 uppercase tracking-wider block">
              2. Posts Fusion Production Spec (Structured JSON)
            </span>
            <pre className="bg-slate-900 p-3 rounded-lg text-emerald-300 font-mono text-[11px] overflow-x-auto">
{`{
  "slides": [
    {
      "slide_number": 1,
      "headline": "Hook Title",
      "body_bullets": ["Point A", "Point B"],
      "layout_type": "split_hero",
      "visual_prompt": "Minimalist dark 3D icon",
      "cta_type": "comment_trigger"
    }
  ]
}`}</pre>
            <p className="text-slate-400 leading-relaxed">
              Strict JSON schema with structured typed fields required for automated PDF canvas rendering, custom fonts, and AI image generation APIs.
            </p>
          </div>
        </div>

        {/* 2 Key Differences Highlighted */}
        <div className="bg-indigo-950/40 border border-indigo-800/60 p-4 rounded-xl space-y-2 text-xs">
          <strong className="text-indigo-300 font-bold flex items-center">
            <Lightbulb className="w-4 h-4 mr-1.5 text-amber-400" />
            2 Primary Structural Differences Noted:
          </strong>
          <ul className="list-disc list-inside space-y-1.5 text-slate-300 pl-1 leading-relaxed">
            <li>
              <strong>Structured Types vs. String Parsing:</strong> Our simple version returns plain text strings requiring regex parsing, whereas the Posts Fusion production spec enforces strict JSON typing (<code className="text-indigo-300 font-mono">headline</code>, <code className="text-indigo-300 font-mono">body_bullets[]</code>) to eliminate parsing errors during automated PDF generation.
            </li>
            <li>
              <strong>Visual & Layout Metadata:</strong> The production spec includes rendering parameters such as <code className="text-indigo-300 font-mono">layout_type</code> (e.g. hero, comparison, quote) and <code className="text-indigo-300 font-mono">visual_prompt</code> for generating custom background images with Flux/Midjourney, which plain text lists cannot specify.
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
