📄 README.md 
markdown 
# Monday AI Internship Task: Python Refresher & API Basics

## 📌 Task Overview
This repository contains the completed Monday tasks for the AI Engineering Internship. The focus is on:

1. **Public API Call** – Fetching real-time weather data using the free `wttr.in` API.
2. **Local AI "API" Call** – Making a successful AI call using **Ollama** (100% free, no OpenAI API key required).
3. **Alternative Script** – Additional demonstration of the local Ollama AI call.

---

## 🛠️ Tech Stack
- **Language**: Python 3
- **Libraries**: `requests`, `json`, `ollama`
- **AI Model**: TinyLlama (via Ollama)
- **External API**: wttr.in (Weather)

---

## 📁 Files in This Repository
| File Name | Description |
| :--- | :--- |
| `weather_api.py` | Part 1: Calls the free `wttr.in` weather API and parses the JSON response for Islamabad. |
| `sawaira_monw1_python_api_basics.py` | Part 2: Simulates an "API call" using the local Ollama model (TinyLlama) to answer: "What is an API?" |
| `ollama_first_call.py` | Part 3: Alternative script demonstrating the same local Ollama AI call (optional). |
| `README.md` | This file – project documentation and setup guide. |

---

## 🗂️ Repository Structure
week1start/
├── weather_api.py # Part 1 : Public API call
├── sawaira_monw1_python_api_basics.py # Part 2 : Local AI call (Main file)
├── ollama_first_call.py # Part 3 : Alternative script (optional)
└── README.md # This file

text

---

## 🚀 How to Run This Project

### 1. Install Prerequisites
- Install [Python 3.10+](https://www.python.org/downloads/)
- Install [Ollama](https://ollama.ai/download) (free, local AI runtime)

### 2. Pull the AI Model
Open a terminal and run:
```bash
ollama pull tinyllama
3. Install Python Dependencies
bash
pip install requests ollama
4. Run the Scripts
Navigate to the project folder and execute:

bash
# Run the Weather API call (Part 1)
python weather_api.py

# Run the Local AI (Ollama) "API" call (Part 2)
python sawaira_monw1_python_api_basics.py

# Run the Alternative script (Part 3 - optional)
python ollama_first_call.py
📊 Sample Outputs
Weather API (weather_api.py) – Part 1
text
🌤️  Fetching weather for Islamabad...
📊 Weather Information:
📍 City: Islamabad
🌡️  Temperature: 32°C
☁️  Conditions: Partly cloudy
✅ Public API Call Complete!
Local AI Call (sawaira_monw1_python_api_basics.py) – Part 2
text
🤖 Sending request to Ollama (local AI)...
✅ Ollama Response:
An API (Application Programming Interface) is a set of rules that allows different software applications to communicate with each other.
💡 No API key needed - 100% FREE!
Alternative Script (ollama_first_call.py) – Part 3
text
🚀 OLLAMA API CALL (FREE - NO API KEY!)
🤖 Sending request to Ollama (local AI)...
✅ Ollama Response:
An API is a way for two software applications to talk to each other.
✅ Ollama API Call Complete!
💡 Why I Used Ollama Instead of OpenAI
The task originally suggested using the OpenAI API. However, I chose Ollama because:

100% Free – No API key required, no billing setup.

Privacy – Runs entirely locally on my machine.

Identical Logic – The structure of the call (model, messages, temperature) is exactly the same as OpenAI. Switching would simply require changing one line of code.

🎯 Learning Outcomes

Gained hands-on experience making HTTP requests to a public API.

Successfully made a "first API call" using a local open-source AI model.

Learned to parse JSON responses and extract meaningful information.

Understood the difference between calling a public API vs. a local AI model.

👩‍💻 Author
Sawaira Mumtaz – AI Engineering Intern

Submitted: Monday, July 6, 2026

