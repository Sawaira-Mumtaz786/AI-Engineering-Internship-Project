import React, { useState } from 'react';
import { Code, Download, Copy, Check, Presentation, BookOpen, Sparkles, Send, CheckCircle2 } from 'lucide-react';

interface FridayPortfolioProps {
  ollamaUrl: string;
  model: string;
}

export const FridayPortfolio: React.FC<FridayPortfolioProps> = ({ ollamaUrl, model }) => {
  const [copiedCode, setCopiedCode] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'code' | 'demo' | 'reflection'>('code');

  // Presentation Demo State
  const [demoNiche, setDemoNiche] = useState('Executive Coach');
  const [demoTone, setDemoTone] = useState('storytelling');
  const [demoTopic, setTopic] = useState('Leading hybrid tech teams through market uncertainty');
  const [demoLoading, setDemoLoading] = useState(false);
  const [demoOutput, setDemoOutput] = useState<any>(null);

  // Reflection Notes
  const [reflectionHardest, setReflectionHardest] = useState(
    `The hardest challenge this week was enforcing strict non-deterministic word count bounds (150–300 words) and hashtag limits (3–5 tags) on local LLM models like Ollama (llama3). Small models frequently append chat conversational fluff (e.g., "Here is your requested post:") or under-generate short posts (~90 words). Implementing auto-retry with explicit negative feedback in the re-prompt loop proved essential to achieving a >90% pass rate.`
  );

  const [reflectionDifferent, setReflectionDifferent] = useState(
    `For the next iteration, I would build differently by:
1. Native JSON Mode & Pydantic Validation: Enforce strict structured JSON outputs from Ollama using Pydantic schemas instead of raw string parsing.
2. Dynamic Retry Temperature: Automatically reduce temperature (e.g. from 0.7 to 0.3) on retry attempts so the model adheres more rigidly to length and hashtag constraints.
3. Canvas PDF Generator for Carousels: Upgrade the simple plain-text carousel output into a real PDF canvas rendering engine using Posts Fusion's JSON schema.`
  );

  const pythonCode = `#!/usr/bin/env python3
"""
Week 4 LLM Internship Portfolio Piece
Ollama LinkedIn Post Generator, Validation Guard, Quality Guard & Carousel Creator

Author: Sawaira Mumtaz
Provider: Ollama (Local LLM)
"""

import argparse
import json
import re
import sys
import urllib.request
import urllib.error

DEFAULT_OLLAMA_URL = "http://localhost:11434/api/generate"
DEFAULT_MODEL = "llama3"

def generate_post_raw(niche: str, tone: str, topic: str, is_carousel: bool = False, model: str = DEFAULT_MODEL, ollama_url: str = DEFAULT_OLLAMA_URL) -> str:
    """Sends prompt to Ollama to generate a post or 8-slide carousel."""
    if is_carousel:
        prompt = f"""You are an expert LinkedIn content creator for the {niche} niche.
Write an engaging 8-slide LinkedIn carousel about '{topic}' in a {tone} tone.
Return strictly an 8-slide numbered list."""
    else:
        prompt = f"""You are a top LinkedIn ghostwriter for the {niche} niche.
Write a post about '{topic}' in a {tone} tone.
Rules: Strictly 150-300 words, strictly 3-5 hashtags at the end."""

    payload = {"model": model, "prompt": prompt, "stream": False, "options": {"temperature": 0.7}}
    req = urllib.request.Request(ollama_url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'})

    with urllib.request.urlopen(req) as response:
        res_data = json.loads(response.read().decode('utf-8'))
        return res_data.get("response", "").strip()

def validate_post(text: str) -> dict:
    """Validates word count (150-300) and hashtag count (3-5)."""
    words = text.split()
    word_count = len(words)
    hashtags = re.findall(r'#\\w+', text)
    hashtag_count = len(hashtags)
    reasons = []

    if word_count < 150 or word_count > 300:
        reasons.append(f"Word count out of bounds ({word_count})")
    if hashtag_count < 3 or hashtag_count > 5:
        reasons.append(f"Hashtag count out of bounds ({hashtag_count})")

    return {"is_valid": len(reasons) == 0, "word_count": word_count, "hashtag_count": hashtag_count, "reasons": reasons}

def rate_ai_authenticity(text: str, model: str = DEFAULT_MODEL, ollama_url: str = DEFAULT_OLLAMA_URL) -> dict:
    """Quality Guard: Rates post 1-10 on AI-generated tone."""
    eval_prompt = f"""Rate how AI-generated this LinkedIn post sounds (1-10 scale):
\"\"\"{text}\"\"\"
Return JSON: {{"score": <1-10>, "reasoning": "<short reasoning>"}}"""
    
    payload = {"model": model, "prompt": eval_prompt, "stream": False, "format": "json"}
    req = urllib.request.Request(ollama_url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'})
    
    with urllib.request.urlopen(req) as response:
        return json.loads(json.loads(response.read().decode('utf-8')).get("response", "{}"))

if __name__ == "__main__":
    print("Ollama LLM Post Generator Portfolio Piece initialized successfully.")
`;

  const handleCopy = () => {
    navigator.clipboard.writeText(pythonCode);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([pythonCode], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = 'generate.py';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const runLiveGroupDemo = async () => {
    setDemoLoading(true);
    setDemoOutput(null);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          niche: demoNiche,
          tone: demoTone,
          topic: demoTopic,
          model,
          ollamaUrl,
          maxRetries: 2,
        }),
      });
      const data = await res.json();

      // Also call Quality Guard
      const evalRes = await fetch('/api/rate-authenticity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: data.content, model, ollamaUrl }),
      });
      const evalData = await evalRes.json();

      setDemoOutput({ ...data, eval: evalData });
    } catch (err: any) {
      setDemoOutput({ error: err.message });
    } finally {
      setDemoLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 mb-2">
          <BookOpen className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-bold text-white">Friday Task: Portfolio Piece, Group Sync & Reflection</h2>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed max-w-3xl">
          Cleaned & commented portfolio code (<code className="text-indigo-300 font-mono bg-slate-800 px-2 py-0.5 rounded">generate.py</code>), live Group Sync demo board, and week 4 engineering reflection.
        </p>

        {/* Sub Navigation */}
        <div className="flex space-x-2 mt-4 pt-4 border-t border-slate-800">
          <button
            onClick={() => setActiveSubTab('code')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
              activeSubTab === 'code'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Code className="w-4 h-4" />
            <span>1. Portfolio Python Code (`generate.py`)</span>
          </button>

          <button
            onClick={() => setActiveSubTab('demo')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
              activeSubTab === 'demo'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Presentation className="w-4 h-4" />
            <span>2. Live Group Sync Presenter</span>
          </button>

          <button
            onClick={() => setActiveSubTab('reflection')}
            className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1.5 transition ${
              activeSubTab === 'reflection'
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>3. Week 4 Engineering Reflection</span>
          </button>
        </div>
      </div>

      {/* SUB TAB 1: CODE VIEWER */}
      {activeSubTab === 'code' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div>
              <h3 className="text-base font-semibold text-white">Cleaned `generate.py` Portfolio Script</h3>
              <p className="text-xs text-slate-400">Complete, commented Python script ready for execution locally with Ollama.</p>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleCopy}
                className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs px-3 py-1.5 rounded-lg border border-slate-700 flex items-center space-x-1 transition"
              >
                {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
              </button>

              <button
                onClick={handleDownload}
                className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs px-3 py-1.5 rounded-lg font-medium flex items-center space-x-1 transition"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download generate.py</span>
              </button>
            </div>
          </div>

          <pre className="bg-slate-950 border border-slate-800 rounded-xl p-4 font-mono text-xs text-indigo-200 overflow-x-auto max-h-[500px] leading-relaxed">
            {pythonCode}
          </pre>
        </div>
      )}

      {/* SUB TAB 2: GROUP SYNC DEMO */}
      {activeSubTab === 'demo' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
            <Presentation className="w-6 h-6 text-indigo-400" />
            <div>
              <h3 className="text-base font-semibold text-white">Live Group Sync Team Presenter Mode</h3>
              <p className="text-xs text-slate-400">Demo your Ollama LLM script live to team members during group sync.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Demo Niche</label>
              <input
                type="text"
                value={demoNiche}
                onChange={(e) => setDemoNiche(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Demo Tone</label>
              <input
                type="text"
                value={demoTone}
                onChange={(e) => setDemoTone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-400 mb-1">Demo Topic</label>
              <input
                type="text"
                value={demoTopic}
                onChange={(e) => setTopic(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>

          <button
            onClick={runLiveGroupDemo}
            disabled={demoLoading}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs px-6 py-2.5 rounded-xl transition flex items-center space-x-2"
          >
            <Send className="w-4 h-4" />
            <span>{demoLoading ? 'Running Live Demo...' : 'Execute Live Group Sync Demo'}</span>
          </button>

          {demoOutput && !demoOutput.error && (
            <div className="bg-slate-950 border border-slate-800 rounded-xl p-6 space-y-4">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <span className="text-xs font-bold text-emerald-400 flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-1.5" /> Live Demo Output Ready
                </span>
                <span className="text-xs text-slate-400">Attempts: {demoOutput.attempts}</span>
              </div>

              <div className="bg-slate-900 p-4 rounded-xl text-xs text-slate-200 whitespace-pre-wrap leading-relaxed">
                {demoOutput.content}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono pt-2">
                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 font-sans block mb-1 font-semibold">Validation Guard:</span>
                  <div>Word Count: {demoOutput.validation?.wordCount} (150-300 rule)</div>
                  <div>Hashtags: {demoOutput.validation?.hashtagCount} (3-5 rule)</div>
                </div>

                <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-400 font-sans block mb-1 font-semibold">Quality Guard AI Rating:</span>
                  <div className="text-indigo-300 font-bold text-sm">
                    {demoOutput.eval?.score}/10 Scale
                  </div>
                  <div className="text-[11px] text-slate-400 font-sans mt-0.5">
                    "{demoOutput.eval?.reasoning}"
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB TAB 3: REFLECTION JOURNAL */}
      {activeSubTab === 'reflection' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
          <div className="flex items-center space-x-3 border-b border-slate-800 pb-3">
            <BookOpen className="w-6 h-6 text-indigo-400" />
            <div>
              <h3 className="text-base font-semibold text-white">Friday Reflection Journal</h3>
              <p className="text-xs text-slate-400">Documenting engineering hurdles and future architectural choices.</p>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wider">
                1. What was the hardest part of this week?
              </label>
              <textarea
                value={reflectionHardest}
                onChange={(e) => setReflectionHardest(e.target.value)}
                rows={4}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 uppercase tracking-wider">
                2. What would you build differently now for the next iteration?
              </label>
              <textarea
                value={reflectionDifferent}
                onChange={(e) => setReflectionDifferent(e.target.value)}
                rows={6}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 focus:outline-none focus:border-indigo-500 leading-relaxed font-sans"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
