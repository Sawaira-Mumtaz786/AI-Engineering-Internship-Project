import requests
import re
import time

# ==========================================
# YOUR UPDATED RESUME INFORMATION
# ==========================================
YOUR_NAME = "Sawaira Mumtaz"
YOUR_ROLE = "AI Engineering Intern"
YOUR_EDUCATION = "Bachelors in Computer Science (8th Semester) - Virtual University of Pakistan"
YOUR_SKILLS = ["Python", "C++", "Web Development", "React", "Nest.js", "Tkinter"]
YOUR_EXPERIENCE = [
    "AI Engineering Intern at Pro Fusion AI (July 2026 - Present)",
    "AI Engineering Intern at AL Basheer AI Solution (July 2026 - Present)",
    "Software Engineering Intern at Nicat (March 2026 - June 2026)"
]
YOUR_PROJECTS = [
    "Clothe Management System - Python Tkinter",
    "Notification Web App - React, Nest.js",
    "Portfolio Website - HTML, CSS"
]
YOUR_CERTIFICATIONS = ["C++", "Python", "Web App Development", "WordPress"]

# ==========================================
# CONFIGURATION
# ==========================================
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "tinyllama"  # Use tinyllama for speed

# ==========================================
# SYSTEM PROMPT WITH EXPLICIT CONSTRAINTS (Using YOUR Updated Resume)
# ==========================================
SYSTEM_PROMPT = f"""You are {YOUR_NAME}, an AI Engineering Intern sharing your career journey on LinkedIn.

CRITICAL RULES YOU MUST FOLLOW:
1. WORD COUNT: Your post MUST be between 150-300 words (excluding hashtags)
2. HASHTAGS: You MUST include exactly 3-5 hashtags at the end
3. HOOK: The FIRST LINE of your post MUST be a strong hook to grab attention
4. Write in a professional, engaging, conversational tone
5. Use YOUR REAL experience from your resume

Your background:
- {YOUR_EDUCATION}
- Skills: {', '.join(YOUR_SKILLS)}
- Experience: {', '.join(YOUR_EXPERIENCE)}
- Projects: {', '.join(YOUR_PROJECTS)}
- Certifications: {', '.join(YOUR_CERTIFICATIONS)}

If you don't follow these rules, your post will be rejected. Be careful.
"""

USER_PROMPT_TEMPLATE = """Write a LinkedIn post about {TOPIC} based on YOUR REAL experience.

Remember:
- First line MUST be a hook
- Total word count (excluding hashtags): 150-300 words
- Include 3-5 hashtags at the end
- Make it engaging and professional
- Use YOUR real journey and experience

Write the post now:"""

# Topics based on YOUR updated resume experience
TOPICS = [
    "My journey from Software Engineering Intern to AI Engineering Intern",
    "The #1 lesson I learned building AI agents at Pro Fusion AI",
    "How I'm using Python and React to build real-world applications",
    "What I learned from my AI Engineering internship at AL Basheer",
    "Why I'm pursuing AI Engineering while completing my CS degree"
]

# ==========================================
# VALIDATOR FUNCTION
# ==========================================
def validate_post(text):
    """
    Validates a LinkedIn post against platform constraints.
    Returns (passed, details_dict)
    """
    # Clean the text
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines[0].startswith("```"): lines = lines[1:]
        if lines and lines[-1].startswith("```"): lines = lines[:-1]
        text = "\n".join(lines).strip()
    
    # Check if empty
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    if not lines:
        return False, {"error": "Post content is empty"}
    
    # Rule 1: Hook on Line 1
    first_line = lines[0]
    hook_ok = not (
        first_line.startswith("[") or 
        first_line.startswith("# ") or 
        "here is" in first_line.lower() or
        first_line.startswith("ERROR") or
        first_line.startswith("[Insert")
    )
    
    # Rule 2: Hashtag count (3-5)
    hashtags = re.findall(r"#\w+", text)
    hashtag_count = len(hashtags)
    hashtag_ok = 3 <= hashtag_count <= 5
    
    # Rule 3: Word count (150-300)
    clean_text = text
    for tag in hashtags:
        clean_text = clean_text.replace(tag, "")
    words = [w for w in clean_text.split() if w]
    word_count = len(words)
    word_ok = 150 <= word_count <= 300
    
    # Overall pass/fail
    passed = hook_ok and hashtag_ok and word_ok
    
    return passed, {
        "word_count": word_count,
        "word_ok": word_ok,
        "hashtag_count": hashtag_count,
        "hashtag_ok": hashtag_ok,
        "hook_ok": hook_ok,
        "hashtags_found": hashtags,
        "hook_text": first_line[:50] + "..." if len(first_line) > 50 else first_line
    }

# ==========================================
# FUNCTION TO CALL OLLAMA
# ==========================================
def ask_ollama(topic):
    full_prompt = f"""{SYSTEM_PROMPT}

{USER_PROMPT_TEMPLATE.format(TOPIC=topic)}"""
    
    try:
        response = requests.post(OLLAMA_URL, json={
            "model": MODEL,
            "prompt": full_prompt,
            "stream": False,
            "options": {
                "temperature": 0.8,
                "num_predict": 700
            }
        }, timeout=120)  # Increased timeout
        return response.json()["response"].strip()
    except requests.exceptions.Timeout:
        return "ERROR: Ollama took too long. Please try again."
    except Exception as e:
        return f"ERROR: {e}"

# ==========================================
# RUN THE TEST
# ==========================================
print("=" * 70)
print("🧪 TESTING LINKEDIN CONSTRAINTS (5 POSTS USING YOUR UPDATED RESUME)")
print("=" * 70)
print(f"\n👤 Author: {YOUR_NAME}")
print(f"🎓 Education: {YOUR_EDUCATION}")
print(f"💼 Current Role: {YOUR_ROLE}")
print(f"💻 Experience: {', '.join(YOUR_EXPERIENCE[:2])}")
print("\n📌 CONSTRAINTS BEING TESTED:")
print("1. Hook on Line 1 ✅")
print("2. 150-300 words ✅")
print("3. 3-5 hashtags ✅")

results = []
failed_posts = []

for i, topic in enumerate(TOPICS, 1):
    print(f"\n" + "=" * 70)
    print(f"📝 POST {i}/5: {topic}")
    print("=" * 70)
    
    print("⏳ Generating...")
    post = ask_ollama(topic)
    
    print("\n📄 GENERATED POST:")
    print("-" * 50)
    print(post)
    print("-" * 50)
    
    # Validate the post
    passed, details = validate_post(post)
    
    # Display validation results
    print("\n📊 VALIDATION RESULTS:")
    print(f"   Word Count: {details.get('word_count')} (Requires 150-300) → {'✅' if details.get('word_ok') else '❌'}")
    print(f"   Hashtag Count: {details.get('hashtag_count')} (Requires 3-5) → {'✅' if details.get('hashtag_ok') else '❌'}")
    print(f"   Hook on Line 1: {'✅' if details.get('hook_ok') else '❌'}")
    print(f"   Overall: {'✅ PASSED' if passed else '❌ FAILED'}")
    
    if details.get('hashtags_found'):
        print(f"   Hashtags Found: {', '.join(details.get('hashtags_found', []))}")
    
    if not passed:
        print(f"   ❌ FAILED CONSTRAINTS:")
        if not details.get('word_ok'):
            print(f"      - Word count: {details.get('word_count')} (should be 150-300)")
        if not details.get('hashtag_ok'):
            print(f"      - Hashtag count: {details.get('hashtag_count')} (should be 3-5)")
        if not details.get('hook_ok'):
            print(f"      - Hook: First line is not a hook")
            print(f"      - First line: '{details.get('hook_text')}'")
        failed_posts.append({"topic": topic, "post": post, "details": details})
    
    results.append({"topic": topic, "passed": passed, "details": details})
    time.sleep(1)  # Small delay between requests

# ==========================================
# SUMMARY TABLE
# ==========================================
print("\n" + "=" * 70)
print("📊 SUMMARY: 5 POSTS TESTED USING YOUR UPDATED RESUME")
print("=" * 70)

print("\n┌─────┬──────────────────────────────────────┬──────────┬──────────┬──────────┬─────────┐")
print("│ No. │ Topic                                │ Words    │ Hashtags │ Hook     │ Passed  │")
print("├─────┼──────────────────────────────────────┼──────────┼──────────┼──────────┼─────────┤")

for i, result in enumerate(results, 1):
    topic_short = result['topic'][:30] + "..." if len(result['topic']) > 30 else result['topic']
    word_status = f"{result['details']['word_count']} ✅" if result['details']['word_ok'] else f"{result['details']['word_count']} ❌"
    hashtag_status = f"{result['details']['hashtag_count']} ✅" if result['details']['hashtag_ok'] else f"{result['details']['hashtag_count']} ❌"
    hook_status = "✅" if result['details']['hook_ok'] else "❌"
    passed_status = "✅" if result['passed'] else "❌"
    
    print(f"│ {i}   │ {topic_short:<36} │ {word_status:<8} │ {hashtag_status:<8} │ {hook_status:<8} │ {passed_status:<7} │")

print("└─────┴──────────────────────────────────────┴──────────┴──────────┴──────────┴─────────┘")

# ==========================================
# FAILURES REPORT
# ==========================================
if failed_posts:
    print("\n" + "=" * 70)
    print("❌ POSTS THAT IGNORED CONSTRAINTS (Common LLM Limitation)")
    print("=" * 70)
    
    print("\n📌 The model failed to follow all constraints in the following posts:")
    for i, failed in enumerate(failed_posts, 1):
        print(f"\n{i}. Topic: {failed['topic']}")
        print(f"   Word Count: {failed['details']['word_count']} (Required: 150-300)")
        print(f"   Hashtag Count: {failed['details']['hashtag_count']} (Required: 3-5)")
        print(f"   Hook on Line 1: {'✅' if failed['details']['hook_ok'] else '❌'}")
        print(f"   Violations:")
        if not failed['details']['word_ok']:
            print(f"      - WORD COUNT TOO {'SHORT' if failed['details']['word_count'] < 150 else 'LONG'}")
        if not failed['details']['hashtag_ok']:
            print(f"      - HASHTAG COUNT {'TOO FEW' if failed['details']['hashtag_count'] < 3 else 'TOO MANY'}")
        if not failed['details']['hook_ok']:
            print(f"      - NO HOOK ON LINE 1 (starts with: '{failed['details']['hook_text']}')")
else:
    print("\n" + "=" * 70)
    print("✅ ALL 5 POSTS PASSED!")
    print("=" * 70)
    print("The model successfully followed all constraints.")

# ==========================================
# CONCLUSION & LEARNING
# ==========================================
print("\n" + "=" * 70)
print("📝 CONCLUSION: WHY LLMs IGNORE CONSTRAINTS")
print("=" * 70)

print("""
This test reveals a REAL, COMMON limitation of LLMs:

🔴 THE PROBLEM:
LLMs (like tinyllama) often forget or ignore explicit constraints 
provided in the prompt, especially when:
- The prompt is long (they lose track)
- The constraint is "negative" (e.g., "Don't do X")
- There are multiple constraints (they prioritize one over others)
- The model is small (less context window, less reasoning ability)

🟡 WHAT WE OBSERVED FROM YOUR UPDATED RESUME POSTS:
- Some posts were TOO SHORT (under 150 words)
- Some posts had TOO FEW hashtags
- Some posts failed to put the hook on line 1
- The model sometimes generated placeholder text instead of real content

💡 HOW Posts Fusion SOLVES THIS:
1. Use a VALIDATOR (like the one in this script) to check every output
2. If validation fails, RE-PROMPT or RETRY the generation
3. Use LARGER MODELS (llama3, mistral) for better constraint adherence
4. Keep constraints SIMPLE and at the BEGINNING of the prompt
5. Use SYSTEM PROMPTS (not just user prompts) for better results

🏆 KEY TAKEAWAY:
Never trust an LLM to follow rules perfectly. ALWAYS validate the output.
This is why the Posts Fusion pipeline has a Step 3 validator – it's essential!

📌 SPECIFIC TO YOUR UPDATED RESUME:
The model struggled to generate posts based on YOUR actual experience because:
- It doesn't know your specific story – it generates generic content
- It needs more detailed examples to understand your unique journey
- Few-shot prompting (showing examples) would improve results significantly
- Your experience as an AI Engineering Intern is recent and specific
""")

print("\n" + "=" * 70)
print("✅ TEST COMPLETE!")
print("=" * 70)