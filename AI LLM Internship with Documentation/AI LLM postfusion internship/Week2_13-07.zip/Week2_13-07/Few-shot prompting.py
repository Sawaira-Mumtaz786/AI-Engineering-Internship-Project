import requests
import re

# ==========================================
# YOUR 2 EXAMPLES FROM WEEK 1 WORK
# ==========================================

# EXAMPLE 1: Your successful Ollama API call (from Tuesday)
MY_EXAMPLE_1 = """
My very first API call works perfectly!
"""

# EXAMPLE 2: Your dynamic prompt function (from Thursday)
MY_EXAMPLE_2 = """
def build_dynamic_prompt(niche, tone):
    tone_descriptions = {
        "professional": "Professional, polished, and business-like.",
        "casual": "Casual, conversational, and friendly.",
        "inspirational": "Inspirational, motivational, and uplifting.",
        "raw": "Raw, honest, and vulnerable.",
        "opinionated": "Opinionated, direct, and slightly controversial.",
        "educational": "Educational, informative, and practical."
    }
    niche_descriptions = {
        "coach": "A business or life coach who helps people achieve their goals.",
        "founder": "A SaaS founder who has built a company from the ground up.",
        "recruiter": "A recruiter who helps companies find and hire top talent."
    }
    return system_prompt, user_prompt
"""

# ==========================================
# SETUP
# ==========================================

def ask_ollama(prompt):
    response = requests.post("http://localhost:11434/api/generate", json={
        "model": "tinyllama",  # Use tinyllama for speed
        "prompt": prompt,
        "stream": False,
        "options": {"temperature": 0.8, "num_predict": 700}
    })
    return response.json()["response"].strip()

TOPIC = "AI Engineering Internship Experience"

print("🚀 ZERO-SHOT vs FEW-SHOT COMPARISON (Using YOUR Week 1 work as examples)")

# ZERO SHOT (No examples)
print("\n⏳ Generating ZERO-SHOT output...")
zero_prompt = f"Write a short summary about {TOPIC}. Keep it under 100 words."
zero_output = ask_ollama(zero_prompt)

# FEW SHOT (Using YOUR 2 examples)
print("⏳ Generating FEW-SHOT output...")
few_prompt = f"""
Here are 2 examples of my work style from Week 1:

--- EXAMPLE 1 (My API call) ---
{MY_EXAMPLE_1}

--- EXAMPLE 2 (My Python function) ---
{MY_EXAMPLE_2}

Now write a short summary about {TOPIC} using the SAME concise, technical, and professional tone as my examples.
Keep it under 100 words.
"""
few_output = ask_ollama(few_prompt)

print("\n" + "="*60)
print("📄 ZERO-SHOT OUTPUT:")
print("="*60)
print(zero_output)

print("\n" + "="*60)
print("📄 FEW-SHOT OUTPUT (Using YOUR Week 1 examples):")
print("="*60)
print(few_output)

print("\n" + "="*60)
print("✅ CONCLUSION:")
print("="*60)
print("The FEW-SHOT output is more consistent with my Week 1 work because:")
print("1. It copies my technical, professional tone from my API call")
print("2. It mimics the structured, code-like precision from my Python function")
print("3. Zero-shot sounds generic; Few-shot sounds like ME")
print("\nFor Posts Fusion, FEW-SHOT is better because it maintains brand voice.")