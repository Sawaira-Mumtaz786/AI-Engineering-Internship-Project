import React, { useState } from 'react';
import { Sparkles, Play, RefreshCw, CheckCircle2, Copy, FileText, Send } from 'lucide-react';

interface MondayGeneratorProps {
  ollamaUrl: string;
  model: string;
}

interface TestCombination {
  id: number;
  niche: string;
  tone: string;
  topic: string;
  status: 'idle' | 'generating' | 'completed' | 'error';
  content?: string;
  wordCount?: number;
  hashtagCount?: number;
  error?: string;
}

export const MondayGenerator: React.FC<MondayGeneratorProps> = ({ ollamaUrl, model }) => {
  // Single custom generator state
  const [niche, setNiche] = useState('Career Coach');
  const [tone, setTone] = useState('storytelling');
  const [topic, setTopic] = useState('Overcoming imposter syndrome when transitioning into AI engineering');
  const [isGeneratingSingle, setIsGeneratingSingle] = useState(false);
  const [singleResult, setSingleResult] = useState<string | null>(null);

  // Monday Task 3: 6 mandatory test combinations
  const [tests, setTests] = useState<TestCombination[]>([
    { id: 1, niche: 'Executive Coach', tone: 'storytelling', topic: 'Overcoming imposter syndrome in senior management', status: 'idle' },
    { id: 2, niche: 'Tech Founder', tone: 'bold', topic: 'Why bootstrapper mindset beats high-burn VC funding', status: 'idle' },
    { id: 3, niche: 'Growth Marketer', tone: 'analytical', topic: 'How zero-click search is changing content distribution', status: 'idle' },
    { id: 4, niche: 'Software Engineer', tone: 'educational', topic: 'Top 3 mistake developers make with LLM function calling', status: 'idle' },
    { id: 5, niche: 'Product Designer', tone: 'inspirational', topic: 'The art of micro-interactions in modern SaaS design', status: 'idle' },
    { id: 6, niche: 'Tech Recruiter', tone: 'direct', topic: 'How to structure your resume for AI screening filters', status: 'idle' },
  ]);

  const runSingleGeneration = async () => {
    setIsGeneratingSingle(true);
    setSingleResult(null);
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ niche, tone, topic, format: 'post', model, ollamaUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed');
      setSingleResult(data.content);
    } catch (err: any) {
      setSingleResult(`Error: ${err.message}`);
    } finally {
      setIsGeneratingSingle(false);
    }
  };

  const runTestIndex = async (idx: number) => {
    setTests((prev) =>
      prev.map((t, i) => (i === idx ? { ...t, status: 'generating', error: undefined } : t))
    );

    const t = tests[idx];
    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ niche: t.niche, tone: t.tone, topic: t.topic, format: 'post', model, ollamaUrl }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Generation failed');

      const wordCount = data.content.split(/\s+/).length;
      const hashtagCount = (data.content.match(/#\w+/g) || []).length;

      setTests((prev) =>
        prev.map((item, i) =>
          i === idx
            ? { ...item, status: 'completed', content: data.content, wordCount, hashtagCount }
            : item
        )
      );
    } catch (err: any) {
      setTests((prev) =>
        prev.map((item, i) =>
          i === idx ? { ...item, status: 'error', error: err.message } : item
        )
      );
    }
  };

  const runAll6Tests = async () => {
    for (let i = 0; i < tests.length; i++) {
      await runTestIndex(i);
    }
  };

  return (
    <div className="space-y-8">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-slate-800 rounded-2xl p-6 shadow-md">
        <div className="flex items-center space-x-3 mb-2">
          <FileText className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-bold text-white">Monday Task: Core `generate_post` Function</h2>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed max-w-3xl">
          Build a clean, reusable function <code className="text-indigo-300 bg-slate-800 px-2 py-0.5 rounded font-mono">generate_post(niche, tone, topic)</code> that returns an engaging LinkedIn-style post, accepts CLI arguments, and is evaluated against at least 6 distinct combinations.
        </p>
      </div>

      {/* Single Live Generator Test */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
        <h3 className="text-base font-semibold text-white flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-indigo-400" />
          <span>Interactive Single Post Generator</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Target Niche</label>
            <input
              type="text"
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Coach, Founder, Marketer"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Tone of Voice</label>
            <select
              value={tone}
              onChange={(e) => setTone(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="storytelling">storytelling</option>
              <option value="bold & provocative">bold & provocative</option>
              <option value="analytical & data-driven">analytical & data-driven</option>
              <option value="educational step-by-step">educational step-by-step</option>
              <option value="vulnerable & authentic">vulnerable & authentic</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">Topic</label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
              placeholder="e.g. Imposter syndrome, AI trends"
            />
          </div>
        </div>

        <button
          onClick={runSingleGeneration}
          disabled={isGeneratingSingle}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-medium text-xs px-5 py-2.5 rounded-xl transition flex items-center space-x-2"
        >
          {isGeneratingSingle ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Generating Post with Ollama...</span>
            </>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Generate Post Now</span>
            </>
          )}
        </button>

        {singleResult && (
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 mt-4 text-sm text-slate-200 whitespace-pre-wrap leading-relaxed">
            <div className="flex justify-between items-center mb-3 pb-2 border-b border-slate-800 text-xs text-slate-400">
              <span className="font-semibold text-indigo-400">LinkedIn Post Result</span>
              <span>Word Count: {singleResult.split(/\s+/).length}</span>
            </div>
            {singleResult}
          </div>
        )}
      </div>

      {/* 6 Mandatory Test Combinations Suite */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-white">6-Combination Test Suite (Mandatory Requirement 3)</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Run and verify 6 distinct niche/tone/topic matrix tests as required by Monday's task specification.
            </p>
          </div>

          <button
            onClick={runAll6Tests}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs px-4 py-2 rounded-xl transition flex items-center space-x-2 self-start sm:self-auto"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Run All 6 Combination Tests</span>
          </button>
        </div>

        {/* 6 Grid Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {tests.map((t, idx) => (
            <div
              key={t.id}
              className="bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded">
                    Test #{t.id}
                  </span>
                  {t.status === 'completed' && (
                    <span className="text-xs text-emerald-400 flex items-center font-medium">
                      <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Done ({t.wordCount} words)
                    </span>
                  )}
                  {t.status === 'generating' && (
                    <span className="text-xs text-amber-400 flex items-center">
                      <RefreshCw className="w-3.5 h-3.5 mr-1 animate-spin" /> Running...
                    </span>
                  )}
                </div>

                <div className="text-xs text-slate-300 space-y-1 mb-3">
                  <p><strong className="text-slate-400">Niche:</strong> {t.niche}</p>
                  <p><strong className="text-slate-400">Tone:</strong> {t.tone}</p>
                  <p className="line-clamp-2"><strong className="text-slate-400">Topic:</strong> "{t.topic}"</p>
                </div>

                {t.content && (
                  <div className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-[11px] text-slate-300 max-h-36 overflow-y-auto whitespace-pre-wrap leading-relaxed mb-3">
                    {t.content}
                  </div>
                )}

                {t.error && (
                  <div className="bg-rose-950/40 border border-rose-800 text-rose-300 text-xs p-2 rounded-lg mb-3">
                    {t.error}
                  </div>
                )}
              </div>

              <button
                onClick={() => runTestIndex(idx)}
                disabled={t.status === 'generating'}
                className="w-full bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-medium text-xs py-1.5 rounded-lg transition"
              >
                {t.status === 'generating' ? 'Running...' : t.status === 'completed' ? 'Re-run Test' : 'Run Test'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
