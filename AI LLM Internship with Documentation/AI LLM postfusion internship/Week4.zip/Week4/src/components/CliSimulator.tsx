import React, { useState } from 'react';
import { Terminal, Play, Copy, Check, Sparkles, AlertCircle } from 'lucide-react';

interface CliSimulatorProps {
  ollamaUrl: string;
  model: string;
}

export const CliSimulator: React.FC<CliSimulatorProps> = ({ ollamaUrl, model }) => {
  const [cliInput, setCliInput] = useState(
    "python generate.py --niche coach --tone story --topic 'imposter syndrome' --eval"
  );
  const [isRunning, setIsRunning] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  const presets = [
    { label: 'Monday Post (Coach / Story)', cmd: "python generate.py --niche coach --tone story --topic 'imposter syndrome'" },
    { label: 'Tuesday Validation & Retry', cmd: "python generate.py --niche 'tech founder' --tone bold --topic 'AI agents replacing developers'" },
    { label: 'Wednesday Quality Guard (1-10)', cmd: "python generate.py --niche marketer --tone analytical --topic 'SEO in 2026' --eval" },
    { label: 'Thursday Carousel', cmd: "python generate.py --niche 'career coach' --tone inspirational --topic '5 networking mistakes' --format carousel" },
  ];

  const runCommand = async (commandToRun?: string) => {
    const cmd = commandToRun || cliInput;
    setIsRunning(true);
    setLogs([
      `$ ${cmd}`,
      `[INFO] Initializing Ollama post generator (Model: ${model})...`,
      `[INFO] Connecting to local endpoint: ${ollamaUrl}...`,
    ]);

    // Parse command arguments manually
    const nicheMatch = cmd.match(/--niche (?:'([^']+)'|"([^"]+)"|(\S+))/);
    const toneMatch = cmd.match(/--tone (?:'([^']+)'|"([^"]+)"|(\S+))/);
    const topicMatch = cmd.match(/--topic (?:'([^']+)'|"([^"]+)"|(\S+))/);
    const formatMatch = cmd.match(/--format (\w+)/);
    const evalRequested = cmd.includes('--eval');

    const niche = nicheMatch ? (nicheMatch[1] || nicheMatch[2] || nicheMatch[3]) : 'coach';
    const tone = toneMatch ? (toneMatch[1] || toneMatch[2] || toneMatch[3]) : 'story';
    const topic = topicMatch ? (topicMatch[1] || topicMatch[2] || topicMatch[3]) : 'imposter syndrome';
    const format = formatMatch ? formatMatch[1] : 'post';

    try {
      setLogs((prev) => [...prev, `[INFO] Requesting completion for Niche: "${niche}", Tone: "${tone}", Format: "${format}"`]);

      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          niche,
          tone,
          topic,
          format,
          model,
          ollamaUrl,
          maxRetries: 2,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Generation failed');
      }

      const newLogs = [
        `\n============================================================`,
        `🚀 OLLAMA LINKEDIN GENERATOR | Niche: ${data.niche} | Tone: ${data.tone}`,
        `📌 Topic: "${data.topic}" | Format: ${data.format}`,
        `============================================================\n`,
        `--- GENERATED OUTPUT ---`,
        data.content,
        `-------------------------\n`,
      ];

      if (format !== 'carousel' && data.validation) {
        newLogs.push(`📊 DAY 2 VALIDATION METRICS:`);
        newLogs.push(`  • Attempts Made: ${data.attempts}`);
        newLogs.push(`  • Word Count: ${data.validation.wordCount} (Rule: 150-300 words)`);
        newLogs.push(`  • Hashtags (${data.validation.hashtagCount}): ${data.validation.hashtags.join(', ')} (Rule: 3-5)`);
        newLogs.push(`  • Status: ${data.validation.isValid ? '✅ PASSED' : '❌ FAILED'}`);
        if (data.validation.reasons && data.validation.reasons.length > 0) {
          newLogs.push(`  • Rule Failures: ${data.validation.reasons.join(', ')}`);
        }
        newLogs.push('');
      }

      if (evalRequested) {
        newLogs.push(`🔍 DAY 3 QUALITY GUARD EVALUATION:`);
        newLogs.push(`  • Contacting LLM AI Detector model...`);

        const evalRes = await fetch('/api/rate-authenticity', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            content: data.content,
            model,
            ollamaUrl,
          }),
        });
        const evalData = await evalRes.json();
        newLogs.push(`  • AI Sounding Score: ${evalData.score}/10 (1 = Natural Human, 10 = Obvious AI)`);
        newLogs.push(`  • Reasoning: ${evalData.reasoning}`);
      }

      newLogs.push(`\n[SUCCESS] Script executed cleanly with exit code 0.`);
      setLogs((prev) => [...prev, ...newLogs]);
    } catch (err: any) {
      setLogs((prev) => [
        ...prev,
        `❌ ERROR: ${err.message}`,
        `💡 Check that Ollama is running ('ollama serve') or check server logs.`,
      ]);
    } finally {
      setIsRunning(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(logs.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 mb-2">
          <Terminal className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-bold text-white">Interactive CLI Terminal Simulator</h2>
        </div>
        <p className="text-slate-400 text-sm">
          Run your <code className="text-indigo-300 font-mono bg-slate-800 px-2 py-0.5 rounded">generate.py</code> script exactly as required for Week 4 Monday–Thursday CLI tasks.
        </p>

        {/* Preset Command Buttons */}
        <div className="mt-4 flex flex-wrap gap-2">
          <span className="text-xs text-slate-400 self-center font-medium mr-2">Quick Presets:</span>
          {presets.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => {
                setCliInput(preset.cmd);
                runCommand(preset.cmd);
              }}
              className="text-xs bg-slate-800 hover:bg-slate-700 text-indigo-300 border border-slate-700 hover:border-indigo-500 px-3 py-1.5 rounded-lg transition"
            >
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      {/* Command Input Box */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
        <label className="block text-xs font-semibold text-slate-400 mb-2 uppercase tracking-wider">
          Command Line Input
        </label>
        <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-xl p-2 focus-within:border-indigo-500 transition">
          <span className="text-emerald-400 font-mono text-sm pl-2">$</span>
          <input
            type="text"
            value={cliInput}
            onChange={(e) => setCliInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && !isRunning && runCommand()}
            placeholder="python generate.py --niche coach --tone story --topic 'imposter syndrome' --eval"
            className="w-full bg-transparent text-slate-100 font-mono text-sm focus:outline-none"
          />
          <button
            onClick={() => runCommand()}
            disabled={isRunning}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 text-white font-medium text-xs px-4 py-2 rounded-lg transition flex items-center space-x-1.5 shrink-0"
          >
            {isRunning ? (
              <>
                <span className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Running...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Run Command</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Output Console */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl font-mono text-xs text-slate-200">
        <div className="bg-slate-900 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-rose-500/80" />
            <div className="w-3 h-3 rounded-full bg-amber-500/80" />
            <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
            <span className="text-slate-400 text-xs pl-2 font-sans font-medium">stdout / Terminal Logs</span>
          </div>
          {logs.length > 0 && (
            <button
              onClick={handleCopy}
              className="text-slate-400 hover:text-white transition flex items-center space-x-1 text-xs"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Output'}</span>
            </button>
          )}
        </div>

        <div className="p-4 max-h-[500px] overflow-y-auto space-y-1.5 whitespace-pre-wrap leading-relaxed">
          {logs.length === 0 ? (
            <div className="text-slate-500 italic text-center py-12">
              Ready to execute. Click "Run Command" or choose a preset above.
            </div>
          ) : (
            logs.map((log, i) => {
              if (log.startsWith('$')) {
                return <div key={i} className="text-emerald-400 font-bold">{log}</div>;
              } else if (log.includes('✅ PASSED') || log.includes('SUCCESS')) {
                return <div key={i} className="text-emerald-300 font-semibold">{log}</div>;
              } else if (log.includes('❌ FAILED') || log.includes('ERROR')) {
                return <div key={i} className="text-rose-400 font-semibold">{log}</div>;
              } else if (log.includes('QUALITY GUARD') || log.includes('METRICS')) {
                return <div key={i} className="text-indigo-400 font-bold">{log}</div>;
              }
              return <div key={i} className="text-slate-300">{log}</div>;
            })
          )}
        </div>
      </div>
    </div>
  );
};
