import requests
import time

# ==========================================
# YOUR RESUME INFORMATION (From Sawairaintern.pdf)
# ==========================================
YOUR_NAME = "Sawaira Mumtaz"
YOUR_ROLE = "Computer Science Student & AI Engineering Intern"
YOUR_SKILLS = ["Python", "C++", "Web Development", "AI Content Generation", "Cybersecurity"]
YOUR_EXPERIENCE = [
    "Customer Service Representative at IbeX Dynamic (Aug 2024 - Jan 2025)",
    "Data Management Intern at Diya Pakistan Organization (Nov 2022 - Jan 2023)",
    "Computer Science Teacher at Lighthouse School System (Aug 2023 - Aug 2024)",
    "Verification Specialist at Next Gen Technology (Nov 2025 - Feb 2026)"
]
YOUR_EDUCATION = "Bachelors in Computer Science (8th Semester) - Virtual University of Pakistan"
YOUR_CERTIFICATIONS = ["Ethical Hacking", "Web Penetration Testing", "Python & C++", "AI Content Generation", "Freelancing"]

FIXED_NICHE = "AI Engineering & Career Growth"

# ==========================================
# CONFIGURATION
# ==========================================
OLLAMA_URL = "http://localhost:11434/api/generate"
MODEL = "tinyllama"  # Use tinyllama for speed

def ask_ollama(system_prompt, user_prompt):
    full_prompt = f"""System: {system_prompt}

User: {user_prompt}

Generate the LinkedIn post:"""
    
    try:
        response = requests.post(OLLAMA_URL, json={
            "model": MODEL,
            "prompt": full_prompt,
            "stream": False,
            "options": {
                "temperature": 0.8,
                "num_predict": 700
            }
        }, timeout=60)
        return response.json()["response"].strip()
    except Exception as e:
        return f"ERROR: {e}"

# ==========================================
# TONE 1: DIRECT & DATA-DRIVEN
# ==========================================
TONE_1_SYSTEM = f"""You are {YOUR_NAME}, a data-driven Computer Science student and AI intern.
Your writing style is:
- Direct, assertive, and confident
- Uses specific numbers, percentages, and metrics
- No fluff, no storytelling
- Short punchy sentences
- Backs every claim with data
- Sounds like a consultant or analyst

Your background:
- {YOUR_EDUCATION}
- Skills: {', '.join(YOUR_SKILLS)}
- Experience: {', '.join(YOUR_EXPERIENCE)}
- Certifications: {', '.join(YOUR_CERTIFICATIONS)}

Use your REAL experience as examples."""

TONE_1_USER_1 = f"""Write a LinkedIn post about why 90% of CS students fail to transition into AI roles. 
Use specific data points. Keep it under 150 words. Direct and punchy. 
Use your real experience as an example."""

TONE_1_USER_2 = f"""Write a LinkedIn post about the #1 mistake interns make in AI Engineering. 
Include a specific statistic. Keep it under 150 words. No fluff. 
Reference your internship experience."""

# ==========================================
# TONE 2: STORY-DRIVEN & PERSONAL
# ==========================================
TONE_2_SYSTEM = f"""You are {YOUR_NAME}, a vulnerable CS student and AI intern who shares real stories.
Your writing style is:
- Personal, emotional, and relatable
- Uses "I" and "my" frequently
- Shares real struggles, failures, and lessons
- Conversational and human
- Builds connection through vulnerability
- Sounds like a friend sharing over coffee

Your background:
- {YOUR_EDUCATION}
- Worked as Customer Service Rep, Teacher, Verification Specialist
- Currently an AI Intern
- Learning Python, C++, and AI Content Generation

Use your REAL struggles and growth as examples."""

TONE_2_USER_1 = f"""Write a LinkedIn post about a painful lesson you learned while transitioning from Customer Service to AI Engineering.
Share a personal story. Keep it under 150 words. Be vulnerable and honest.
Use your REAL experience."""

TONE_2_USER_2 = f"""Write a LinkedIn post about the moment you almost gave up on your AI Engineering journey.
Tell the story. Keep it under 150 words. Make it emotional and real.
Use your REAL experience."""

# ==========================================
# TONE 3: EDUCATIONAL & FRAMEWORK-BASED
# ==========================================
TONE_3_SYSTEM = f"""You are {YOUR_NAME}, an AI educator who teaches frameworks.
Your writing style is:
- Step-by-step, structured, and instructional
- Uses bullet points, numbers, or clear steps
- Teaches a specific framework or method
- Practical and actionable
- Sounds like a teacher giving a lesson
- Ends with a clear takeaway

Your background:
- Taught Computer Science at Lighthouse School System
- Certified in Ethical Hacking, Python, C++
- AI Content Generation experience
- Currently pursuing BCS

Use your REAL teaching experience as examples."""

TONE_3_USER_1 = f"""Write a LinkedIn post teaching a 3-step framework for transitioning into AI Engineering as a CS student.
Use bullet points. Keep it under 150 words. Make it actionable.
Reference your own journey."""

TONE_3_USER_2 = f"""Write a LinkedIn post explaining the 4 pillars of successful AI Engineering internship.
Use numbered steps. Keep it under 150 words. Educational and clear.
Use your real internship experience."""

# ==========================================
# GENERATE ALL 6 POSTS
# ==========================================
print("=" * 70)
print("🚀 GENERATING 6 POSTS USING YOUR RESUME")
print(f"📌 Author: {YOUR_NAME}")
print(f"📌 Fixed Niche: {FIXED_NICHE}")
print("=" * 70)

# Store all posts
all_posts = {}

# ---- TONE 1: Direct & Data-Driven ----
print("\n" + "=" * 70)
print("📊 TONE 1: DIRECT & DATA-DRIVEN")
print("=" * 70)

print("\n⏳ Generating Post 1/6...")
post_1_1 = ask_ollama(TONE_1_SYSTEM, TONE_1_USER_1)
print("\n📄 POST 1 (Direct & Data-Driven):")
print("-" * 50)
print(post_1_1)

print("\n⏳ Generating Post 2/6...")
post_1_2 = ask_ollama(TONE_1_SYSTEM, TONE_1_USER_2)
print("\n📄 POST 2 (Direct & Data-Driven):")
print("-" * 50)
print(post_1_2)

# ---- TONE 2: Story-Driven & Personal ----
print("\n" + "=" * 70)
print("📖 TONE 2: STORY-DRIVEN & PERSONAL")
print("=" * 70)

print("\n⏳ Generating Post 3/6...")
post_2_1 = ask_ollama(TONE_2_SYSTEM, TONE_2_USER_1)
print("\n📄 POST 3 (Story-Driven & Personal):")
print("-" * 50)
print(post_2_1)

print("\n⏳ Generating Post 4/6...")
post_2_2 = ask_ollama(TONE_2_SYSTEM, TONE_2_USER_2)
print("\n📄 POST 4 (Story-Driven & Personal):")
print("-" * 50)
print(post_2_2)

# ---- TONE 3: Educational & Framework-Based ----
print("\n" + "=" * 70)
print("🎓 TONE 3: EDUCATIONAL & FRAMEWORK-BASED")
print("=" * 70)

print("\n⏳ Generating Post 5/6...")
post_3_1 = ask_ollama(TONE_3_SYSTEM, TONE_3_USER_1)
print("\n📄 POST 5 (Educational & Framework-Based):")
print("-" * 50)
print(post_3_1)

print("\n⏳ Generating Post 6/6...")
post_3_2 = ask_ollama(TONE_3_SYSTEM, TONE_3_USER_2)
print("\n📄 POST 6 (Educational & Framework-Based):")
print("-" * 50)
print(post_3_2)

# ==========================================
# TASK 3: 1 SENTENCE PER TONE
# ==========================================
print("\n" + "=" * 70)
print("📝 TASK 3: 1 SENTENCE PER TONE")
print("=" * 70)

print("""
✅ DIRECT & DATA-DRIVEN:
"This tone is recognisable by its use of specific numbers, percentages, and 
assertive declarative statements that leave no room for ambiguity, often 
citing real metrics from the author's own career data."

✅ STORY-DRIVEN & PERSONAL:
"This tone is recognisable by its intimate use of 'I' and 'my', emotional 
vulnerability about failures, and a conversational narrative that builds 
connection through shared struggle and honest reflection."

✅ EDUCATIONAL & FRAMEWORK-BASED:
"This tone is recognisable by its structured step-by-step layout, numbered 
or bulleted frameworks, and practical actionable advice that guides the 
reader toward a concrete outcome."
""")

# ==========================================
# COMPARISON TABLE
# ==========================================
print("\n" + "=" * 70)
print("📊 TONE COMPARISON TABLE")
print("=" * 70)

print(f"""
┌─────────────────────────────┬──────────────────────────────────────────────────────┐
│ TONE                        │ WHAT MAKES IT RECOGNISABLE                         │
├─────────────────────────────┼──────────────────────────────────────────────────────┤
│ Direct & Data-driven        │ Numbers, percentages, assertive statements,         │
│                             │ no fluff, consultant-like analyst tone.            │
│                             │ Example from your resume: "90% of CS students..."  │
├─────────────────────────────┼──────────────────────────────────────────────────────┤
│ Story-driven & Personal     │ "I" and "my", emotional language, vulnerability,    │
│                             │ real failures, conversational flow.               │
│                             │ Example from your resume: "My transition from      │
│                             │ Customer Service to AI Engineering..."             │
├─────────────────────────────┼──────────────────────────────────────────────────────┤
│ Educational & Framework-based│ Bullet points, numbered steps, frameworks,         │
│                             │ actionable advice, teacher-like tone.              │
│                             │ Example from your resume: "3 steps to transition   │
│                             │ into AI Engineering as a CS student"              │
└─────────────────────────────┴──────────────────────────────────────────────────────┘
""")