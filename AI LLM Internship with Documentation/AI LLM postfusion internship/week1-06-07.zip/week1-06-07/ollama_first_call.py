"""
PART 3: OLLAMA API CALL (FREE - NO API KEY NEEDED!)
Using Ollama to simulate an "API call" - completely free and local
"""

import ollama
import json

def make_ollama_call():
    """
    Make a "API call" using Ollama (Free, Local, No API Key)
    This is your "first successful API call" using Ollama!
    """
    
    try:
        print("🤖 Sending request to Ollama (local AI)...")
        
        # This is the "API Call" using Ollama
        response = ollama.chat(
            model="tinyllama",  # Use tinyllama, phi3.5, or gemma3
            messages=[
                {"role": "system", "content": "You are a helpful AI assistant."},
                {"role": "user", "content": "What is an API? Explain in one sentence for a beginner."}
            ]
        )
        
        return response
        
    except Exception as e:
        return {"error": str(e)}

def extract_response_info(response):
    """Extract useful information from the Ollama response"""
    
    if isinstance(response, dict) and "error" in response:
        return response
    
    try:
        return {
            "model": response.get("model", "unknown"),
            "content": response.get("message", {}).get("content", ""),
            "total_duration": response.get("total_duration", 0)
        }
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    print("=" * 60)
    print("🚀 OLLAMA API CALL (FREE - NO API KEY!)")
    print("=" * 60)
    
    # Make the "API Call"
    response = make_ollama_call()
    
    # Extract info
    result = extract_response_info(response)
    
    if "error" in result:
        print(f"❌ Error: {result['error']}")
    else:
        print(f"\n✅ Ollama Response:")
        print("-" * 40)
        print(result["content"])
        
        print("\n📝 Raw JSON Response:")
        print("-" * 40)
        # Pretty print the JSON
        print(json.dumps(response, indent=2, default=str))
    
    print("\n✅ Ollama API Call Complete!")
    print("💡 No API key needed - 100% FREE!")