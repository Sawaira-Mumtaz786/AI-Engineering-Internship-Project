"""
PART 1: PYTHON REFRESHER
- Functions
- Dictionaries
- JSON handling
"""

import json

# 1. FUNCTIONS
def greet_user(name, role="Intern"):
    return f"Hello {name}! Welcome to your {role} role."

print("--- FUNCTIONS ---")
print(greet_user("Sawaira"))
print(greet_user("Sawaira", "AI Engineer"))
print()

# 2. DICTIONARIES
person = {
    "name": "Sawaira",
    "role": "AI Intern",
    "skills": ["Python", "Prompt Engineering", "API Integration"],
    "completed_tasks": 3
}

print("--- DICTIONARIES ---")
print(f"Name: {person['name']}")
print(f"Role: {person['role']}")
print(f"Skills: {', '.join(person['skills'])}")
print(f"Tasks Completed: {person['completed_tasks']}")
print()

# 3. JSON HANDLING
python_data = {
    "task": "API Basics",
    "day": "Monday",
    "completed": True,
    "topics": ["Functions", "Dictionaries", "JSON", "APIs"]
}

json_string = json.dumps(python_data, indent=2)
print("--- JSON SERIALIZATION ---")
print(json_string)
print()

# JSON string -> Python dict
json_data = '{"name": "Sawaira", "task": "API Call", "status": "success"}'
python_dict = json.loads(json_data)
print("--- JSON DESERIALIZATION ---")
print(f"Name: {python_dict['name']}")
print(f"Task: {python_dict['task']}")
print(f"Status: {python_dict['status']}")
print()

# 4. PRACTICE: Combine everything
def process_user_data(user_dict):
    name = user_dict.get("name", "Unknown")
    role = user_dict.get("role", "No Role")
    skills_count = len(user_dict.get("skills", []))
    
    return {
        "summary": f"{name} is a {role} with {skills_count} skills",
        "skills_list": user_dict.get("skills", []),
        "is_intern": "Intern" in role
    }

result = process_user_data(person)
print("--- COMBINED PRACTICE ---")
print(f"Summary: {result['summary']}")
print(f"Is Intern? {result['is_intern']}")
print()

print("✅ Python Refresher Complete!")