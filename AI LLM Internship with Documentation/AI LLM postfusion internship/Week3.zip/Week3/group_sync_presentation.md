# Group Sync: Week 3 Presentation

**Presenter:** Sawaira Mumtaz
**Date:** July 23, 2026
**Audience:** Nabeel, Abdul Ahad, and Team

---

## 🎯 What I Learned This Week

### 1. Embeddings = Text → Numbers

> "A list of numbers that captures meaning"

**Example:**
- "I love pizza" → [0.2, 0.8, -0.3, 0.5]
- Similar sentences → Similar numbers

---

### 2. Cosine Similarity = How Similar

**Results from my test:**

| Sentences | Similarity |
| :--- | :--- |
| "I love pizza" vs "Pizza is my favorite" | 0.89 |
| "I love pizza" vs "I enjoy Italian food" | 0.72 |
| "I love pizza" vs "The weather is beautiful" | 0.12 |

**Conclusion:** Similar meaning = High score (0.72-0.89)

---

### 3. Content Fingerprint in Action

**How it works:**
User Draft → Embedding → Pinecone → Top 3 Similar


---

### 4. Why Pinecone (Not a List)

| **List** | **Pinecone** |
| :--- | :--- |
| Slow for big data | Fast (milliseconds) |
| Can't scale | Scales to billions |
| No built-in search | Built-in cosine search |

---

## 🎤 Key Takeaways for the Team

1. **Embeddings capture meaning** – Not just keywords
2. **Similarity search is fast** – Millisecond response
3. **Pinecone scales** – Supports millions of posts
4. **Content Fingerprint works** – Saves hours of searching