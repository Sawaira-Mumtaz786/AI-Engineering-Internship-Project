"""
DAY 1: First Embedding
Task: Generate your first embedding using Ollama
"""

import requests

print("=" * 60)
print("📚 DAY 1: FIRST EMBEDDING")
print("=" * 60)

# Test sentence
sentence = "Vector embeddings turn text into numbers that capture meaning."

print(f"\n📝 Sentence: '{sentence}'")

try:
    response = requests.post(
        "http://localhost:11434/api/embeddings",
        json={"model": "nomic-embed-text", "prompt": sentence},
        timeout=30
    )
    
    embedding = response.json().get("embedding", [])
    
    if embedding:
        print(f"\n✅ Embedding generated successfully!")
        print(f"\n📊 Vector Length: {len(embedding)} numbers")
        print(f"\n🔢 First 5 numbers: {embedding[:5]}")
        
        print("\n📋 Full Embedding (first 20 numbers for preview):")
        print("-" * 40)
        print(embedding[:20])
    else:
        print("\n❌ No embedding generated.")
        
except Exception as e:
    print(f"\n❌ ERROR: {e}")
    print("Make sure Ollama is running. Type: ollama serve")

print("\n" + "=" * 60)
print("✅ DAY 1 COMPLETE!")
print("=" * 60)

print("\n📝 My 3 Sentences on Embeddings:")
print("1. An embedding is a list of numbers that captures the meaning of a piece of text, similar to how coordinates on a map capture the location of a building.")
print("2. The numbers in an embedding are not random – they are calculated by an AI model so that similar sentences have similar numbers, allowing computers to understand semantic relationships.")
print("3. Embeddings enable AI to compare, search, and cluster content by meaning rather than just matching keywords, which powers everything from search engines to recommendation systems.")