import React, { useState } from 'react';
import { Eye, ShieldAlert, Sparkles, RefreshCw, ThumbsUp, ThumbsDown, MessageSquare } from 'lucide-react';

interface WednesdayQualityGuardProps {
  ollamaUrl: string;
  model: string;
}

interface SavedOutputEval {
  id: number;
  niche: string;
  topic: string;
  content: string;
  aiScore: number | null;
  aiReasoning: string | null;
  humanScore: number; // 1-10 slider
  isEvaluating: boolean;
}

export const WednesdayQualityGuard: React.FC<WednesdayQualityGuardProps> = ({ ollamaUrl, model }) => {
  // Pre-loaded saved outputs from earlier testing
  const [outputs, setOutputs] = useState<SavedOutputEval[]>([
    {
      id: 1,
      niche: 'Coach',
      topic: 'Imposter Syndrome',
      content: `I almost canceled my talk last week. Why? Because the voice in my head whispered, "You're not ready."

In today's fast-paced corporate world, imposter syndrome is a tapestry woven into executive life.

Here are 3 ways to overcome it:
1. Reframe fear as readiness.
2. Track your small wins daily.
3. Speak with a mentor.

Remember, perfection is a myth. Embrace the journey! #CareerGrowth #Leadership #Mindset #Coaching #Success`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 8, // User human score
      isEvaluating: false,
    },
    {
      id: 2,
      niche: 'Tech Founder',
      topic: 'Bootstrapping vs VC',
      content: `VCs offered us $2M. We said no.

Everyone thought we were crazy. "How can you turn down capital in 2026?"

Here is what they didn't see:
• We had 82% gross margins.
• We were profitable from Month 4.
• We wanted 100% decision autonomy.

Raising venture capital is not a badge of honor. Profitability is.

Build products customers pay for, not slide decks investors pitch. #Startups #Bootstrapping #Entrepreneurship #SaaS`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 2,
      isEvaluating: false,
    },
    {
      id: 3,
      niche: 'Growth Marketer',
      topic: 'Zero-Click Search',
      content: `Google is no longer sending you traffic.

With AI Overviews and snippet answers, 62% of searches end without a click.

If your strategy relies on traditional SEO, you're building on shifting sand.

What works now:
- Zero-click native content on LinkedIn & X.
- Owned email newsletters.
- Brand affinity over keyword stuffing.

Adapt or get left behind. #Marketing #SEO #ContentStrategy #Growth`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 4,
      isEvaluating: false,
    },
    {
      id: 4,
      niche: 'Software Engineer',
      topic: 'LLM Function Calling',
      content: `Most devs use LLM function calling completely wrong.

They pass loose JSON schemas and pray the model adheres to types.

The solution?
Use strict Zod schemas with server-side validation. Never trust LLM outputs without runtime guardrails.

Let's delve deeper into schema enforcement tomorrow. #SoftwareEngineering #AI #TypeScript #Coding`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 7,
      isEvaluating: false,
    },
    {
      id: 5,
      niche: 'Product Designer',
      topic: 'Micro-interactions',
      content: `Micro-interactions are the secret sauce of memorable UX.

A subtle tactile haptic, a 150ms spring animation, or a satisfying checkmark state.

It's the difference between software that feels clunky and software that feels magical.

Focus on the details that delight. #Design #UX #ProductDesign #UI`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 5,
      isEvaluating: false,
    },
    {
      id: 6,
      niche: 'Recruiter',
      topic: 'AI Resume Filters',
      content: `Stop sending fancy 2-column PDF resumes.

Applicant Tracking Systems (ATS) ruin parsing when you use tables and graphics.

Keep it simple:
- Single column layout.
- Standard headings (Experience, Education).
- Clear metric-driven bullet points.

Your career deserves to be read. #Recruiting #CareerAdvice #Jobs #Hiring`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 3,
      isEvaluating: false,
    },
    {
      id: 7,
      niche: 'Data Scientist',
      topic: 'Local LLMs',
      content: `Running Llama 3 locally on Apple Silicon is a game-changer.

In today's landscape, privacy matters more than raw cloud compute.

Here's my setup:
1. Ollama server instance
2. Quantized Q4_K_M model
3. 24GB unified memory

Zero API costs, complete data privacy. #DataScience #AI #Ollama #MachineLearning`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 8,
      isEvaluating: false,
    },
    {
      id: 8,
      niche: 'Finance Lead',
      topic: 'Startup Cashflow',
      content: `Cash runway is oxygen for your startup.

If you don't know your exact monthly burn rate, you're flying blind.

Calculate:
Runway (Months) = Total Cash / Monthly Net Burn

Keep at least 18 months of runway in reserve during market slowdowns. #Finance #Startups #CFO #Business`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 3,
      isEvaluating: false,
    },
    {
      id: 9,
      niche: 'Cybersecurity Specialist',
      topic: 'Zero Trust Security',
      content: `Trust no one. Verify everything.

That is the core philosophy of Zero Trust architecture.

In a hybrid work era, perimeter security is dead. Every request must be authenticated, authorized, and encrypted. #Cybersecurity #Infosec #IT #Security`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 4,
      isEvaluating: false,
    },
    {
      id: 10,
      niche: 'Career Mentor',
      topic: 'Asking for a Raise',
      content: `Don't ask for a raise based on your expenses. Ask based on your impact.

Bring a brag sheet documenting:
- Revenue generated
- Processes automated
- Projects delivered on time

Data wins negotiations. #CareerAdvice #Mentorship #Workplace #Growth`,
      aiScore: null,
      aiReasoning: null,
      humanScore: 2,
      isEvaluating: false,
    },
  ]);

  const evaluateSingle = async (idx: number) => {
    setOutputs((prev) =>
      prev.map((o, i) => (i === idx ? { ...o, isEvaluating: true } : o))
    );

    const item = outputs[idx];

    try {
      const res = await fetch('/api/rate-authenticity', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: item.content,
          model,
          ollamaUrl,
        }),
      });
      const data = await res.json();

      setOutputs((prev) =>
        prev.map((o, i) =>
          i === idx
            ? {
                ...o,
                aiScore: data.score ?? 5,
                aiReasoning: data.reasoning ?? 'Evaluation complete',
                isEvaluating: false,
              }
            : o
        )
      );
    } catch (err: any) {
      setOutputs((prev) =>
        prev.map((o, i) =>
          i === idx
            ? {
                ...o,
                aiScore: 5,
                aiReasoning: `Error: ${err.message}`,
                isEvaluating: false,
              }
            : o
        )
      );
    }
  };

  const evaluateAll10 = async () => {
    for (let i = 0; i < outputs.length; i++) {
      await evaluateSingle(i);
    }
  };

  const updateHumanScore = (idx: number, val: number) => {
    setOutputs((prev) =>
      prev.map((o, i) => (i === idx ? { ...o, humanScore: val } : o))
    );
  };

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 mb-2">
          <Eye className="w-6 h-6 text-indigo-400" />
          <h2 className="text-xl font-bold text-white">Wednesday Task: Quality Guard (AI Authenticity Rating)</h2>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed max-w-3xl">
          Adds a second LLM evaluation call asking: <code className="text-indigo-300 font-mono bg-slate-800 px-2 py-0.5 rounded">"rate how AI-generated this sounds, 1–10"</code> (Posts Fusion Quality Guard). Compares AI scores against human judgment to analyze agreement & disagreement.
        </p>

        {/* Legend */}
        <div className="mt-4 flex flex-wrap items-center gap-4 text-xs font-medium">
          <span className="text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded">
            Score 1 - 3: Human & Authentic
          </span>
          <span className="text-amber-400 bg-amber-500/10 border border-amber-500/30 px-2.5 py-1 rounded">
            Score 4 - 6: Neutral / Mild AI Signals
          </span>
          <span className="text-rose-400 bg-rose-500/10 border border-rose-500/30 px-2.5 py-1 rounded">
            Score 7 - 10: Obvious AI Cliches ("delve", "tapestry", "fast-paced")
          </span>
        </div>
      </div>

      {/* Main Container */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-white">10-Post Quality Guard Evaluation Matrix</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Run Ollama AI Detector on 10 saved posts and compare with your Human score.
            </p>
          </div>

          <button
            onClick={evaluateAll10}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-xs px-5 py-2.5 rounded-xl transition flex items-center space-x-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>Rate All 10 Posts with Ollama</span>
          </button>
        </div>

        {/* 10 Items Cards */}
        <div className="space-y-4">
          {outputs.map((item, idx) => {
            const delta = item.aiScore !== null ? Math.abs(item.aiScore - item.humanScore) : 0;
            const hasDisagreement = item.aiScore !== null && delta >= 3;

            return (
              <div
                key={item.id}
                className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-3 hover:border-slate-700 transition"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-800/80">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-indigo-400 bg-indigo-500/10 px-2.5 py-0.5 rounded">
                      Post #{item.id}
                    </span>
                    <span className="text-xs font-semibold text-slate-300">{item.niche}</span>
                    <span className="text-xs text-slate-500">• {item.topic}</span>
                  </div>

                  <button
                    onClick={() => evaluateSingle(idx)}
                    disabled={item.isEvaluating}
                    className="text-xs bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 px-3 py-1 rounded-lg transition self-start sm:self-auto flex items-center space-x-1"
                  >
                    {item.isEvaluating ? (
                      <>
                        <RefreshCw className="w-3 h-3 animate-spin mr-1" />
                        <span>Evaluating...</span>
                      </>
                    ) : (
                      <span>{item.aiScore !== null ? 'Re-Evaluate AI' : 'Run Quality Guard'}</span>
                    )}
                  </button>
                </div>

                {/* Content text */}
                <div className="text-xs text-slate-300 bg-slate-900/60 p-3.5 rounded-lg whitespace-pre-wrap leading-relaxed font-sans border border-slate-800">
                  {item.content}
                </div>

                {/* Scores & Comparison Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  {/* Human Rating Input */}
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                    <div className="flex justify-between items-center text-xs mb-1">
                      <span className="text-slate-400 font-medium">Your Human Score:</span>
                      <strong className="text-white text-sm">{item.humanScore}/10</strong>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="10"
                      value={item.humanScore}
                      onChange={(e) => updateHumanScore(idx, Number(e.target.value))}
                      className="w-full accent-indigo-500 cursor-pointer"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                      <span>1 (Human)</span>
                      <span>10 (AI)</span>
                    </div>
                  </div>

                  {/* AI Quality Guard Score */}
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
                    <div className="flex justify-between items-center text-xs">
                      <span className="text-slate-400 font-medium">Ollama Quality Guard Score:</span>
                      {item.aiScore !== null ? (
                        <strong className={`text-sm font-bold ${
                          item.aiScore <= 3 ? 'text-emerald-400' : item.aiScore <= 6 ? 'text-amber-400' : 'text-rose-400'
                        }`}>
                          {item.aiScore}/10
                        </strong>
                      ) : (
                        <span className="text-slate-500 italic">Not rated</span>
                      )}
                    </div>
                    {item.aiReasoning && (
                      <p className="text-[11px] text-slate-400 mt-1 italic line-clamp-2">
                        "{item.aiReasoning}"
                      </p>
                    )}
                  </div>

                  {/* Agreement / Delta */}
                  <div className="bg-slate-900 p-3 rounded-lg border border-slate-800 flex flex-col justify-between">
                    <span className="text-xs text-slate-400 font-medium">Agreement / Delta Analysis</span>
                    {item.aiScore !== null ? (
                      <div>
                        {hasDisagreement ? (
                          <div className="flex items-center space-x-1.5 text-amber-400 text-xs font-semibold mt-1">
                            <ShieldAlert className="w-4 h-4" />
                            <span>Disagreement (Delta: {delta} pts)</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-1.5 text-emerald-400 text-xs font-semibold mt-1">
                            <ThumbsUp className="w-4 h-4" />
                            <span>Strong Agreement (Delta: {delta} pts)</span>
                          </div>
                        )}
                        <p className="text-[10px] text-slate-400 mt-1">
                          {hasDisagreement
                            ? 'Human and AI disagree on cliche density or list structure.'
                            : 'Human and AI align closely on writing tone.'}
                        </p>
                      </div>
                    ) : (
                      <span className="text-xs text-slate-500 italic mt-1">Run Quality Guard to compare</span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
