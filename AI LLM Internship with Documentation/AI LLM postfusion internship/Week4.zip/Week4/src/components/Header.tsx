import React, { useState, useEffect } from 'react';
import { Terminal, Cpu, CheckCircle, AlertTriangle, RefreshCw, Sparkles, BookOpen } from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  ollamaUrl: string;
  setOllamaUrl: (url: string) => void;
  model: string;
  setModel: (m: string) => void;
  ollamaOnline: boolean | null;
  checkOllama: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  ollamaUrl,
  setOllamaUrl,
  model,
  setModel,
  ollamaOnline,
  checkOllama,
}) => {
  const [showConfig, setShowConfig] = useState(false);

  const tabs = [
    { id: 'cli', label: '💻 CLI Simulator' },
    { id: 'monday', label: '📅 Mon: Core Post Script' },
    { id: 'tuesday', label: '🛡️ Tue: Validation & Retry' },
    { id: 'wednesday', label: '🔍 Wed: Quality Guard (AI 1-10)' },
    { id: 'thursday', label: '🎠 Thu: Carousel Generator' },
    { id: 'friday', label: '📝 Fri: Portfolio & Reflection' },
  ];

  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand / Title */}
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-tr from-indigo-600 to-violet-500 p-2 rounded-xl text-white shadow-lg shadow-indigo-500/20">
              <Terminal className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="font-bold text-lg text-slate-100 tracking-tight">Ollama LLM Post Studio</h1>
                <span className="text-xs bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-semibold px-2 py-0.5 rounded-full">
                  Week 4 Internship
                </span>
              </div>
              <p className="text-xs text-slate-400">Building Local LLM Post Generator, Quality Guard & Carousels</p>
            </div>
          </div>

          {/* Ollama Status & Config Controls */}
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowConfig(!showConfig)}
              className="flex items-center space-x-2 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 px-3 py-1.5 rounded-lg transition"
            >
              <Cpu className="w-4 h-4 text-indigo-400" />
              <span>Model: <strong className="text-white">{model}</strong></span>
              <span className="text-slate-500">|</span>
              {ollamaOnline === true ? (
                <span className="flex items-center text-emerald-400 font-medium">
                  <CheckCircle className="w-3.5 h-3.5 mr-1" /> Ollama Connected
                </span>
              ) : ollamaOnline === false ? (
                <span className="flex items-center text-amber-400 font-medium">
                  <AlertTriangle className="w-3.5 h-3.5 mr-1" /> Cloud Hybrid Mode
                </span>
              ) : (
                <span className="flex items-center text-slate-400">
                  <RefreshCw className="w-3.5 h-3.5 mr-1 animate-spin" /> Checking...
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Collapsible Connection Config */}
        {showConfig && (
          <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 my-2 text-xs grid grid-cols-1 md:grid-cols-3 gap-4 shadow-xl">
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Ollama Endpoint URL</label>
              <input
                type="text"
                value={ollamaUrl}
                onChange={(e) => setOllamaUrl(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono focus:outline-none focus:border-indigo-500"
                placeholder="http://localhost:11434/api/generate"
              />
            </div>
            <div>
              <label className="block text-slate-400 mb-1 font-medium">Ollama / Local Model</label>
              <select
                value={model}
                onChange={(e) => setModel(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono focus:outline-none focus:border-indigo-500"
              >
                <option value="llama3">llama3 (Default)</option>
                <option value="llama3.2">llama3.2</option>
                <option value="mistral">mistral</option>
                <option value="qwen2.5">qwen2.5</option>
                <option value="phi3">phi3</option>
                <option value="custom">Custom Model</option>
              </select>
            </div>
            <div className="flex items-end justify-between">
              <button
                onClick={checkOllama}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-4 py-1.5 rounded-lg transition flex items-center space-x-1"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Test Connection</span>
              </button>
              <p className="text-[11px] text-slate-400 max-w-[200px]">
                Note: If local Ollama is offline, calls automatically fall back to Gemini cloud LLM for seamless demo testing.
              </p>
            </div>
          </div>
        )}

        {/* Navigation Tabs */}
        <nav className="flex space-x-1 overflow-x-auto pb-2 scrollbar-none border-t border-slate-800/80 pt-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30 font-semibold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </div>
    </header>
  );
};
