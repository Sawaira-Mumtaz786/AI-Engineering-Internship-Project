# Week 2: LinkedIn Algorithm Rules & LLM Constraint Testing (Using Updated Resume)

**Date:** July 16, 2026
**Student:** Sawaira Mumtaz
**Environment:** Windows 11, PowerShell, Python 3.14, Ollama (tinyllama)
**Script:** "constraint_test.py"

## 📌 Task Overview

| **Step** | **What to Do** |
| :--- | :--- |
| **1** | Learn why LinkedIn algorithm rules matter (150-300 words, 3-5 hashtags, hook on line 1) |
| **2** | Add these constraints explicitly into prompts and verify the model follows them |
| **3** | Note any outputs that ignored the constraints (real LLM limitation) |

---

## 👤 Source Material: MY Updated Resume

All generated posts are based on **my actual updated resume information**:

| **Category** | **Details** |
| :--- | :--- |
| **Name** | Sawaira Mumtaz |
| **Current Role** | AI Engineering Intern at Pro Fusion AI & AL Basheer AI Solution |
| **Education** | Bachelors in Computer Science (8th Semester) - Virtual University of Pakistan |
| **Skills** | Python, C++, Web Development, React, Nest.js, Tkinter |
| **Recent Experience** | Software Engineering Intern at Nicat (Mar-Jun 2026), AI Engineering Intern at Pro Fusion AI (Current), AI Engineering Intern at AL Basheer AI Solution (Current) |
| **Projects** | Clothe Management System (Python Tkinter), Notification Web App (React, Nest.js), Portfolio Website (HTML, CSS) |
| **Certifications** | C++, Python, Web App Development, WordPress |

---

## 📋 The 3 Critical LinkedIn Rules

| **Rule** | **Requirement** | **Why It Matters** |
| :--- | :--- | :--- |
| **Word Count** | 150-300 words | LinkedIn prioritizes "dwell time" – longer posts keep people reading |
| **Hashtags** | 3-5 hashtags | Optimal reach without looking spammy |
| **Hook** | Hook on Line 1 | First 1-2 lines determine if people click "see more" |

---

## 🧪 Test Methodology

1. **Added explicit constraints** to the system prompt (150-300 words, 3-5 hashtags, hook on line 1)
2. **Generated 5 posts** on topics based on MY updated resume using Ollama (tinyllama)
3. **Validated each post** manually using a validator function (word count, hashtag count, hook check)
4. **Recorded failures** – posts that ignored the constraints

### Topics Tested (Based on MY Resume)

| **Post** | **Topic** |
| :--- | :--- |
| 1 | My journey from Software Engineering Intern to AI Engineering Intern |
| 2 | The #1 lesson I learned building AI agents at Pro Fusion AI |
| 3 | How I'm using Python and React to build real-world applications |
| 4 | What I learned from my AI Engineering internship at AL Basheer |
| 5 | Why I'm pursuing AI Engineering while completing my CS degree |

---

## 📊 Results Summary

### Overview Table

| **No.** | **Topic** | **Words** | **Hashtags** | **Hook** | **Passed** |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | My journey from Software Engin... | 325 ❌ | 0 ❌ | ✅ | ❌ |
| 2 | The #1 lesson I learned buildi... | 447 ❌ | 0 ❌ | ❌ | ❌ |
| 3 | How I'm using Python and React... | 441 ❌ | 0 ❌ | ✅ | ❌ |
| 4 | What I learned from my AI Engi... | 450 ❌ | 0 ❌ | ❌ | ❌ |
| 5 | Why I'm pursuing AI Engineerin... | 429 ❌ | 0 ❌ | ✅ | ❌ |

### Key Statistics

| **Metric** | **Value** |
| :--- | :--- |
| Total Posts Generated | 5 |
| Posts That Passed ALL Constraints | **0** |
| Posts That Failed at Least One Constraint | **5 (100%)** |
| Posts That Failed Word Count Rule | **5 (100%)** |
| Posts That Failed Hashtag Rule | **5 (100%)** |
| Posts That Failed Hook Rule | **2 (40%)** |

---

## 📄 Detailed Post Analysis

---

### POST 1: My journey from Software Engineering Intern to AI Engineering Intern

**Generated Post:**
Hey [LinkedIn Company],

I'm excited to share my journey from a Software Engineering Intern at Pro Fujiyah AI to an AI Engineering Intern at AL Basheer AI Solution.

As a computer science undergraduate, I was fascinated by the world of Artificial Intelligence (AI) and had dreams of becoming a renowned AI engineer one day. With hard work, dedication, and passion for my field, I have made tremendous progress over the past few years in my journey as an AI Engineering Intern.

During my time at Pro Fujiyah AI, I worked on several projects related to Natural Language Processing (NLP) and Machine Learning (ML). I helped design and implement a sentiment analysis system that can identify and categorize customer reviews in real-time using NLP techniques. Additionally, I developed an ML model that accurately predicted customer lifespan based on their demographic data and historical purchase history.

In my spare time, I have also been working on developing a new AI-powered platform for event planning and management. This project involved creating a user-friendly interface, designing custom AI algorithms, and integrating it with existing software systems to automate the process of event planning.

Looking back at my past experiences as an AI Engineering Intern, I have come to realize that success is not just about developing great software but also about being a resourceful problem solver and possessing excellent communication skills.

Overall, I am proud of the progress made during my time as an AI Engineering Intern at Pro Fujiyah AI and AL Basheer AI Solution. With this experience, I can confidently apply the knowledge gained and make significant contributions to my respective organizations as an AI engineer in the future.

Thank you for considering my application. I would be grateful if you could consider my qualifications for the position of AI Engineering Intern at [LinkedIn Company Name] based on my experience, professionalism, and enthusiasm. Please let me know your decision by March 31, 2026.

Best regards,

[SAWAIRA]

text

**Validation Results:**
- Word Count: 325 ❌ (Required: 150-300)
- Hashtag Count: 0 ❌ (Required: 3-5)
- Hook on Line 1: ✅
- **Overall: ❌ FAILED**

**Violations:**
- ❌ Word count too long (325 – should be 150-300)
- ❌ Hashtag count too few (0 – should be 3-5)

---

### POST 2: The #1 lesson I learned building AI agents at Pro Fusion AI

**Generated Post:**
[SAWAIRA]
[AI ENGINEER]
[SIR MURAD]

[LinkedIn Profile Link]

Critical Rules You Must Follow:

WORD COUNT: Your post MUST be between 150-300 words (excluding hashtags)

HASHTAGS: You MUST include exactly 3-5 hashtags at the end

HOOK: The FIRST LINE of your post MUST be a strong hook to grab attention

Write in a professional, engaging, conversational tone

Background:
I am [Your Name] and I currently work as an AI Engineering Intern at Pro Fusiion AI, based on the city/country listed below. I have completed my Bachelor's degree in Computer Science (8th Semester) from [Virtual University of Pakistan], but I have also obtained several certifications in C++, Python, Web Development, React, NeST.js, TKinter, and so on.

Project/Experience: At Pro Fusiion AI, I've had the opportunity to build an AI agent that can autonomously manage a team of virtual assistants. It's been a challenging but rewarding experience, and here are the lessons I've learned along the way.

First Lesson: When it comes to building AI agents, there are no shortcuts. Building from scratch takes time and effort, but it's worth it in the end. Don't be afraid to make mistakes or seek advice when you need it. The more you understand about the problem domain, the better equipped you'll be to build a solution that truly solves the problem.

Second Lesson: In my experience, the most important skill is having a deep understanding of the problem domain. It's impossible to build an AI agent that can effectively manage a virtual assistant team if you don't understand why they should exist in the first place. The more you understand about the problem domain, the better equipped you'll be to build a solution that truly solves the problem.

Third Lesson: Don't get complacent. AI is still relatively new and there are always going to be improvements to be made. It's important to continuously seek out new ideas and technologies to stay up-to-date with the latest trends and developments in AI engineering.

Fourth Lesson: AI is not a one-size-fits-all solution. There will always be unique challenges and opportunities associated with building an AI agent for virtual assistants, and it's essential to take a holistic approach to solving these problems. Experimentation and prototyping are key in discovering new solutions that work best for your specific use case.

Fifth Lesson: Being adaptable is key to success. The world of AI engineering is constantly evolving, and it's important to be open-minded about new technologies and approaches. Don't be afraid to try out new ideas or explore unconventional approaches when they're relevant to your problem domain.

Last Lesson: Building an AI agent for virtual assistants requires a deep understanding of the technology...


**Validation Results:**
- Word Count: 447 ❌ (Required: 150-300)
- Hashtag Count: 0 ❌ (Required: 3-5)
- Hook on Line 1: ❌ (Starts with "[Your Name]")
- **Overall: ❌ FAILED**

**Violations:**
- ❌ Word count too long (447 – should be 150-300)
- ❌ Hashtag count too few (0 – should be 3-5)
- ❌ No hook on line 1 – starts with placeholder text

### POST 3: How I'm using Python and React to build real-world applications

**Generated Post:**
As a passionate AI engineer who's been working on cutting-edge projects in the field, I would like to share my experience and expertise using Python and React to build real-world applications.

My journey with Python began during my Bachelor's degree in Computer Science, where I developed skills in both data science and web development. I quickly realized that Python could be a powerful tool for building highly scalable and performant web applications, thanks to its high-level syntax, robust libraries, and efficient implementation techniques.

As a software engineering intern at Pro Fuziion AI, my team was tasked with developing a new chatbot that would assist users in accessing information about products and services. The project required me to work closely with a team of designers and developers, collaborating on the front-end design, API development, and testing the chatbot's performance.

To build the chatbot, we utilized Python and React to develop a robust backend system that could process user queries, fetch relevant information from APIs, and handle interactions between chatbot and users. We used libraries like Flask for web development, PostgreSQL as a database, and Axios for making HTTP requests.

My experience also includes building web applications using React Native, which allowed us to deploy the chatbot on both iOS and Android platforms. This was an exciting challenge as we had to optimize the application for different screen sizes and device types, ensuring that it ran smoothly and performed optimally on all devices.

Furthermore, I've also worked on implementing machine learning models using PyTorch and TensorFlow to predict product prices based on user demographics and purchase history. This was a particularly challenging task as we had to deal with imbalanced datasets and ensure that the algorithms were correctly trained for optimal results.

In addition to these projects, I've also been skilled in developing responsive and cross-browser desktop applications using HTML, CSS, and JavaScript. I've used frameworks like React Native and Vue.js for building mobile apps as well.

Overall, my experiences with Python and React have enabled me to build real-world applications that solve complex problems and provide value to users. By combining my technical expertise with a deep understanding of the software development process, I've been able to contribute significantly to our team's success.

In conclusion, my experience in building highly scalable and performant web applications using Python and React has equipped me with valuable skills that I can apply to future projects. As a passionate AI engineer, I am grateful for the opportunity to share my expertise with you on LinkedIn, and I encourage anyone looking to learn more about this exciting field to do likewise. Thank you for considering my application!


**Validation Results:**
- Word Count: 441 ❌ (Required: 150-300)
- Hashtag Count: 0 ❌ (Required: 3-5)
- Hook on Line 1: ✅
- **Overall: ❌ FAILED**

**Violations:**
- ❌ Word count too long (441 – should be 150-300)
- ❌ Hashtag count too few (0 – should be 3-5)

### POST 4: What I learned from my AI Engineering internship at AL Basheer

**Generated Post:**
[SAWAIRA]

[AI ENGINEER]

[PRO FUSION /Organization]

[Date]

[LinkedIn Handle]

Thank you for having me as an AI Engineering Intern at [AL Basheer AI Solution], where I gained valuable experience in the field of Artificial Intelligence. My job has allowed me to work with cutting-edge technology and have a direct impact on real-world applications.

One of the most crucial aspects of my internship was learning how to effectively integrate AI technologies into various industries, including finance, healthcare, and marketing. In this department, I worked closely with the Chief Technology Officer (CTO) to implement machine learning algorithms that improved the accuracy and efficiency of our data analytics capabilities.

As a result, we were able to provide actionable insights to our clients that helped them achieve their business goals. This experience taught me how to design and deploy AI models in various environments, ranging from small-scale data sets to large enterprise systems. I have learned how to effectively integrate AI into complex systems while ensuring its security and privacy standards are adhered to.

I also had the opportunity to work on a variety of projects, including developing custom AI algorithms for predictive maintenance in industrial settings. This experience taught me how to design and implement scalable solutions that can accurately detect faults and optimize equipment maintenance schedules based on machine learning models.

In addition to my internship, I have also gained valuable experience in the field of software engineering. Throughout my time at AL Basheer AI Solution, I worked on various projects such as developing web applications using React and NeatJS, implementing automated testing frameworks, and optimizing database designs for maximum efficiency.

My experience has taught me that AI is not a one-size-fits-all solution; it requires a unique approach to fit a specific problem domain. As an engineer, I have learned the importance of integrating different approaches while ensuring they work together seamlessly.

As someone who wants to contribute to society and make a positive impact on the world, my internship at AL Basheer AI Solution has given me valuable insights into the field of Artificial Intelligence. I have come away with a newfound appreciation for the potential applications of this technology, particularly in healthcare, finance, and marketing.

In conclusion, I would like to express my gratitude to [AL Basheer AI Solution] for providing me with the opportunity to gain practical experience in Artificial Intelligence. My internship has not only enhanced my technical skills but also instilled in me a deep understanding of its potential applications and impact on society.

Thank you, once again, for considering my application as an AI Engineering Intern. I hope to return to AL Basheer AI Solution for further opportunities and learnings in the future. Sincerely,

[SAWAIRA]

text

**Validation Results:**
- Word Count: 450 ❌ (Required: 150-300)
- Hashtag Count: 0 ❌ (Required: 3-5)
- Hook on Line 1: ❌ (Starts with "[Your Name]")
- **Overall: ❌ FAILED**

**Violations:**
- ❌ Word count too long (450 – should be 150-300)
- ❌ Hashtag count too few (0 – should be 3-5)
- ❌ No hook on line 1 – starts with placeholder text

---

### POST 5: Why I'm pursuing AI Engineering while completing my CS degree

**Generated Post:**
Dear recruiters,

As a passionate AI enthusiast, I am proud to announce my career pursuit in AI Engineering while completing my Bachelor's degree in Computer Science (8th Semester). This opportunity has been offered to me by Pro Fusiion AI, a leading AI firm, which I have joined as an Intern.

The AI field offers immense potential for innovation and growth, with countless technological breakthroughs being developed every day. As an Engineering Intern, I am honoured to work on various AI projects that are crucial for the success of businesses and industries around the world.

My recent projects include developing a Clothe Management System (CMS), which is a user-friendly platform designed to streamline internal and external communication in real estate companies, as well as developing a Notification Web App that sends personalized notifications via mobile and desktop devices to customers based on their preferences. I'm proud to mention these projects were completed within the last six months with a team of amazing professionals and with the support of my mentor.

I understand the importance of completing higher education, and I've achieved it by taking advantage of the opportunities that lie ahead. Besides, I have obtained numerous certifications in Python, PyTorch, TensorFlow, and Web Development, among others.

In addition to these projects, I am currently working on developing a Portfolio Website for my artistic endeavours, which will showcase my work, ideas, and style to potential clients or collaborators. It's an exciting opportunity to showcase my capabilities beyond my AI abilities, which will help me establish myself as a valuable asset to any company.

As someone who has always been passionate about learning new things, the fact that I can make a significant impact in this field by working on these projects with exceptional professionals motivates me to pursue further studies and acquire additional knowledge in AI Engineering. This opportunity also allows me to explore the possibilities within the field, which will help me gain a competitive edge in my job search.

In conclusion, I have spent several months honing my skills in AI Engineering while completing my CS degree, and I am excited to continue learning new things, making a significant impact in the AI world, and contributing to the growth of industries that rely on this technology.

Thank you for considering me for your next hire, and I wish you the best of luck as we embark on this journey together. If you're interested in learning more about my experiences or projects, please reach out to me. I look forward to hearing back from you soon.

Best regards,

[ SAWAIRA ]

text

**Validation Results:**
- Word Count: 429 ❌ (Required: 150-300)
- Hashtag Count: 0 ❌ (Required: 3-5)
- Hook on Line 1: ✅
- **Overall: ❌ FAILED**

**Violations:**
- ❌ Word count too long (429 – should be 150-300)
- ❌ Hashtag count too few (0 – should be 3-5)


## 📊 Failure Analysis

| **Constraint** | **Posts That Failed** | **Failure Count** | **Common Issue** |
| :--- | :--- | :--- | :--- |
| Word Count (150-300) | 1, 2, 3, 4, 5 | 5/5 | All were TOO LONG (325-450 words) |
| Hashtags (3-5) | 1, 2, 3, 4, 5 | 5/5 | No hashtags at all |
| Hook on Line 1 | 2, 4 | 2/5 | Started with placeholder text like "[Your Name]" |

### Key Observations

| **Issue** | **How Many Posts** | **Percentage** |
| :--- | :--- | :--- |
| Failed at least one constraint | 5 | 100% |
| Failed word count rule | 5 | 100% |
| Failed hashtag rule | 5 | 100% |
| Failed hook rule | 2 | 40% |
| **Passed ALL constraints** | **0** | **0%** |


## 🧠 Why LLMs Ignore Constraints (The Real Limitation)

| **Issue** | **Explanation** |
| :--- | :--- |
| **Prompt Length** | Long prompts cause the model to "forget" earlier instructions |
| **Multiple Constraints** | The model prioritizes one rule (e.g., content quality) over others (e.g., length) |
| **Negative Constraints** | Telling the model "don't do X" is less effective than telling it "do Y" |
| **Model Size** | Smaller models (like tinyllama) have less reasoning ability and smaller context windows |

### What We Observed in This Test

1. **ALL 5 posts exceeded the word limit** – ranging from 325 to 450 words
2. **ALL 5 posts had 0 hashtags** – completely ignored the hashtag requirement
3. **2 posts failed the hook rule** – started with placeholder text like "[Your Name]"
4. **0 posts passed all constraints** – a 0% success rate
5. The model generated **overly long, generic content** instead of concise, engaging posts


## 💡 How Posts Fusion Solves This

| **Solution** | **How It Works** |
| :--- | :--- |
| **1. Validator** | Every output is checked against the rules (like the function in this script) |
| **2. Re-prompting** | If validation fails, regenerate the post with stronger constraints |
| **3. Larger Models** | Use llama3 or mistral (which follow instructions better than tinyllama) |
| **4. Simpler Prompts** | Place constraints at the very beginning of the prompt |
| **5. System Prompts** | Use system messages (not just user messages) for better instruction following |


## 🏆 Key Takeaway

> **Never trust an LLM to follow rules perfectly. ALWAYS validate the output.**
>
> This is exactly why the Posts Fusion pipeline has a **Step 3 validator** – it catches these exact failures and forces regeneration until the post meets all criteria.


## 📋 Task Completion Checklist

- [x] Learned why LinkedIn algorithm rules matter (150-300 words, 3-5 hashtags, hook on line 1)
- [x] Added constraints explicitly into prompts using MY updated resume
- [x] Generated 5 posts based on MY experience
- [x] Verified each post (counted words & hashtags manually)
- [x] Noted outputs that ignored constraints (ALL 5 posts failed)
- [x] Documented real LLM limitations

---

## 🛠️ Technical Setup Used

| **Component** | **Details** |
| :--- | :--- |
| **Python Version** | 3.14.4 |
| **AI Model** | Ollama (tinyllama) |
| **Prompting Method** | System + User prompts with explicit constraints |
| **Source Material** | MY updated resume (Sawaira Mumtaz Job resume.pdf) |
| **Environment** | Windows 11, PowerShell, Virtual Environment (.venv) |
| **Validator** | Custom function (word count, hashtag count, hook check) |
| **Test Posts** | 5 topics based on MY experience |
| **Success Rate** | **0%** (0 out of 5 posts passed) |

## 📈 Key Learnings from This Test

| **Learning** | **Description** |
| :--- | :--- |
| **LLMs are unreliable with constraints** | Even when explicitly told, the model ignored multiple rules |
| **Smaller models struggle more** | tinyllama consistently failed to follow instructions |
| **Multiple constraints are harder** | The model failed on all three constraints across all posts |
| **Placeholder text is a warning sign** | Posts 2 and 4 started with "[Your Name]" – the model was confused |
| **Validation is essential** | Without validation, these posts would have been published with errors |

---

## 🔧 Recommendations for Improvement

| **Recommendation** | **Why** |
| :--- | :--- |
| **Use larger model** | llama3 or mistral follow instructions better than tinyllama |
| **Simplify prompts** | Put constraints at the very beginning with clear formatting |
| **Use few-shot examples** | Show the model examples of correct posts |
| **Implement re-prompting** | If validation fails, try again with stronger emphasis |
| **Reduce temperature** | Lower temperature (0.3-0.5) for more consistent outputs |

## 👩‍💻 Author

**Sawaira Mumtaz** – AI Engineering Intern
**Submitted:** July 16, 2026

## 📂 Files in This Repository

| **File Name** | **Description** |
| :--- | :--- |
| `constraint_test.py` | Python script for testing LinkedIn constraints |
| `README.md` | This file – documentation and results |

## 🏁 End of Report
