text
============================================================
          Tuesday TASK - COMPLETION REPORT / README
============================================================
Date: July 10, 2026
Student/User: Sawaira Mumtaz
Environment: Windows 11, PowerShell, Python 3.14, Ollama
============================================================

============================================================
PART 1: PYTHON REFRESHER (Functions, Dictionaries, JSON)
============================================================

WHAT I DID:
I wrote a Python script that:
- Created a function called "welcome_message()" that takes a name and returns a greeting.
- Created a Dictionary called "my_business" containing business details (name, clients, country).
- Converted that Python Dictionary into a JSON string using "json.dumps()" to understand how JSON formatting works.

MY CODE SNIPPET:
------------------------------------------------------------
def welcome_message(name):
    return "Welcome to the team, " + name + "!"

my_business = {
    "name": "Peak Performance Coaching",
    "clients": 15,
    "country": "USA"
}
business_json = json.dumps(my_business)
------------------------------------------------------------

MY OUTPUT:
------------------------------------------------------------
Welcome to the team, Sawaira!
My Dictionary: {'name': 'Peak Performance Coaching', 'clients': 15, 'country': 'USA'}
My Dictionary as a JSON string: {"name": "Peak Performance Coaching", "clients": 15, "country": "USA"}
------------------------------------------------------------

LEARNING TAKEAWAY:
- Functions are reusable blocks of code.
- Dictionaries store data in "key: value" pairs.
- JSON is just a string format that looks like a dictionary, used to send data over the internet.

============================================================
PART 2: PUBLIC API CALL (Weather API)
============================================================

WHAT I DID:
I used the Python "requests" library to call a free weather API (Open-Meteo) without needing an API key. I requested the current weather for Tokyo, Japan.

MY CODE SNIPPET:
------------------------------------------------------------
weather_url = "https://api.open-meteo.com/v1/forecast?latitude=35.68&longitude=139.76&current_weather=true"
weather_response = requests.get(weather_url)
weather_data = weather_response.json()
------------------------------------------------------------

MY OUTPUT (Raw JSON Response):
------------------------------------------------------------
{'latitude': 35.7, 'longitude': 139.75, 'generationtime_ms': 0.06771087646484375, 'utc_offset_seconds': 0, 'timezone': 'GMT', 'timezone_abbreviation': 'GMT', 'elevation': 12.0, 'current_weather_units': {'time': 'iso8601', 'interval': 'seconds', 'temperature': '°C', 'windspeed': 'km/h', 'winddirection': '°', 'is_day': '', 'weathercode': 'wmo code'}, 'current_weather': {'time': '2026-07-10T11:15', 'interval': 900, 'temperature': 24.6, 'windspeed': 7.6, 'winddirection': 177, 'is_day': 0, 'weathercode': 1}}
------------------------------------------------------------

EXTRACTED INFORMATION:
Tokyo temperature right now: 24.6°C

LEARNING TAKEAWAY:
- An API is like a waiter that takes your request to a server and brings back data.
- "requests.get()" sends the request.
- ".json()" converts the raw response into a Python dictionary so we can read it easily.

============================================================
PART 3: OPENAI/OLLAMA API CALL (Print Raw JSON Response)
============================================================

WHAT I DID:
Since I don't have an OpenAI API key with billing set up, I used Ollama (a free, local OpenAI-compatible API) running on my own computer. I sent a prompt to the "mistral" model asking it to say "My very first API call works perfectly!" and printed the raw JSON response.

TECHNICAL SETUP:
- Used "http://localhost:11434/api/generate" as the API endpoint.
- Model used: "mistral" (installed via Ollama).
- Sent a POST request with a JSON payload containing the prompt.

MY CODE SNIPPET:
------------------------------------------------------------
ollama_url = "http://localhost:11434/api/generate"
payload = {
    "model": "mistral",
    "prompt": "Say 'My very first API call works perfectly!'",
    "stream": False
}
response = requests.post(ollama_url, json=payload)
------------------------------------------------------------

MY OUTPUT (RAW JSON RESPONSE - This is exactly what the task asked for):
------------------------------------------------------------
{"model":"mistral","created_at":"2026-07-10T11:29:12.8051474Z","response":" My very first API call works perfectly!","done":true,"done_reason":"stop","context":[3,29473,16521,1232,5951,1983,1675,7854,1802,4559,10711,9641,4,29473,2752,1983,1675,7854,1802,4559,10711,29576],"total_duration":40586684400,"load_duration":35303608100,"prompt_eval_count":14,"prompt_eval_duration":2525205000,"eval_count":9,"eval_duration":2687242000}
------------------------------------------------------------

EXTRACTED AI REPLY:
"My very first API call works perfectly!"

LEARNING TAKEAWAY:
- Making an API call involves sending a request with headers/payload and reading the JSON response.
- The JSON response contains metadata (timing, model name) plus the actual "response" from the AI.
- Raw JSON is the fundamental way computers talk to each other over the internet.

============================================================
ENVIRONMENT SETUP & COMMANDS USED
============================================================

1. Installed Python "requests" library:
   > pip install requests

2. Checked available AI models in Ollama:
   > ollama list
   > (Showed: mistral, llama3.2, gemma3, phi3.5)

3. Ran the final Python script:
   > python Tuesday_task.py

============================================================
CONCLUSION / SUBMISSION NOTE
============================================================

I have successfully completed all three parts of the Monday task:

1. ✅ Refreshed Python concepts (Functions, Dictionaries, JSON).
2. ✅ Made a successful public API call (Weather API).
3. ✅ Made a successful local AI API call (Ollama) and printed the raw JSON response.

Note: I used Ollama (mistral model) instead of OpenAI's cloud API because I do not have an OpenAI API key with billing enabled. However, the concept and implementation are identical—sending a POST request to an API endpoint and parsing the JSON response.

Output
PS C:\Users\Sawaira Mumtaz\OneDrive\Desktop\AI task\week1-06-07-26> Python Tuesday_task.py
========================================
MONDAY TASK - OLLAMA VERSION
========================================

--- PART 1: PYTHON REFRESHER ---
Welcome to the team, Sawaira!
My Dictionary: {'name': 'Peak Performance Coaching', 'clients': 15, 'country': 'USA'}
My Dictionary as a JSON string: {"name": "Peak Performance Coaching", "clients": 15, "country": "USA"}

--- PART 2: WEATHER API CALL ---
Raw Weather JSON Response:
{'latitude': 35.7, 'longitude': 139.75, 'generationtime_ms': 0.0591278076171875, 'utc_offset_seconds': 0, 'timezone': 'GMT', 'timezone_abbreviation': 'GMT', 'elevation': 12.0, 'current_weather_units': {'time': 'iso8601', 'interval': 'seconds', 'temperature': '°C', 'windspeed': 'km/h', 'winddirection': '°', 'is_day': '', 'weathercode': 'wmo code'}, 'current_weather': {'time': '2026-07-10T13:00', 'interval': 900, 'temperature': 24.2, 'windspeed': 7.7, 'winddirection': 169, 'is_day': 0, 'weathercode': 1}}

Tokyo temperature right now: 24.2°C

--- PART 3: OLLAMA API CALL ---
Calling your Ollama AI...

--- THE RAW JSON RESPONSE FROM OLLAMA ---
{"model":"mistral","created_at":"2026-07-10T13:10:21.7232071Z","response":" My very first API call works perfectly!","done":true,"done_reason":"stop","context":[3,29473,16521,1232,5951,1983,1675,7854,1802,4559,10711,9641,4,29473,2752,1983,1675,7854,1802,4559,10711,29576],"total_duration":5992768000,"load_duration":146731900,"prompt_eval_count":14,"prompt_eval_duration":2722201000,"eval_count":9,"eval_duration":3083201000}

--- AI's Actual Reply ---
 My very first API call works perfectly!

============================================================
END OF REPORT


