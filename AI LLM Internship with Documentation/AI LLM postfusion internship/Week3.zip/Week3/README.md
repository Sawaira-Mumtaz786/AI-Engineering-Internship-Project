\# Week 3: Vector Embeddings \& Content Fingerprint



\*\*Date:\*\* July 23, 2026

\*\*Student:\*\* Sawaira Mumtaz



\---



\## 📌 Task Overview



| \*\*Day\*\* | \*\*Task\*\* | \*\*Status\*\* |

| :--- | :--- | :--- |

| Monday | First embedding + 3 sentences | ✅ Complete |

| Tuesday | 5 sentences + cosine similarity | ✅ Complete |

| Wednesday | Pinecone concept + setup | ✅ Complete |

| Thursday | Query + retrieval + Posts Fusion | ✅ Complete |

| Friday | Research summary + Group sync | ✅ Complete |



\---



\## 🧪 How to Run



```bash

\# Pull the model

ollama pull nomic-embed-text



\# Run each day

python day1\_embedding\_intro.py

python day2\_cosine\_similarity.py

python day3\_pinecone\_setup.py

python day4\_query\_similarity.py



