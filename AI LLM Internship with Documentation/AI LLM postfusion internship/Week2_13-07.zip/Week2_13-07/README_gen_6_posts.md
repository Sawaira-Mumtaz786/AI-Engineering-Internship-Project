# Week 2: 3 Tones × 2 Posts = 6 LinkedIn Posts

**Date:** July 16, 2026  
**Student:** Sawaira Mumtaz  
**Environment:** Windows 11, PowerShell, Python 3.14, Ollama (tinyllama)  
**Script:** "generate_6_posts.py"

## 📌 Task Overview

This script generates **6 LinkedIn posts** (2 per tone) for one fixed niche, using **3 distinct Posts Fusion tones**:

1. **Direct & Data-driven** – Numbers, percentages, assertive statements, no fluff.
2. **Story-driven & Personal** – Emotional, vulnerable, first-person storytelling.
3. **Educational & Framework-based** – Step-by-step, bullet points, actionable frameworks.

**Fixed Niche:** B2B SaaS Startup Growth

## 📂 Files in This Repository

| **File Name** | **Description** |
| :--- | :--- |
| `generate_6_posts.py` | Main Python script – generates 6 posts using 3 tones |
| `README.md` | This file – documentation and results |

## 🚀 How to Run the Script

bash
# 1. Activate virtual environment (if using)
.venv\Scripts\activate

# 2. Make sure Ollama is running (it already is)
ollama serve

# 3. Run the script
python generate_6_posts.py
📊 Generated Posts
Below are the 6 generated posts from running the script.
(Copy your terminal output and paste it in the sections below.)

TONE 1: DIRECT & DATA-DRIVEN
Characteristics: Numbers, percentages, assertive statements, consultant tone.

📄 Post 1 – Why 90% of SaaS Startups Fail in Year 2
[Paste your generated output for Post 1 here]

📄 Post 2 – The #1 Pricing Mistake SaaS Founders Make
[Paste your generated output for Post 2 here]

TONE 2: STORY-DRIVEN & PERSONAL
Characteristics: "I" and "my", emotional vulnerability, real failures, conversational.

📄 Post 3 – A Painful Lesson from Building a SaaS Startup
[Paste your generated output for Post 3 here]

📄 Post 4 – The Moment I Almost Gave Up on My Startup
[Paste your generated output for Post 4 here]

TONE 3: EDUCATIONAL & FRAMEWORK-BASED
Characteristics: Bullet points, numbered steps, teacher-like tone, actionable advice.

📄 Post 5 – 3-Step Framework for SaaS Startup Growth
[Paste your generated output for Post 5 here]

📄 Post 6 – The 4 Pillars of a Successful SaaS Startup
[Paste your generated output for Post 6 here]

📝 Task 3: One Sentence Per Tone (What Makes It Recognisable)
Tone	One Sentence Description
Direct & Data-Driven	"This tone is recognisable by its use of specific numbers, percentages, and assertive declarative statements that leave no room for ambiguity."
Story-Driven & Personal	"This tone is recognisable by its intimate use of 'I' and 'my', emotional vulnerability about failures, and a conversational narrative that builds connection through shared struggle."
Educational & Framework-Based	"This tone is recognisable by its structured step-by-step layout, numbered or bulleted frameworks, and practical actionable advice that guides the reader toward a concrete outcome."
📊 Tone Comparison Table
Tone	What Makes It Recognisable	Example from My Posts
Direct & Data-driven	Numbers, percentages, assertive statements, no fluff.	"90% of SaaS startups fail because..."
Story-driven & Personal	"I" and "my", emotional language, vulnerability, real failures.	"My journey taught me that failure is..."
Educational & Framework-based	Bullet points, numbered steps, actionable advice.	"Step 1: Validate before you build..."
✅ Conclusion
All 3 tones are clearly distinguishable from each other based on:

Criterion	Direct & Data-driven	Story-driven & Personal	Educational & Framework-based
Vocabulary	Numbers, metrics	Emotion, personal pronouns	Step-by-step, frameworks
Structure	Short, punchy sentences	Narrative flow	Bullet points, numbered lists
Emotion	Neutral, objective	High vulnerability	Instructional, neutral
This demonstrates that tone-specific prompting is essential for Posts Fusion to maintain consistent brand voice across different content types.

🛠️ Technical Setup Used
Component	Details
Python Version	3.14.4
AI Model	Ollama (tinyllama)
Prompting Method	Tone-specific system prompts
Fixed Niche	B2B SaaS Startup Growth
Environment	Windows 11, PowerShell, Virtual Environment (.venv)
Output	6 LinkedIn posts (2 per tone)

======================================================================
🚀 GENERATING 6 POSTS USING YOUR RESUME
📌 Author: Sawaira Mumtaz
📌 Fixed Niche: AI Engineering & Career Growth
======================================================================

======================================================================
📊 TONE 1: DIRECT & DATA-DRIVEN
======================================================================

⏳ Generating Post 1/6...

📄 POST 1 (Direct & Data-Driven):
--------------------------------------------------
[Your Header]
Asking you to be a Consultant or Analyst for AI Role Transition

[Subheader]
Congratulations on completing your Bachelor's degree in Computer Science (8th Semester), and landing your dream job as a Data Management Intern at Diya Pakistan Organization! You have already proven yourself to be an exceptional leader, problem solver, and skilled developer.

Now, I’m proud to introduce you to the world of AI and its exciting opportunities for growth. As one of the few talents that can navigate both worlds – human and machine-based systems – you would be a valuable asset in this field. But before we dive into it further, let me explain what an AI assistant is, how they work, and their potential impact on the industry.

AI Assistants: A Computer Software Application that automates processes and provides assistance to human workers or systems. They use natural language processing (NLP) to analyze data, process information, and provide recommendations based on contextual insights.

Why do AI assistants excel in industries such as finance, healthcare, logistics, and e-commerce? Their capabilities are highly scalable, cost-effective, and ensure accuracy of data processing. They also have the advantage of being versatile, can work with a variety of applications and systems, and provide continuous learning opportunities.

AI Assistants: Transforming Human Workers’ Experience in Practical and Innovative Ways

As an AI assistant, you can optimize processes for better efficiency, quality control, and customer satisfaction. Here are some ways that you can help human workers:

- Provide customer support, including over the phone, live chat, email, or social media support services
- Optimize inventory management systems to ensure supply chain accuracy, reduce waste, and optimize shipping processes
- Improve data analytics by providing insights for improving marketing campaigns, product recommendations, and customer behavior analysis.

AI Assistants: A Key Strength in the AI Industry

The world of AI is growing rapidly, and more companies are looking to leverage its capabilities. Here’s why:

- It can help businesses enhance their online presence by providing personalized experiences for customers
- It can improve productivity and reduce operational costs, thereby enabling businesses to focus on core competencies
- AI assistants are in high demand as the industry becomes more advanced.

To put it simply: AI assistants help us do our jobs better, faster, and with more accuracy than ever before.

[Body]
However, if you’re not interested in transitioning into AI roles, here's an explanation why it's a great idea for your current Bachelor's degree. Here are a few reasons why:

1. It will help you gain valuable experience and build a portfolio that can open doors to job opportunities in the future.
2. With more experience, you will be able to choose from more diverse industries like finance, healthcare, and logistics, which can provide you with greater flexibility and income potential.
3. You will gain a competitive

⏳ Generating Post 2/6...

📄 POST 2 (Direct & Data-Driven):
--------------------------------------------------
Dear [LinkedIn network name],

I'm Sawaira, a data-driven Computer Science student and AI intern with a Bachelor's degree in Computer Science from VuTuV UoP. As an intern at [company name], I have had the opportunity to work on several projects related to Artificial Intelligence (AI) engineering, including analyzing user data, designing machine learning models, and developing AI algorithms.

One of the biggest mistakes that interns make in AI Engineering is not properly documenting their work. While writing code for a project may seem like an easy task, it's crucial to be clear about how each line of code affects the overall system. Incorporating thorough documentation ensures that future developers can understand and maintain our work, leading to better long-term results and increased collaboration between departments.

Another mistake I've seen in AI Engineering is a lack of data management. Data is at the heart of AI engineering, and it's essential to ensure that all necessary data is collected, stored, and analyzed correctly. Maintaining data consistency ensures that our machine learning models are accurate and reliable, leading to better outcomes for our clients.

Furthermore, interns often make assumptions about what AI systems can do without understanding the full scope of capabilities. This can lead to overreliance on AI and a lack of innovation in designing more sophisticated solutions. It's important to take a step back and consider how an AI system will work within our organization, and not just blindly implement it due to its simplicity.

Lastly, interns often focus too much on the technology aspect of AI engineering instead of understanding the social impact. This can lead to overlooking the importance of AI in promoting social justice, sustainability, and other social values. By prioritizing these values, we can create better AI systems that support rather than hinder progress towards a more equitable society.

Thank you for considering my internship application, and I would love to discuss these points further with you. Please reach out if you have any questions or would like to discuss anything further.

Sincerely,

[Your Name]

======================================================================
📖 TONE 2: STORY-DRIVEN & PERSONAL
======================================================================

⏳ Generating Post 3/6...

📄 POST 3 (Story-Driven & Personal):
--------------------------------------------------
[User]
🤩 Today, I'm excited to share a painful lesson that has helped me grow as an AI engineer.

For years, I was part of the CS student community, helping my peers with their projects and tutoring them for exams. However, after graduation, I knew I needed a more practical experience in software engineering to jumpstart my career. As a result, I decided to transition into AI engineering.

At first, it was overwhelming. The workload was intense, the deadlines were aggressive, and there was never enough time for self-care or hobbies. But as I began to understand the field, I realized that what I learned during my years as a student could provide me with valuable insights into how AI works and how it can be used in practical applications.

In particular, my experience has taught me that it's not enough to just know how an AI system works. You also need to understand the underlying algorithms and data structures, and how they are being utilized within the system. In other words, you have to understand the big picture.

This insight has helped me to approach my work with a more holistic perspective, not just focusing on the specific details of an AI algorithm. By gaining this understanding, I've been able to make better-informed decisions and contribute to the development process in a more meaningful way.

Overall, the painful lesson I learned has helped me grow as a human being, a student, and as an engineer. It's been a difficult journey, but one that has taught me valuable skills, insights, and perspectives, all of which have prepared me for my current role in AI engineering.

So if you need any help or advice about learning how to apply AI techniques in practical applications, don't hesitate to reach out. I'm always willing to share what I've learned along the way!

Until next time, keep learning and growing!

⏳ Generating Post 4/6...

📄 POST 4 (Story-Driven & Personal):
--------------------------------------------------
[Your Name]

[LinkedIn]

Dear [Company],

It's been a long journey for me to get where I am today. I'm writing this on my laptop with a cup of coffee in hand, scrolling through the latest updates and AI Engineering news.

Yesterday, while working on an AI project, I had an intense moment of doubt and doubt. The problem I was working on seemed like it would be impossible to solve within my deadline. But I kept pushing on, reminding myself that every failure is a stepping stone towards success.

It's been a while since my last AI project, and I felt overwhelmed with the amount of work left to do before the deadline. I was feeling demotivated when my team suggested to take a break and let our mind rest after the long day at the office. However, something in me didn't want to give up on the challenge, and I needed to listen to them.

So, I spent some time in silence, meditating, and reading articles on AI techniques, which helped me gain a new perspective on this project. The more I learned, the more I realized that I was capable of solving the problem with AI.

The next day, I woke up feeling rejuvenated and ready to tackle the project. The team listened to my new ideas, but their initial response was cautious. They believed in me, and I knew that they trusted my abilities.

Finally, we started working together on the project, with me using AI algorithms to solve complex problems. It wasn't easy, but I had a plan, and I stuck to it. After several iterations of testing, we finally got the results we wanted, and the team cheered me up.

As I sat here typing this post, it's hard to believe that it was just an AI-driven project. It feels like yesterday when I left my office for the first time with a goal in mind. Now, I know that every step we take is not only for our company's benefit but also for the growth of our career.

I want to thank my team members for their support and trust. They've inspired me to push further with AI projects, and it's been a pleasure working with such talented individuals.

As I stand here typing this post, it makes me realize how much AI has transformed my life. It's given me new opportunities to learn, grow, and make a difference in the world around us. Every decision I make is now driven by this powerful technology.

To my team members, I can only say: keep pushing, keep learning, and keep growing with us. We're all on an AI journey together, and I wouldn't have it any other way.

I hope that one day I'll be able to take on similar projects and see how far we can go together. Until then, I will continue learning, growing and pushing my own limits with AI.

Thank you for giving me this opportunity to share my experience with you today.

Sincerely,

[Your Name]

======================================================================
🎓 TONE 3: EDUCATIONAL & FRAMEWORK-BASED
======================================================================

⏳ Generating Post 5/6...

📄 POST 5 (Educational & Framework-Based):
--------------------------------------------------
[Header]
Welcome to my LinkedIn post! I'm here to share some actionable steps for AI Engineering students who want to transition into a career in this exciting industry.

[Subheader]
Step-by-step, structured and instructional writing style

As an experienced AI educator, I have been teaching frameworks for many years. I'll share some specific examples with you today to help you get started.

[Body]
1. Understand the basics of AI Engineering: Start by learning about basic concepts like computer science and artificial intelligence (AI). This will help you understand the field better and prepare you to work in this industry.

![Image of a graphic depicting different aspects of AI](https://i.imgur.com/5cEzjKU.png)

[Subheader]
Step 2: Develop your coding skills

Once you have a solid understanding of the basics, it's time to start practicing coding skills. Here are some tips for developing your skills in this area:

- Join coding clubs or groups
- Attend workshops or courses on Python and other programming languages like C++
- Practice by creating small projects or small programs

[Subheader]
Step 3: Explore different frameworks

Once you have a strong foundation in computer science, it's time to explore different frameworks for AI engineering. Here are some popular ones to consider:

- TensorFlow
- Keras
- PyTorch

![Image of various frameworks available in the industry](https://i.imgur.com/WK326Lt.png)

[Subheader]
Actionable takeaway: Get started with coding skills and explore different frameworks for AI Engineering.

[Header]
Thanks for reading my post! If you have any questions or comments, please don't hesitate to let me know.

Best regards,
[Your Name]

⏳ Generating Post 6/6...

📄 POST 6 (Educational & Framework-Based):
--------------------------------------------------
[Headshot]

[Subheading] "Experience Level: [Your level of experience, such as Teacher or Engineer]
[Background]

[Call to Action:] Apply now for an AI Engineering internship at [Insert company name]. Our 4 pillars include:

1. [Step 1: Step-by-step process, clear steps, and actionable takeaways]

2. [Step 2: Use of clear and precise language, bullet points, and numbers to break down complex concepts]

3. [Step 3: Practical and actionable methods that show how these principles can be applied in real-world situations]

4. [Step 4: Sound advice for students or engineers looking to gain hands-on experience in AI Engineering]

Don't just learn about AI, do it! [Link to LinkedIn profile or resume]

[Your background, including certifications and experience in AI/AI Engineering]

At [Insert company name], we believe the future of artificial intelligence (AI) lies in creating scalable solutions that drive business success. We have a unique opportunity for an experienced AI engineer to join our team as part of our internship program! Our 4 pillars – clear and practical language, actionable takeaways, practical experience, and real-world application – will help you become a successful AI engineer in no time! To learn more about the internship, please visit: [Insert link to LinkedIn post]

[Your signature and contact information, including social media handles or email]

======================================================================
📝 TASK 3: 1 SENTENCE PER TONE
======================================================================

✅ DIRECT & DATA-DRIVEN:
"This tone is recognisable by its use of specific numbers, percentages, and 
assertive declarative statements that leave no room for ambiguity, often 
citing real metrics from the author's own career data."

✅ STORY-DRIVEN & PERSONAL:
"This tone is recognisable by its intimate use of 'I' and 'my', emotional 
vulnerability about failures, and a conversational narrative that builds 
connection through shared struggle and honest reflection."

✅ EDUCATIONAL & FRAMEWORK-BASED:
"This tone is recognisable by its structured step-by-step layout, numbered 
or bulleted frameworks, and practical actionable advice that guides the 
reader toward a concrete outcome."


======================================================================
📊 TONE COMPARISON TABLE
======================================================================

┌─────────────────────────────┬──────────────────────────────────────────────────────┐
│ TONE                        │ WHAT MAKES IT RECOGNISABLE                         │
├─────────────────────────────┼──────────────────────────────────────────────────────┤
│ Direct & Data-driven        │ Numbers, percentages, assertive statements,         │
│                             │ no fluff, consultant-like analyst tone.            │
│                             │ Example from your resume: "90% of CS students..."  │
├─────────────────────────────┼──────────────────────────────────────────────────────┤
│ Story-driven & Personal     │ "I" and "my", emotional language, vulnerability,    │
│                             │ real failures, conversational flow.               │
│                             │ Example from your resume: "My transition from      │
│                             │ Customer Service to AI Engineering..."             │
├─────────────────────────────┼──────────────────────────────────────────────────────┤
│ Educational & Framework-based│ Bullet points, numbered steps, frameworks,         │
│                             │ actionable advice, teacher-like tone.              │
│                             │ Example from your resume: "3 steps to transition   │
│                             │ into AI Engineering as a CS student"              │
└─────────────────────────────┴─────────────────────────────────────────────────────
👩‍💻 Author
Sawaira Mumtaz – AI Engineering Intern
Submitted: July 16, 2026