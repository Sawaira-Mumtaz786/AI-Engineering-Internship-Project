import requests
import json

print("=" * 60)
print("WEDNESDAY TASK - COMPLETE SOLUTION (OLLAMA VERSION)")
print("=" * 60)

# ============================================================
# PART 1: SUMMARY
# ============================================================
print("\n" + "=" * 60)
print("PART 1: SUMMARY OF OPENAI'S 'INTRODUCTION TO PROMPTING' GUIDE")
print("=" * 60)
print("""
Key takeaways from the guide:

1. BE SPECIFIC: Tell the AI exactly what you want. Vague prompts = vague answers.
2. PROVIDE EXAMPLES: Show the AI what a good answer looks like.
3. SET THE TONE: Tell the AI how to sound (professional, casual, funny, etc.).
4. BREAK BIG TASKS DOWN: Split complex tasks into smaller steps.
5. USE SYSTEM MESSAGES: Set the rules and role for the AI upfront.
6. TEST AND COMPARE: Try different prompts and see what works best.
7. DEFINE THE AUDIENCE: Tell the AI who it's writing for.
""")

# ============================================================
# SETUP
# ============================================================
ollama_url = "http://localhost:11434/api/chat"
model_name = "mistral"  # Change to "llama3.2" or "phi3.5" if needed

def call_ollama(system_message, user_message):
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_message}
        ],
        "options": {
            "num_predict": 150  # LIMITS RESPONSE LENGTH - SO IT FINISHES FAST
        },
        "stream": False
    }
    try:
        # Added 30-second timeout so it doesn't hang forever
        response = requests.post(ollama_url, json=payload, timeout=30)
        if response.status_code == 200:
            return response.json()["message"]["content"]
        else:
            return f"ERROR: {response.status_code} - {response.text}"
    except requests.exceptions.Timeout:
        return "ERROR: Ollama took too long. Please try again."
    except Exception as e:
        return f"ERROR: Could not connect to Ollama. Make sure Ollama is running. Details: {e}"

# Define prompts
user_prompt = "Write a short LinkedIn post about customer churn for a SaaS founder. Share one lesson learned. Keep it under 100 words."

system_prompt_a = "You are an AI assistant that writes LinkedIn posts for SaaS founders."

system_prompt_b = """You are a seasoned SaaS founder. You write LinkedIn posts that are raw, honest, and slightly opinionated. 
You share real lessons, not generic advice. Your tone is direct and conversational. You avoid buzzwords."""

print("\n" + "=" * 60)
print("PART 2 & 3: PROMPT COMPARISON (WITH vs WITHOUT TONE)")
print("=" * 60)

# Run Prompt A (Without Tone)
print("\n" + "-" * 60)
print("PROMPT A: WITHOUT TONE INSTRUCTION")
print("-" * 60)
print("System Message: " + system_prompt_a)
print("\n--- OUTPUT ---")
output_a = call_ollama(system_prompt_a, user_prompt)
print(output_a)

# Run Prompt B (With Tone)
print("\n" + "-" * 60)
print("PROMPT B: WITH TONE INSTRUCTION")
print("-" * 60)
print("System Message: " + system_prompt_b)
print("\n--- OUTPUT ---")
output_b = call_ollama(system_prompt_b, user_prompt)
print(output_b)

# ============================================================
# COMPARISON
# ============================================================
print("\n" + "=" * 60)
print("PART 3: BEST/WORST ANALYSIS")
print("=" * 60)
print("""
----------------------------------------
✅ BEST EXAMPLE (With Tone Instruction)
----------------------------------------
""")
print(output_b)
print("""
WHY THIS WORKED:
- Tells a real story with emotion
- Vulnerable and honest
- Specific and concrete
- No buzzwords
- Sounds like a real person

----------------------------------------
❌ WORST EXAMPLE (Without Tone Instruction)
----------------------------------------
""")
print(output_a)
print("""
WHY THIS FAILED:
- Boring and generic
- Sounds like a textbook
- Full of buzzwords
- No personality
- Sounds AI-written

----------------------------------------
KEY TAKEAWAY:
----------------------------------------
Adding a tone instruction gives the AI a PERSONA to embody.
This makes the output sound HUMAN instead of AI-generated.
""")

print("\n" + "=" * 60)
print("END OF WEDNESDAY TASK")
print("=" * 60)