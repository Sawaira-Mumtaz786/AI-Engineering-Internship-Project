import React, { useState } from 'react';
import { ShieldCheck, RefreshCw, CheckCircle, XCircle, AlertCircle, BarChart3, ArrowRight } from 'lucide-react';

interface TuesdayValidationProps {
  ollamaUrl: string;
  model: string;
}

interface TestRunItem {
  id: number;
  niche: string;
  tone: string;
  topic: string;
  attempt1: {
    wordCount: number;
    hashtagCount: number;
    isValid: boolean;
    reasons: string[];
    content: string;
  };
  attempt2?: {
    wordCount: number;
    hashtagCount: number;
    isValid: boolean;
    reasons: string[];
    content: string;
  };
  finalStatus: 'pass_first' | 'pass_retry' | 'failed';
}

export const TuesdayValidation: React.FC<TuesdayValidationProps> = ({ ollamaUrl, model }) => {
  const [isRunning, setIsRunning] = useState(false);
  const [testRuns, setTestRuns] = useState<TestRunItem[]>([]);

  // Sample 10 test prompts for Tuesday Task
  const testPrompts = [
    { niche: 'Executive Coach', tone: 'storytelling', topic: 'Managing executive burnout in high-growth startups' },
    { niche: 'Tech Founder', tone: 'bold', topic: 'Why AI will not replace human empathy in leadership' },
    { niche: 'SaaS Marketer', tone: 'analytical', topic: 'B2B acquisition metrics that matter in 2026' },
    { niche: 'Engineering Lead', tone: 'educational', topic: 'How to conduct constructive code reviews' },
    { niche: 'Product Manager', tone: 'inspirational', topic: 'Turning customer rejection into feature breakthroughs' },
    { niche: 'Cybersecurity Specialist', tone: 'urgent', topic: '3 critical security habits every remote worker needs' },
    { niche: 'Finance Advisor', tone: 'practical', topic: 'Managing cashflow during uncertain economic shifts' },
    { niche: 'Data Scientist', tone: 'technical', topic: 'Understanding context window limits in local LLMs' },
    { niche: 'Design Lead', tone: 'creative', topic: 'Why minimalistic UI leads to higher conversion rates' },
    { niche: 'Career Mentor', tone: 'supportive', topic: 'How to ask for a salary raise with confidence' },
  ];

  const run10TestGenerations = async () => {
    setIsRunning(true);
    setTestRuns([]);

    const results: TestRunItem[] = [];

    for (let i = 0; i < testPrompts.length; i++) {
      const p = testPrompts[i];

      try {
        // Attempt 1: Standard generation
        const res1 = await fetch('/api/generate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            niche: p.niche,
            tone: p.tone,
            topic: p.topic,
            model,
            ollamaUrl,
            maxRetries: 1, // First run single attempt
          }),
        });
        const data1 = await res1.json();

        const words1 = data1.content.trim().split(/\s+/).length;
        const hashtags1 = (data1.content.match(/#\w+/g) || []).length;
        const isValid1 = data1.validation?.isValid ?? false;
        const reasons1 = data1.validation?.reasons || [];

        let item: TestRunItem = {
          id: i + 1,
          niche: p.niche,
          tone: p.tone,
          topic: p.topic,
          attempt1: {
            wordCount: words1,
            hashtagCount: hashtags1,
            isValid: isValid1,
            reasons: reasons1,
            content: data1.content,
          },
          finalStatus: isValid1 ? 'pass_first' : 'failed',
        };

        // If Attempt 1 failed, automatically retry with maxRetries: 2 (Auto-retry logic)
        if (!isValid1) {
          const res2 = await fetch('/api/generate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              niche: p.niche,
              tone: p.tone,
              topic: p.topic,
              model,
              ollamaUrl,
              maxRetries: 2, // Retries once automatically with feedback
            }),
          });
          const data2 = await res2.json();

          const words2 = data2.content.trim().split(/\s+/).length;
          const hashtags2 = (data2.content.match(/#\w+/g) || []).length;
          const isValid2 = data2.validation?.isValid ?? false;
          const reasons2 = data2.validation?.reasons || [];

          item.attempt2 = {
            wordCount: words2,
            hashtagCount: hashtags2,
            isValid: isValid2,
            reasons: reasons2,
            content: data2.content,
          };

          item.finalStatus = isValid2 ? 'pass_retry' : 'failed';
        }

        results.push(item);
        setTestRuns([...results]);
      } catch (err) {
        // Handle unexpected error
      }
    }

    setIsRunning(false);
  };

  // Metrics calculation
  const totalCompleted = testRuns.length;
  const passedFirstAttempt = testRuns.filter((r) => r.attempt1.isValid).length;
  const passedAfterRetry = testRuns.filter((r) => r.finalStatus === 'pass_first' || r.finalStatus === 'pass_retry').length;

  const passRateBefore = totalCompleted > 0 ? Math.round((passedFirstAttempt / totalCompleted) * 100) : 0;
  const passRateAfter = totalCompleted > 0 ? Math.round((passedAfterRetry / totalCompleted) * 100) : 0;

  return (
    <div className="space-y-8">
      {/* Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center space-x-3 mb-2">
          <ShieldCheck className="w-6 h-6 text-emerald-400" />
          <h2 className="text-xl font-bold text-white">Tuesday Task: Validation & Auto-Retry Engine</h2>
        </div>
        <p className="text-slate-300 text-sm leading-relaxed max-w-3xl">
          Checks generated posts against two strict quality guardrails: <span className="text-indigo-300 font-semibold">150–300 Words</span> and <span className="text-indigo-300 font-semibold">3–5 Hashtags</span>. Automatically triggers a targeted re-prompt retry if rules are broken.
        </p>

        {/* Rule Badges */}
        <div className="mt-4 flex flex-wrap gap-3 text-xs font-mono">
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-200">
            Rule 1: <strong className="text-emerald-400">150 - 300 Words</strong>
          </div>
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-200">
            Rule 2: <strong className="text-emerald-400">3 - 5 Hashtags</strong>
          </div>
          <div className="bg-slate-950 border border-slate-800 px-3 py-1.5 rounded-lg text-slate-200">
            Action: <strong className="text-amber-400">Auto-Regenerate on Failure</strong>
          </div>
        </div>
      </div>

      {/* Test Suite Controls & Stats */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-semibold text-white">10-Generation Validation Benchmark</h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Run 10 posts through the validation pipeline and calculate pass rate before vs after auto-retry.
            </p>
          </div>

          <button
            onClick={run10TestGenerations}
            disabled={isRunning}
            className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-medium text-xs px-5 py-2.5 rounded-xl transition flex items-center space-x-2"
          >
            {isRunning ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Running 10 Benchmarks ({testRuns.length}/10)...</span>
              </>
            ) : (
              <>
                <BarChart3 className="w-4 h-4" />
                <span>Run 10 Benchmark Suite</span>
              </>
            )}
          </button>
        </div>

        {/* Pass Rate Comparison Cards */}
        {testRuns.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-950 p-5 rounded-xl border border-slate-800">
            <div>
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Pass Rate BEFORE Retry</span>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-3xl font-extrabold text-amber-400">{passRateBefore}%</span>
                <span className="text-xs text-slate-400">({passedFirstAttempt}/{totalCompleted} passed)</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full mt-2 overflow-hidden">
                <div className="bg-amber-400 h-full transition-all duration-500" style={{ width: `${passRateBefore}%` }} />
              </div>
            </div>

            <div>
              <span className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Pass Rate AFTER Auto-Retry</span>
              <div className="flex items-baseline space-x-2 mt-1">
                <span className="text-3xl font-extrabold text-emerald-400">{passRateAfter}%</span>
                <span className="text-xs text-slate-400">({passedAfterRetry}/{totalCompleted} passed)</span>
              </div>
              <div className="w-full bg-slate-800 h-2 rounded-full mt-2 overflow-hidden">
                <div className="bg-emerald-400 h-full transition-all duration-500" style={{ width: `${passRateAfter}%` }} />
              </div>
            </div>

            <div className="bg-indigo-950/40 border border-indigo-800/50 p-3 rounded-lg flex flex-col justify-between">
              <span className="text-xs text-indigo-300 font-semibold">Validation Guard Impact</span>
              <p className="text-xs text-slate-300 mt-1">
                Auto-retry improved pass rate by <strong className="text-emerald-400">+{passRateAfter - passRateBefore}%</strong> points by injecting explicit word/hashtag constraint feedback into Attempt 2.
              </p>
            </div>
          </div>
        )}

        {/* Detailed Results Table */}
        {testRuns.length > 0 && (
          <div className="border border-slate-800 rounded-xl overflow-hidden font-sans">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase text-[10px] tracking-wider font-semibold">
                <tr>
                  <th className="p-3"># / Topic</th>
                  <th className="p-3">Attempt 1 (Words / Hashtags)</th>
                  <th className="p-3">Attempt 2 (Auto-Retry)</th>
                  <th className="p-3">Final Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 bg-slate-900">
                {testRuns.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-800/40 transition">
                    <td className="p-3">
                      <div className="font-semibold text-white">Run #{r.id}: {r.niche}</div>
                      <div className="text-[11px] text-slate-400 truncate max-w-xs">{r.topic}</div>
                    </td>

                    <td className="p-3 font-mono">
                      <div className="flex items-center space-x-2">
                        {r.attempt1.isValid ? (
                          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                        ) : (
                          <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        )}
                        <span>{r.attempt1.wordCount} words | {r.attempt1.hashtagCount} tags</span>
                      </div>
                      {r.attempt1.reasons.length > 0 && (
                        <div className="text-[10px] text-rose-400 mt-0.5">
                          {r.attempt1.reasons.join(', ')}
                        </div>
                      )}
                    </td>

                    <td className="p-3 font-mono">
                      {r.attempt2 ? (
                        <div>
                          <div className="flex items-center space-x-2">
                            {r.attempt2.isValid ? (
                              <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                            ) : (
                              <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                            )}
                            <span>{r.attempt2.wordCount} words | {r.attempt2.hashtagCount} tags</span>
                          </div>
                          {r.attempt2.reasons.length > 0 && (
                            <div className="text-[10px] text-rose-400 mt-0.5">
                              {r.attempt2.reasons.join(', ')}
                            </div>
                          )}
                        </div>
                      ) : (
                        <span className="text-slate-500 italic">Not needed (Passed 1st)</span>
                      )}
                    </td>

                    <td className="p-3">
                      {r.finalStatus === 'pass_first' && (
                        <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 px-2 py-1 rounded text-[10px] font-semibold">
                          PASSED (1st Try)
                        </span>
                      )}
                      {r.finalStatus === 'pass_retry' && (
                        <span className="bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 px-2 py-1 rounded text-[10px] font-semibold">
                          PASSED (On Retry)
                        </span>
                      )}
                      {r.finalStatus === 'failed' && (
                        <span className="bg-rose-500/10 text-rose-400 border border-rose-500/30 px-2 py-1 rounded text-[10px] font-semibold">
                          FAILED RULE
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
