#!/usr/bin/env python3
"""
LinkedIn Post Generator using Groq API (Free, Fast, Works!)
"""

import os
import sys
import re
import json
import argparse
from groq import Groq

DEFAULT_MODEL = "llama-3.3-70b-versatile"  # Fast, free, works

def generate_post_raw(niche, tone, topic, is_carousel, model, api_key):
    client = Groq(api_key=api_key)
    
    if is_carousel:
        prompt = f"""You are an expert LinkedIn content creator for {niche}.
Write an 8-slide carousel about '{topic}' in a {tone} tone.
Return exactly:
Slide 1: [Title] - [content]
Slide 2: [Title] - [content]
...
Slide 8: [Title] - [content]"""
    else:
        prompt = f"""You are a LinkedIn ghostwriter for {niche}.
Write a LinkedIn post about '{topic}' in a {tone} tone.

Rules:
1. Length: 150-300 words
2. Include 3-5 relevant hashtags at the end
3. Use short paragraphs
4. Include a hook and CTA

Write the post:"""

    try:
        completion = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=1024
        )
        return completion.choices[0].message.content.strip()
    except Exception as e:
        print(f"\n❌ Groq Error: {e}")
        sys.exit(1)

def validate_post(text):
    words = text.split()
    word_count = len(words)
    hashtags = re.findall(r'#\w+', text)
    hashtag_count = len(hashtags)
    
    reasons = []
    if word_count < 150:
        reasons.append(f"Word count too low ({word_count} < 150)")
    elif word_count > 300:
        reasons.append(f"Word count too high ({word_count} > 300)")
    if hashtag_count < 3:
        reasons.append(f"Too few hashtags ({hashtag_count} < 3)")
    elif hashtag_count > 5:
        reasons.append(f"Too many hashtags ({hashtag_count} > 5)")
    
    return {
        "is_valid": len(reasons) == 0,
        "word_count": word_count,
        "hashtag_count": hashtag_count,
        "hashtags": hashtags,
        "reasons": reasons
    }

def generate_post(niche, tone, topic, is_carousel, model, api_key):
    for attempt in range(1, 3):
        content = generate_post_raw(niche, tone, topic, is_carousel, model, api_key)
        if is_carousel:
            return content, {"is_valid": True, "word_count": len(content.split()), "hashtag_count": 0, "reasons": []}, attempt
        val = validate_post(content)
        if val["is_valid"]:
            return content, val, attempt
        print(f"⚠️ Attempt {attempt} failed: {', '.join(val['reasons'])}")
    return content, val, 2

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--niche", default="Tech Leader")
    parser.add_argument("--tone", default="storytelling")
    parser.add_argument("--topic", default="Imposter Syndrome in AI Engineering")
    parser.add_argument("--format", choices=["post", "carousel"], default="post")
    parser.add_argument("--eval", action="store_true")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    
    args = parser.parse_args()
    
    api_key = os.environ.get('GROQ_API_KEY')
    if not api_key:
        print("❌ Set GROQ_API_KEY environment variable")
        print("💡 $env:GROQ_API_KEY = 'your-key'")
        sys.exit(1)
    
    print("=" * 60)
    print(f"🚀 GROQ LINKEDIN GENERATOR")
    print(f"📌 Topic: '{args.topic}' | Niche: {args.niche} | Tone: {args.tone}")
    print("=" * 60)
    
    content, val, attempts = generate_post(
        args.niche, args.tone, args.topic,
        args.format == "carousel",
        args.model, api_key
    )
    
    print("\n--- GENERATED CONTENT ---")
    print(content)
    print("-------------------------\n")
    
    if args.format == "post":
        print("📊 VALIDATION:")
        print(f"  • Attempts: {attempts}")
        print(f"  • Word Count: {val['word_count']} (150-300)")
        print(f"  • Hashtags: {', '.join(val['hashtags'])} ({val['hashtag_count']}/3-5)")
        print(f"  • Valid: {'✅ PASSED' if val['is_valid'] else '❌ FAILED'}")

if __name__ == "__main__":
    main()