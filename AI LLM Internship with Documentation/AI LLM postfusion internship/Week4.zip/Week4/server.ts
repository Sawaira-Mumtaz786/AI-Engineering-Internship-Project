import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const app = express();
app.use(express.json());

// Lazy Gemini client initializer
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (key) {
      aiClient = new GoogleGenAI({ apiKey: key });
    }
  }
  return aiClient;
}

// ----------------------------------------------------
// Validation Helper Function
// ----------------------------------------------------
function validatePost(text: string) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const hashtags = text.match(/#\w+/g) || [];
  const hashtagCount = hashtags.length;

  const reasons: string[] = [];
  if (wordCount < 150) {
    reasons.append ? reasons.push(`Word count too low (${wordCount} words < 150 min)`) : reasons.push(`Word count too low (${wordCount} words < 150 min)`);
  } else if (wordCount > 300) {
    reasons.push(`Word count too high (${wordCount} words > 300 max)`);
  }

  if (hashtagCount < 3) {
    reasons.push(`Too few hashtags (${hashtagCount} < 3 min)`);
  } else if (hashtagCount > 5) {
    reasons.push(`Too many hashtags (${hashtagCount} > 5 max)`);
  }

  return {
    isValid: reasons.length === 0,
    wordCount,
    hashtagCount,
    hashtags,
    reasons,
  };
}

// ----------------------------------------------------
// API Route: Ollama Connection Health Check
// ----------------------------------------------------
app.get('/api/ollama-status', async (req: Request, res: Response) => {
  const ollamaUrl = (req.query.url as string) || 'http://localhost:11434';
  try {
    const response = await fetch(`${ollamaUrl}/api/tags`, { signal: AbortSignal.timeout(3000) });
    if (response.ok) {
      const data = await response.json();
      return res.json({ online: true, models: data.models || [] });
    }
    return res.json({ online: false, error: 'Ollama responded with status ' + response.status });
  } catch (err: any) {
    return res.json({ online: false, error: err.message || 'Cannot reach Ollama at ' + ollamaUrl });
  }
});

// ----------------------------------------------------
// API Route: Core LLM Post & Carousel Generation
// ----------------------------------------------------
app.post('/api/generate', async (req: Request, res: Response) => {
  const {
    niche = 'Coach',
    tone = 'storytelling',
    topic = 'Overcoming imposter syndrome in career',
    format = 'post',
    provider = 'ollama', // 'ollama' | 'gemini' | 'auto'
    ollamaUrl = 'http://localhost:11434/api/generate',
    model = 'llama3',
    maxRetries = 2,
  } = req.body;

  const isCarousel = format === 'carousel';

  let prompt = '';
  if (isCarousel) {
    prompt = `You are an expert LinkedIn content creator for the ${niche} niche.
Write an engaging 8-slide LinkedIn carousel about '${topic}' in a ${tone} tone.

FORMAT INSTRUCTIONS:
Return exactly an 8-slide numbered list like this:
Slide 1: [Catchy Hook Title] - [1-2 short punchy sentences]
Slide 2: [Key Insight 1] - [1-2 short punchy sentences]
Slide 3: [Key Insight 2] - [1-2 short punchy sentences]
Slide 4: [Key Insight 3] - [1-2 short punchy sentences]
Slide 5: [Key Insight 4] - [1-2 short punchy sentences]
Slide 6: [Key Insight 5] - [1-2 short punchy sentences]
Slide 7: [Key Insight 6] - [1-2 short punchy sentences]
Slide 8: [Call to Action] - [1 closing sentence and question]

Do not include any intro or outro text outside the 8 slides.`;
  } else {
    prompt = `You are a top-performing LinkedIn ghostwriter for the ${niche} niche.
Write a LinkedIn post about '${topic}' using a ${tone} tone.

CRITICAL RULES:
1. Target length: strictly between 150 and 300 words.
2. Include strictly 3 to 5 relevant hashtags at the very end.
3. Use short, readable paragraphs with line breaks for skimmability.
4. Include a strong hook in line 1 and a question/CTA at the end.

Write the post now:`;
  }

  let attemptCount = 0;
  let finalContent = '';
  let valInfo: any = null;
  let providerUsed = provider;

  // Function to call LLM (Ollama or Gemini)
  async function callLLM(activePrompt: string) {
    if (providerUsed === 'ollama' || providerUsed === 'auto') {
      try {
        const response = await fetch(ollamaUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model,
            prompt: activePrompt,
            stream: false,
            options: { temperature: 0.7 },
          }),
        });

        if (response.ok) {
          const data = await response.json();
          providerUsed = 'ollama';
          return data.response || '';
        }
      } catch (ollamaErr) {
        if (providerUsed === 'ollama') {
          // If explicitly requested ollama and failed, rethrow or switch if auto
          throw new Error(`Failed to communicate with Ollama at ${ollamaUrl}. Make sure 'ollama serve' is running.`);
        }
      }
    }

    // Fallback to Gemini API if process.env.GEMINI_API_KEY exists or provider === 'gemini' / 'auto'
    const client = getGeminiClient();
    if (client) {
      providerUsed = 'gemini';
      const response = await client.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: activePrompt,
      });
      return response.text || '';
    }

    throw new Error('No active LLM provider available. Please run Ollama locally or provide GEMINI_API_KEY.');
  }

  try {
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
      attemptCount = attempt;
      finalContent = await callLLM(prompt);

      if (isCarousel) {
        valInfo = { isValid: true, wordCount: finalContent.split(/\s+/).length, hashtagCount: 0, reasons: [] };
        break;
      }

      valInfo = validatePost(finalContent);
      if (valInfo.isValid) {
        break;
      }

      // Modify prompt for retry
      prompt = `${prompt}\n\n[SYSTEM NOTICE: Your previous attempt was ${valInfo.wordCount} words and had ${valInfo.hashtagCount} hashtags. Failure reasons: ${valInfo.reasons.join(', ')}. Please strictly adjust to 150-300 words and 3-5 hashtags.]`;
    }

    return res.json({
      content: finalContent,
      attempts: attemptCount,
      validation: valInfo,
      providerUsed,
      format,
      niche,
      tone,
      topic,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Failed to generate content' });
  }
});

// ----------------------------------------------------
// API Route: Quality Guard (Day 3 AI Score)
// ----------------------------------------------------
app.post('/api/rate-authenticity', async (req: Request, res: Response) => {
  const { content, provider = 'auto', ollamaUrl = 'http://localhost:11434/api/generate', model = 'llama3' } = req.body;

  if (!content) {
    return res.status(400).json({ error: 'Content is required for evaluation' });
  }

  const evalPrompt = `You are a ruthless LinkedIn editor checking for generic AI writing tropes.
Analyze the following post and rate how AI-generated it sounds on a strict scale of 1 to 10 (1 = completely natural human writing, 10 = obviously generic AI with cliches like 'delve', 'game-changer', 'tapestry', 'in today's fast-paced world').

POST TO EVALUATE:
"""
${content}
"""

OUTPUT FORMAT:
Return JSON strictly in this format:
{
  "score": <integer 1 to 10>,
  "reasoning": "<1-2 concise sentences explaining the score and listing any detected AI cliches>"
}`;

  try {
    let resultText = '';
    
    // Try Ollama first
    if (provider === 'ollama' || provider === 'auto') {
      try {
        const response = await fetch(ollamaUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model,
            prompt: evalPrompt,
            stream: false,
            format: 'json',
          }),
        });
        if (response.ok) {
          const data = await response.json();
          resultText = data.response || '';
        }
      } catch (e) {
        // Fallback
      }
    }

    if (!resultText) {
      const client = getGeminiClient();
      if (client) {
        const response = await client.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: evalPrompt,
          config: { responseMimeType: 'application/json' },
        });
        resultText = response.text || '';
      }
    }

    // Parse JSON
    let parsed = { score: 5, reasoning: 'Standard AI evaluation' };
    try {
      const jsonMatch = resultText.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        parsed = JSON.parse(jsonMatch[0]);
      }
    } catch (e) {
      parsed = { score: 6, reasoning: resultText.slice(0, 150) };
    }

    return res.json(parsed);
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Evaluation failed' });
  }
});

// ----------------------------------------------------
// Start Express + Vite Middleware
// ----------------------------------------------------
async function startServer() {
  const PORT = 3000;
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });

  app.use(vite.middlewares);

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Studio Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
