import requests
import json

print("=" * 70)
print("THURSDAY TASK - OLLAMA API SCRIPT")
print("=" * 70)

# ============================================================
# CONFIGURATION
# ============================================================
ollama_url = "http://localhost:11434/api/chat"
model_name = "mistral"  # Change to "llama3.2", "phi3.5", or "gemma3" if needed

def call_ollama(system_message, user_message):
    """Function to send a prompt to Ollama and get the response"""
    payload = {
        "model": model_name,
        "messages": [
            {"role": "system", "content": system_message},
            {"role": "user", "content": user_message}
        ],
        "options": {
            "num_predict": 200  # Limits response length
        },
        "stream": False
    }
    try:
        response = requests.post(ollama_url, json=payload, timeout=30)
        if response.status_code == 200:
            return response.json()["message"]["content"]
        else:
            return f"ERROR: {response.status_code} - {response.text}"
    except requests.exceptions.Timeout:
        return "ERROR: Ollama took too long. Please try again."
    except Exception as e:
        return f"ERROR: Could not connect to Ollama. Make sure Ollama is running. Details: {e}"

print("\n✅ Ollama is connected and ready!\n")

# ============================================================
# TASK 1: BASIC API CALL - PRINT RAW RESPONSE
# ============================================================
print("=" * 70)
print("TASK 1: BASIC API CALL (Print Raw Response)")
print("=" * 70)

# Define a simple system and user message
system_message_simple = "You are a helpful assistant."
user_message_simple = "Say 'My first API call works perfectly!' in a professional tone."

print("\n📤 SENDING PROMPT:")
print(f"System: {system_message_simple}")
print(f"User: {user_message_simple}")

print("\n📥 RAW RESPONSE:")
response = call_ollama(system_message_simple, user_message_simple)
print(response)

# ============================================================
# TASK 2: DYNAMIC PROMPT BUILDING WITH VARIABLES
# ============================================================
print("\n" + "=" * 70)
print("TASK 2: DYNAMIC PROMPT WITH NICHE AND TONE VARIABLES")
print("=" * 70)

def build_dynamic_prompt(niche, tone):
    """Build a LinkedIn post prompt dynamically based on niche and tone"""
    
    # Tone descriptions
    tone_descriptions = {
        "professional": "Professional, polished, and business-like. Use proper business language.",
        "casual": "Casual, conversational, and friendly. Use everyday language.",
        "inspirational": "Inspirational, motivational, and uplifting. Use powerful language.",
        "raw": "Raw, honest, and vulnerable. Share real struggles and lessons.",
        "opinionated": "Opinionated, direct, and slightly controversial. Take a strong stance.",
        "educational": "Educational, informative, and practical. Teach something useful."
    }
    
    # Niche descriptions
    niche_descriptions = {
        "coach": "A business or life coach who helps people achieve their goals.",
        "founder": "A SaaS founder who has built a company from the ground up.",
        "recruiter": "A recruiter who helps companies find and hire top talent."
    }
    
    tone_instruction = tone_descriptions.get(tone, "Professional and helpful.")
    niche_instruction = niche_descriptions.get(niche, "A professional in their field.")
    
    # Build the system prompt
    system_prompt = f"""You are {niche_instruction}
Your writing style is: {tone_instruction}
Write a LinkedIn post that is engaging and valuable to your audience.
Avoid buzzwords and generic advice. Be specific and authentic."""
    
    # Build the user prompt
    user_prompt = f"""Write a short LinkedIn post about a lesson you learned in your journey as a {niche}.
Keep it under 150 words. Make it engaging and shareable."""
    
    return system_prompt, user_prompt

# Test the dynamic function with different niches and tones
test_cases = [
    ("coach", "inspirational"),
    ("founder", "raw"),
    ("recruiter", "professional")
]

print("\n📋 TESTING DYNAMIC PROMPT GENERATION:\n")

for niche, tone in test_cases:
    system_prompt, user_prompt = build_dynamic_prompt(niche, tone)
    print(f"🔹 NICHE: {niche.upper()} | TONE: {tone.upper()}")
    print(f"   System: {system_prompt[:80]}...")
    print(f"   User: {user_prompt}")
    print()

# ============================================================
# TASK 3: GENERATE POSTS FOR ALL 3 NICHES
# ============================================================
print("=" * 70)
print("TASK 3: GENERATE POSTS FOR ALL 3 NICHES")
print("=" * 70)

# Define niches and tones
niches = [
    {"name": "Coach", "tone": "inspirational"},
    {"name": "Founder", "tone": "raw"},
    {"name": "Recruiter", "tone": "professional"}
]

all_posts = {}

for niche in niches:
    niche_name = niche["name"]
    tone = niche["tone"]
    
    print("\n" + "-" * 70)
    print(f"📝 GENERATING POST FOR: {niche_name.upper()} (Tone: {tone.upper()})")
    print("-" * 70)
    
    # Build dynamic prompt
    system_prompt, user_prompt = build_dynamic_prompt(niche_name.lower(), tone)
    
    print(f"\n📤 PROMPT SENT:")
    print(f"System: {system_prompt}")
    print(f"User: {user_prompt}")
    
    # Call Ollama
    print(f"\n📥 GENERATING POST...")
    post = call_ollama(system_prompt, user_prompt)
    
    print(f"\n📄 POST GENERATED:")
    print(post)
    
    # Store for later use
    all_posts[niche_name] = {
        "tone": tone,
        "system_prompt": system_prompt,
        "user_prompt": user_prompt,
        "post": post
    }

# ============================================================
# SUMMARY TABLE
# ============================================================
print("\n" + "=" * 70)
print("SUMMARY OF ALL GENERATED POSTS")
print("=" * 70)

print("\n┌─────────────┬─────────────┬────────────────────────────────────┐")
print("│ NICHE       │ TONE        │ POST PREVIEW                       │")
print("├─────────────┼─────────────┼────────────────────────────────────┤")

for niche_name, data in all_posts.items():
    post_preview = data["post"][:50] + "..." if len(data["post"]) > 50 else data["post"]
    print(f"│ {niche_name:<11} │ {data['tone']:<11} │ {post_preview:<34} │")

print("└─────────────┴─────────────┴────────────────────────────────────┘")

# ============================================================
# TASK 1 COMPLETE: RAW API CALL OUTPUT
# ============================================================
print("\n" + "=" * 70)
print("TASK 1 COMPLETE: RAW API CALL OUTPUT")
print("=" * 70)
print("""
✅ This script successfully:
1. Sent a prompt to Ollama API
2. Received and printed the response
3. Printed the raw response from the API

The API call was made to: http://localhost:11434/api/chat
Using model: """ + model_name)

# ============================================================
# TASK 2 COMPLETE: DYNAMIC PROMPT BUILDING
# ============================================================
print("\n" + "=" * 70)
print("TASK 2 COMPLETE: DYNAMIC PROMPT BUILDING")
print("=" * 70)
print("""
✅ This script successfully:
1. Created a function that builds prompts dynamically
2. Accepts 'niche' and 'tone' as variables
3. Generates different system prompts based on input

Available niches: coach, founder, recruiter
Available tones: professional, casual, inspirational, raw, opinionated, educational
""")

# ============================================================
# TASK 3 COMPLETE: ALL 3 NICHES GENERATED
# ============================================================
print("\n" + "=" * 70)
print("TASK 3 COMPLETE: GENERATED POSTS FOR ALL 3 NICHES")
print("=" * 70)

for niche_name, data in all_posts.items():
    print(f"\n🔹 {niche_name.upper()} POST (Tone: {data['tone']}):")
    print("-" * 50)
    print(data["post"])
    print("-" * 50)

print("\n" + "=" * 70)
print("✅ THURSDAY TASK COMPLETED SUCCESSFULLY!")
print("=" * 70)
print("""
📌 WHAT WAS DONE:
1. TASK 1: Basic API call to Ollama - printed raw response
2. TASK 2: Dynamic prompt building with niche and tone variables
3. TASK 3: Generated posts for Coach, Founder, and Recruiter

📊 WHAT WAS LEARNED:
- How to make API calls to Ollama
- How to build prompts dynamically
- How to customize outputs based on audience (niche) and style (tone)
- How to structure a Python script for AI content generation
""")